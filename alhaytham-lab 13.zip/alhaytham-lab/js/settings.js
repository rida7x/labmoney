// ===== Settings Module =====

let currentSettingsTab = 'general';

async function renderSettings() {
  const content = document.getElementById('content');
  content.innerHTML = `
    <div class="settings-container">
      <div class="settings-tabs">
        <button class="settings-tab ${currentSettingsTab === 'general' ? 'active' : ''}" onclick="switchSettingsTab('general')">
          <i class="fa-solid fa-gear"></i> عام
        </button>
        <button class="settings-tab ${currentSettingsTab === 'payment' ? 'active' : ''}" onclick="switchSettingsTab('payment')">
          <i class="fa-solid fa-credit-card"></i> طرق الدفع
        </button>
        <button class="settings-tab ${currentSettingsTab === 'categories' ? 'active' : ''}" onclick="switchSettingsTab('categories')">
          <i class="fa-solid fa-tags"></i> تصنيفات المصروفات
        </button>
        <button class="settings-tab ${currentSettingsTab === 'tests' ? 'active' : ''}" onclick="switchSettingsTab('tests')">
          <i class="fa-solid fa-vial"></i> كتالوج التحاليل
        </button>
        <button class="settings-tab ${currentSettingsTab === 'theme' ? 'active' : ''}" onclick="switchSettingsTab('theme')">
          <i class="fa-solid fa-palette"></i> الألوان والمظهر
        </button>
        <button class="settings-tab ${currentSettingsTab === 'users' ? 'active' : ''}" onclick="switchSettingsTab('users')">
          <i class="fa-solid fa-users-gear"></i> المستخدمين
        </button>
        <button class="settings-tab ${currentSettingsTab === 'backup' ? 'active' : ''}" onclick="switchSettingsTab('backup')">
          <i class="fa-solid fa-database"></i> النسخ الاحتياطي
        </button>
        <button class="settings-tab ${currentSettingsTab === 'about' ? 'active' : ''}" onclick="switchSettingsTab('about')">
          <i class="fa-solid fa-circle-info"></i> حول النظام
        </button>
      </div>
      <div id="settings-tab-content" class="settings-content"></div>
    </div>
  `;

  await loadSettingsTab();
}

function switchSettingsTab(tab) {
  currentSettingsTab = tab;
  renderSettings();
}

async function loadSettingsTab() {
  const container = document.getElementById('settings-tab-content');
  switch (currentSettingsTab) {
    case 'general':    container.innerHTML = await renderGeneralSettings(); break;
    case 'payment':    container.innerHTML = await renderPaymentSettings(); break;
    case 'categories': container.innerHTML = await renderCategorySettings(); break;
    case 'tests':      container.innerHTML = await renderTestsSettings(); break;
    case 'theme':      container.innerHTML = await renderThemeSettings(); setTimeout(initThemeListeners, 50); break;
    case 'users':      container.innerHTML = await renderUsersSettings(); break;
    case 'backup':     container.innerHTML = await renderBackupSettings(); break;
    case 'about':      container.innerHTML = renderAboutSection(); break;
  }
}

async function renderGeneralSettings() {
  const settings = await db.get('settings', 'main') || { id: 'main' };

  return `
    <h2><i class="fa-solid fa-gear"></i> الإعدادات العامة</h2>
    <form id="general-form" onsubmit="saveGeneralSettings(event)">
      <div class="form-grid">
        <div class="form-group full-width">
          <label>شعار المختبر</label>
          <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
            <div id="logoPreview" style="width:90px;height:90px;border-radius:12px;border:2px dashed var(--border);background:var(--bg-tertiary);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;">
              ${settings.labLogo ? `<img src="${settings.labLogo}" alt="logo" style="width:100%;height:100%;object-fit:contain;">` : '<i class="fas fa-image" style="font-size:32px;color:var(--text-tertiary);"></i>'}
            </div>
            <div style="display:flex;flex-direction:column;gap:8px;">
              <label class="btn btn-secondary" style="cursor:pointer;margin:0;">
                <i class="fas fa-upload"></i> اختر صورة
                <input type="file" accept="image/*" style="display:none;" onchange="handleLogoUpload(event)">
              </label>
              ${settings.labLogo ? `<button type="button" class="btn btn-sm btn-danger" onclick="removeLogo()"><i class="fas fa-trash"></i> إزالة</button>` : ''}
              <small style="color:var(--text-secondary);font-size:11px;">PNG, JPG • الحد الأقصى 2MB</small>
            </div>
          </div>
          <input type="hidden" name="labLogo" id="labLogoInput" value="${settings.labLogo || ''}">
        </div>
        <div class="form-group">
          <label>اسم المختبر <span class="required">*</span></label>
          <input type="text" class="form-input" name="labName" value="${settings.labName || 'مختبر الهيثم للتحاليل الطبية'}" required>
        </div>
        <div class="form-group">
          <label>العنوان</label>
          <input type="text" class="form-input" name="labAddress" value="${settings.labAddress || ''}">
        </div>
        <div class="form-group">
          <label>رقم الهاتف</label>
          <input type="tel" class="form-input" name="labPhone" value="${settings.labPhone || ''}">
        </div>
        <div class="form-group">
          <label>البريد الإلكتروني</label>
          <input type="email" class="form-input" name="labEmail" value="${settings.labEmail || ''}">
        </div>
        <div class="form-group">
          <label>العملة</label>
          <input type="text" class="form-input" name="currency" value="${settings.currency || 'د.ل'}">
        </div>
        <div class="form-group">
          <label>نسبة الضريبة (%)</label>
          <input type="number" step="0.01" min="0" max="100" class="form-input" name="taxRate" value="${settings.taxRate || 0}">
        </div>
        <div class="form-group">
          <label>رأس الفواتير</label>
          <input type="text" class="form-input" name="printHeader" value="${settings.printHeader || ''}">
        </div>
        <div class="form-group full-width">
          <label>نص تذييل الفواتير</label>
          <textarea class="form-input" name="printFooter" rows="2" placeholder="نص يظهر أسفل التقارير (اختياري)">${settings.printFooter || ''}</textarea>
        </div>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn btn-primary">
          <i class="fa-solid fa-save"></i> حفظ الإعدادات
        </button>
      </div>
    </form>
  `;
}

async function saveGeneralSettings(event) {
  event.preventDefault();
  const form = event.target;
  const existing = await db.get('settings', 'main') || { id: 'main' };
  const data = {
    ...existing,
    labName: form.labName.value.trim(),
    labLogo: form.labLogo.value.trim(),
    labAddress: form.labAddress.value.trim(),
    labPhone: form.labPhone.value.trim(),
    labEmail: form.labEmail.value.trim(),
    currency: form.currency.value.trim() || 'د.ل',
    taxRate: Number(form.taxRate.value) || 0,
    printHeader: form.printHeader.value.trim(),
    printFooter: form.printFooter.value.trim(),
  };
  await db.update('settings', data);
  showToast('تم حفظ الإعدادات', 'success');
  // تحديث اسم وشعار المختبر في الواجهة
  if (typeof applyLabBranding === 'function') await applyLabBranding();
}

async function renderPaymentSettings() {
  const methods = await db.getAll('paymentMethods');
  const rows = methods.map(m => `
    <tr>
      <td>${m.name}</td>
      <td><span class="badge ${m.active ? 'badge-success' : 'badge-secondary'}">${m.active ? 'مفعل' : 'معطل'}</span></td>
      <td>
        <button class="btn btn-sm btn-secondary" onclick="showPaymentMethodModal('${m.id}')">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button class="btn btn-sm btn-danger" onclick="deletePaymentMethod('${m.id}')">
          <i class="fa-solid fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');

  return `
    <h2><i class="fa-solid fa-credit-card"></i> طرق الدفع</h2>
    <button class="btn btn-primary" onclick="showPaymentMethodModal()">
      <i class="fa-solid fa-plus"></i> إضافة طريقة دفع
    </button>
    <div class="table-responsive" style="margin-top:1rem;">
      <table class="data-table">
        <thead><tr><th>الاسم</th><th>الحالة</th><th>إجراءات</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="3" class="text-center">لا توجد طرق دفع</td></tr>'}</tbody>
      </table>
    </div>
  `;
}

async function showPaymentMethodModal(id = null) {
  let m = { name: '', active: true };
  if (id) m = await db.get('paymentMethods', id);

  const html = `
    <form onsubmit="savePaymentMethod(event, '${id || ''}')">
      <div class="form-group">
        <label>الاسم <span class="required">*</span></label>
        <input type="text" class="form-input" name="name" value="${m.name || ''}" required>
      </div>
      <div class="form-group">
        <label>
          <input type="checkbox" name="active" ${m.active ? 'checked' : ''}>
          مفعل
        </label>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button type="submit" class="btn btn-primary">حفظ</button>
      </div>
    </form>
  `;
  showModal(id ? 'تعديل طريقة دفع' : 'إضافة طريقة دفع', html);
}

async function savePaymentMethod(event, id) {
  event.preventDefault();
  const form = event.target;
  const data = {
    name: form.name.value.trim(),
    active: form.active.checked,
  };
  if (id) {
    const existing = await db.get('paymentMethods', id);
    await db.update('paymentMethods', { ...existing, ...data });
  } else {
    data.id = db.generateId();
    await db.add('paymentMethods', data);
  }
  closeModal();
  showToast('تم الحفظ', 'success');
  loadSettingsTab();
}

async function deletePaymentMethod(id) {
  confirmAction('هل تريد حذف طريقة الدفع؟', async () => {
    await db.delete('paymentMethods', id);
    showToast('تم الحذف', 'success');
    loadSettingsTab();
  });
}

async function renderCategorySettings() {
  const cats = await db.getAll('expenseCategories');
  const rows = cats.map(c => `
    <tr>
      <td>${c.name}</td>
      <td>
        <button class="btn btn-sm btn-secondary" onclick="showCategoryModal('${c.id}')"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-sm btn-danger" onclick="deleteCategory('${c.id}')"><i class="fa-solid fa-trash"></i></button>
      </td>
    </tr>
  `).join('');

  return `
    <h2><i class="fa-solid fa-tags"></i> تصنيفات المصروفات</h2>
    <button class="btn btn-primary" onclick="showCategoryModal()">
      <i class="fa-solid fa-plus"></i> إضافة تصنيف
    </button>
    <div class="table-responsive" style="margin-top:1rem;">
      <table class="data-table">
        <thead><tr><th>الاسم</th><th>إجراءات</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="2" class="text-center">لا توجد تصنيفات</td></tr>'}</tbody>
      </table>
    </div>
  `;
}

async function showCategoryModal(id = null) {
  let c = { name: '' };
  if (id) c = await db.get('expenseCategories', id);

  const html = `
    <form onsubmit="saveCategory(event, '${id || ''}')">
      <div class="form-group">
        <label>اسم التصنيف <span class="required">*</span></label>
        <input type="text" class="form-input" name="name" value="${c.name || ''}" required>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button type="submit" class="btn btn-primary">حفظ</button>
      </div>
    </form>
  `;
  showModal(id ? 'تعديل التصنيف' : 'إضافة تصنيف', html);
}

async function saveCategory(event, id) {
  event.preventDefault();
  const form = event.target;
  const data = { name: form.name.value.trim() };
  if (id) {
    const existing = await db.get('expenseCategories', id);
    await db.update('expenseCategories', { ...existing, ...data });
  } else {
    data.id = db.generateId();
    await db.add('expenseCategories', data);
  }
  closeModal();
  showToast('تم الحفظ', 'success');
  loadSettingsTab();
}

async function deleteCategory(id) {
  confirmAction('هل تريد حذف هذا التصنيف؟', async () => {
    await db.delete('expenseCategories', id);
    showToast('تم الحذف', 'success');
    loadSettingsTab();
  });
}

async function renderUsersSettings() {
  const users = await db.getAll('users');
  const currentUser = getCurrentUser();
  const rows = users.map(u => `
    <tr>
      <td>${u.username}</td>
      <td>${u.fullName || '—'}</td>
      <td>${getRoleLabel(u.role)}</td>
      <td><span class="badge ${u.active ? 'badge-success' : 'badge-secondary'}">${u.active ? 'نشط' : 'موقوف'}</span></td>
      <td>
        <button class="btn btn-sm btn-secondary" onclick="showUserModal('${u.id}')"><i class="fa-solid fa-pen"></i></button>
        ${u.id !== currentUser?.id ? `<button class="btn btn-sm btn-danger" onclick="deleteUser('${u.id}')"><i class="fa-solid fa-trash"></i></button>` : ''}
      </td>
    </tr>
  `).join('');

  return `
    <h2><i class="fa-solid fa-users-gear"></i> إدارة المستخدمين</h2>
    <p class="text-muted">المستخدم الحالي: <strong>${currentUser?.username}</strong> (${getRoleLabel(currentUser?.role)})</p>
    <button class="btn btn-primary" onclick="showUserModal()">
      <i class="fa-solid fa-user-plus"></i> إضافة مستخدم
    </button>
    <div class="table-responsive" style="margin-top:1rem;">
      <table class="data-table">
        <thead><tr><th>اسم المستخدم</th><th>الاسم الكامل</th><th>الصلاحية</th><th>الحالة</th><th>إجراءات</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `;
}

async function showUserModal(id = null) {
  let user = { username: '', fullName: '', role: 'accountant', active: true };
  if (id) user = await db.get('users', id);

  const html = `
    <form onsubmit="saveUser(event, '${id || ''}')">
      <div class="form-grid">
        <div class="form-group">
          <label>اسم المستخدم <span class="required">*</span></label>
          <input type="text" class="form-input" name="username" value="${user.username || ''}" required ${id ? 'readonly' : ''}>
        </div>
        <div class="form-group">
          <label>الاسم الكامل</label>
          <input type="text" class="form-input" name="fullName" value="${user.fullName || ''}">
        </div>
        <div class="form-group">
          <label>${id ? 'كلمة مرور جديدة (اتركه فارغ للإبقاء)' : 'كلمة المرور '}${!id ? '<span class="required">*</span>' : ''}</label>
          <input type="password" class="form-input" name="password" ${!id ? 'required' : ''}>
        </div>
        <div class="form-group">
          <label>الصلاحية <span class="required">*</span></label>
          <select class="form-input" name="role" required>
            <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>مدير عام</option>
            <option value="accountant" ${user.role === 'accountant' ? 'selected' : ''}>محاسب</option>
            <option value="viewer" ${user.role === 'viewer' ? 'selected' : ''}>مشاهد فقط</option>
          </select>
        </div>
        <div class="form-group full-width">
          <label>
            <input type="checkbox" name="active" ${user.active ? 'checked' : ''}> الحساب نشط
          </label>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button type="submit" class="btn btn-primary">حفظ</button>
      </div>
    </form>
  `;
  showModal(id ? 'تعديل مستخدم' : 'إضافة مستخدم', html);
}

async function saveUser(event, id) {
  event.preventDefault();
  const form = event.target;

  try {
    if (id) {
      const existing = await db.get('users', id);
      const updated = {
        ...existing,
        fullName: form.fullName.value.trim(),
        role: form.role.value,
        active: form.active.checked,
      };
      if (form.password.value) {
        updated.password = hashPassword(form.password.value);
      }
      await db.update('users', updated);
    } else {
      const data = {
        id: db.generateId(),
        username: form.username.value.trim(),
        fullName: form.fullName.value.trim(),
        password: hashPassword(form.password.value),
        role: form.role.value,
        active: form.active.checked,
        createdAt: new Date().toISOString(),
      };
      // Check uniqueness
      const all = await db.getAll('users');
      if (all.some(u => u.username === data.username)) {
        showToast('اسم المستخدم موجود مسبقًا', 'error');
        return;
      }
      await db.add('users', data);
    }
    closeModal();
    showToast('تم الحفظ', 'success');
    loadSettingsTab();
  } catch (e) {
    showToast('حدث خطأ: ' + e.message, 'error');
  }
}

async function deleteUser(id) {
  confirmAction('هل تريد حذف هذا المستخدم؟', async () => {
    await db.delete('users', id);
    showToast('تم الحذف', 'success');
    loadSettingsTab();
  });
}

async function renderBackupSettings() {
  return `
    <h2><i class="fa-solid fa-database"></i> النسخ الاحتياطي والاستعادة</h2>

    <div class="info-banner">
      <i class="fa-solid fa-info-circle"></i>
      <p>قم بتصدير نسخة احتياطية بشكل منتظم. سيتم حفظ جميع بيانات النظام في ملف JSON يمكن استعادته لاحقًا.</p>
    </div>

    <div class="settings-section">
      <h3><i class="fa-solid fa-download"></i> تصدير نسخة احتياطية</h3>
      <p>تنزيل جميع البيانات في ملف واحد.</p>
      <button class="btn btn-primary" onclick="exportBackup()">
        <i class="fa-solid fa-download"></i> تصدير نسخة احتياطية
      </button>
    </div>

    <div class="settings-section">
      <h3><i class="fa-solid fa-upload"></i> استعادة نسخة احتياطية</h3>
      <p class="text-warning"><i class="fa-solid fa-triangle-exclamation"></i> تحذير: ستحل البيانات المستوردة محل البيانات الحالية!</p>
      <input type="file" id="backup-file" accept=".json" style="display:none;" onchange="importBackup(event)">
      <button class="btn btn-warning" onclick="document.getElementById('backup-file').click()">
        <i class="fa-solid fa-upload"></i> استيراد نسخة احتياطية
      </button>
    </div>

    <div class="settings-section">
      <h3><i class="fa-solid fa-trash"></i> حذف جميع البيانات</h3>
      <p class="text-danger">سيتم حذف جميع البيانات بشكل نهائي. لا يمكن التراجع عن هذا الإجراء.</p>
      <button class="btn btn-danger" onclick="clearAllData()">
        <i class="fa-solid fa-trash"></i> حذف جميع البيانات
      </button>
    </div>
  `;
}

async function exportBackup() {
  try {
    const data = await db.exportAll();
    data._meta = {
      exportedAt: new Date().toISOString(),
      version: '1.0',
      app: 'Alhaytham Lab Management System'
    };
    downloadJSON(data, `alhaytham-backup-${getTodayString()}.json`);
    showToast('تم تصدير النسخة الاحتياطية', 'success');
  } catch (e) {
    showToast('حدث خطأ: ' + e.message, 'error');
  }
}

async function importBackup(event) {
  const file = event.target.files[0];
  if (!file) return;
  confirmAction('هل أنت متأكد؟ سيتم حذف جميع البيانات الحالية واستبدالها بمحتويات النسخة الاحتياطية.', async () => {
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      await db.importAll(data);
      showToast('تم استيراد البيانات بنجاح', 'success');
      setTimeout(() => location.reload(), 1500);
    } catch (e) {
      showToast('فشل الاستيراد: ' + e.message, 'error');
    }
  });
}

async function clearAllData() {
  confirmAction('هل أنت متأكد تمامًا؟ سيتم حذف جميع البيانات!', () => {
    confirmAction('هذا الإجراء نهائي ولا يمكن التراجع عنه. تأكيد الحذف؟', async () => {
      const stores = ['revenues','expenses','suppliers','supplierPayments','labToLab','employees','salaryRecords','advances'];
      for (const s of stores) {
        await db.clear(s);
      }
      showToast('تم حذف جميع البيانات', 'success');
      setTimeout(() => location.reload(), 1500);
    });
  });
}

function renderAboutSection() {
  return `
    <h2><i class="fa-solid fa-circle-info"></i> حول النظام</h2>
    <div class="about-section">
      <div class="about-logo">
        <i class="fa-solid fa-microscope"></i>
      </div>
      <h3>مختبر الهيثم للتحاليل الطبية</h3>
      <p class="version">الإصدار 1.0.0</p>

      <div class="about-info">
        <p>نظام إدارة مالية متكامل للمختبرات الطبية</p>
        <p>تم تطويره بـ HTML5, CSS3, JavaScript مع IndexedDB للتخزين المحلي</p>
      </div>

      <h4>الميزات:</h4>
      <ul class="features-list">
        <li><i class="fa-solid fa-check"></i> لوحة تحكم تفاعلية مع رسوم بيانية</li>
        <li><i class="fa-solid fa-check"></i> إدارة الإيرادات وطرق الدفع المتعددة</li>
        <li><i class="fa-solid fa-check"></i> إدارة المصروفات بالتصنيفات</li>
        <li><i class="fa-solid fa-check"></i> إدارة الديون والموردين</li>
        <li><i class="fa-solid fa-check"></i> نظام Lab to Lab</li>
        <li><i class="fa-solid fa-check"></i> إدارة الموظفين والرواتب والسلف</li>
        <li><i class="fa-solid fa-check"></i> تقارير متقدمة وتصدير</li>
        <li><i class="fa-solid fa-check"></i> تصميم متجاوب (PWA)</li>
        <li><i class="fa-solid fa-check"></i> الوضع الليلي والنهاري</li>
        <li><i class="fa-solid fa-check"></i> نسخ احتياطي واستعادة</li>
        <li><i class="fa-solid fa-check"></i> دعم العربية الكامل (RTL)</li>
      </ul>

      <div class="about-contact">
        <p><i class="fa-solid fa-coins"></i> العملة: دينار ليبي (LYD)</p>
        <p><i class="fa-solid fa-globe"></i> المنطقة: ليبيا</p>
      </div>
    </div>
  `;
}

// رفع شعار المختبر
async function handleLogoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
        showToast('الصورة كبيرة جداً (الحد الأقصى 2 ميغابايت)', 'error');
        return;
    }
    if (!file.type.startsWith('image/')) {
        showToast('الملف ليس صورة', 'error');
        return;
    }

    try {
        // تصغير الصورة للحد من حجم البيانات المخزنة
        const resized = await resizeImageDataURL(file, 400);
        document.getElementById('labLogoInput').value = resized;
        document.getElementById('logoPreview').innerHTML = `<img src="${resized}" alt="logo" style="width:100%;height:100%;object-fit:contain;">`;
        showToast('تم تحميل الشعار - اضغط حفظ', 'info');
    } catch (e) {
        showToast('فشل قراءة الصورة: ' + e.message, 'error');
    }
}

function removeLogo() {
    document.getElementById('labLogoInput').value = '';
    document.getElementById('logoPreview').innerHTML = '<i class="fas fa-image" style="font-size:32px;color:var(--text-tertiary);"></i>';
    showToast('تم إزالة الشعار - اضغط حفظ', 'info');
}

// تصغير صورة للحد من حجم Data URL
function resizeImageDataURL(file, maxSize = 400) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                let { width, height } = img;
                if (width > height && width > maxSize) {
                    height = (height * maxSize) / width;
                    width = maxSize;
                } else if (height > maxSize) {
                    width = (width * maxSize) / height;
                    height = maxSize;
                }
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/png', 0.92));
            };
            img.onerror = reject;
            img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

// ===== كتالوج التحاليل =====
async function renderTestsSettings() {
  const tests = await db.getAll('testCatalog');
  const rows = tests.map(t => `
    <tr>
      <td>${t.name}</td>
      <td>${t.category || '-'}</td>
      <td>${formatCurrency(t.price)}</td>
      <td>${t.notes || '-'}</td>
      <td>
        <button class="btn btn-sm btn-secondary" onclick="showTestSettingsModal('${t.id}')"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-sm btn-danger" onclick="deleteTestSetting('${t.id}')"><i class="fa-solid fa-trash"></i></button>
      </td>
    </tr>
  `).join('');

  return `
    <h2><i class="fa-solid fa-vial"></i> كتالوج التحاليل وأسعارها</h2>
    <p class="text-muted" style="margin-bottom:14px;">يمكن استخدام هذه القائمة في قسم المخزون → مخزون التحاليل، ولاختيار التحاليل بسرعة في Lab to Lab.</p>
    <button class="btn btn-primary" onclick="showTestSettingsModal()">
      <i class="fa-solid fa-plus"></i> إضافة تحليل
    </button>
    <div class="table-responsive" style="margin-top:1rem;">
      <table class="data-table">
        <thead><tr><th>اسم التحليل</th><th>التصنيف</th><th>السعر</th><th>ملاحظات</th><th>إجراءات</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="5" class="text-center">لا توجد تحاليل بعد</td></tr>'}</tbody>
      </table>
    </div>
  `;
}

async function showTestSettingsModal(id = null) {
  let test = { name: '', category: '', price: 0, notes: '' };
  if (id) test = await db.get('testCatalog', id);
  const html = `
    <form onsubmit="saveTestSetting(event, '${id || ''}')">
      <div class="form-group">
        <label>اسم التحليل <span class="required">*</span></label>
        <input type="text" class="form-input" name="name" value="${test.name || ''}" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>التصنيف</label>
          <input type="text" class="form-input" name="category" value="${test.category || ''}" placeholder="دم / بول / كيمياء حيوية...">
        </div>
        <div class="form-group">
          <label>السعر (د.ل) <span class="required">*</span></label>
          <input type="number" step="0.01" min="0" class="form-input" name="price" value="${test.price || 0}" required>
        </div>
      </div>
      <div class="form-group">
        <label>ملاحظات</label>
        <textarea class="form-input" name="notes">${test.notes || ''}</textarea>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button type="submit" class="btn btn-primary">حفظ</button>
      </div>
    </form>
  `;
  showModal(id ? 'تعديل تحليل' : 'إضافة تحليل', html);
}

async function saveTestSetting(event, id) {
  event.preventDefault();
  const form = event.target;
  const data = {
    name: form.name.value.trim(),
    category: form.category.value.trim(),
    price: parseFloat(form.price.value) || 0,
    notes: form.notes.value.trim()
  };
  if (id) {
    const existing = await db.get('testCatalog', id);
    await db.update('testCatalog', { ...existing, ...data });
  } else {
    data.id = db.generateId();
    await db.add('testCatalog', data);
  }
  closeModal();
  showToast('تم الحفظ', 'success');
  loadSettingsTab();
}

async function deleteTestSetting(id) {
  confirmAction('هل تريد حذف هذا التحليل؟', async () => {
    await db.delete('testCatalog', id);
    showToast('تم الحذف', 'success');
    loadSettingsTab();
  });
}

// ============== تخصيص الألوان والمظهر ==============
const DEFAULT_THEME = {
    primary: '#0d9488',
    primaryDark: '#0f766e',
    secondary: '#8b5cf6',
    success: '#10b981',
    danger: '#ef4444',
    warning: '#f59e0b',
    info: '#0ea5e9'
};

const PRESET_THEMES = [
    {
        name: 'الأزرق الطبي',
        colors: { primary: '#0d9488', primaryDark: '#0f766e', secondary: '#8b5cf6', success: '#10b981', danger: '#ef4444', warning: '#f59e0b', info: '#0ea5e9' }
    },
    {
        name: 'الأزرق الكلاسيكي',
        colors: { primary: '#2563eb', primaryDark: '#1d4ed8', secondary: '#7c3aed', success: '#16a34a', danger: '#dc2626', warning: '#ea580c', info: '#0284c7' }
    },
    {
        name: 'الزمردي',
        colors: { primary: '#059669', primaryDark: '#047857', secondary: '#0891b2', success: '#22c55e', danger: '#ef4444', warning: '#f59e0b', info: '#0ea5e9' }
    },
    {
        name: 'العنابي',
        colors: { primary: '#9f1239', primaryDark: '#881337', secondary: '#7c2d12', success: '#16a34a', danger: '#dc2626', warning: '#d97706', info: '#0369a1' }
    },
    {
        name: 'البنفسجي',
        colors: { primary: '#7c3aed', primaryDark: '#6d28d9', secondary: '#ec4899', success: '#10b981', danger: '#ef4444', warning: '#f59e0b', info: '#3b82f6' }
    },
    {
        name: 'الرمادي الراقي',
        colors: { primary: '#475569', primaryDark: '#334155', secondary: '#0891b2', success: '#16a34a', danger: '#dc2626', warning: '#d97706', info: '#2563eb' }
    },
    {
        name: 'الذهبي',
        colors: { primary: '#b45309', primaryDark: '#92400e', secondary: '#7c3aed', success: '#16a34a', danger: '#dc2626', warning: '#f59e0b', info: '#0284c7' }
    }
];

async function renderThemeSettings() {
    const settings = await db.get('settings', 'main') || {};
    const colors = settings.colors || DEFAULT_THEME;

    const presetCards = PRESET_THEMES.map((preset, idx) => `
        <div class="theme-preset" onclick="applyPresetTheme(${idx})" style="
            cursor:pointer;border:2px solid var(--border);border-radius:14px;padding:14px;
            transition:all 0.3s;background:var(--bg-secondary);
        " onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 6px 18px rgba(0,0,0,0.12)'" onmouseout="this.style.transform='';this.style.boxShadow=''">
            <div style="display:flex;gap:6px;margin-bottom:10px;">
                ${Object.values(preset.colors).slice(0,5).map(c => `<div style="width:24px;height:24px;border-radius:50%;background:${c};box-shadow:0 2px 4px rgba(0,0,0,0.1);"></div>`).join('')}
            </div>
            <div style="font-weight:600;font-size:14px;">${preset.name}</div>
        </div>
    `).join('');

    const colorPickers = [
        { key: 'primary', label: 'اللون الأساسي', icon: 'fa-paint-brush', desc: 'يستخدم في الأزرار الرئيسية، الروابط، والعناوين' },
        { key: 'primaryDark', label: 'الأساسي الداكن', icon: 'fa-moon', desc: 'نسخة داكنة من الأساسي للتدرجات' },
        { key: 'secondary', label: 'اللون الثانوي', icon: 'fa-palette', desc: 'لإضفاء التنوع والتمييز' },
        { key: 'success', label: 'لون النجاح', icon: 'fa-check-circle', desc: 'للإيرادات، التأكيدات الإيجابية' },
        { key: 'danger', label: 'لون الخطر', icon: 'fa-exclamation-circle', desc: 'للمصروفات، التحذيرات الخطيرة، الديون' },
        { key: 'warning', label: 'لون التحذير', icon: 'fa-triangle-exclamation', desc: 'للتنبيهات والملاحظات' },
        { key: 'info', label: 'لون المعلومات', icon: 'fa-info-circle', desc: 'للرسائل العامة' }
    ].map(c => `
        <div style="display:flex;align-items:center;gap:14px;padding:14px;background:var(--bg-tertiary);border-radius:12px;margin-bottom:10px;">
            <div style="position:relative;">
                <input type="color" class="theme-color-input" data-key="${c.key}" value="${colors[c.key] || DEFAULT_THEME[c.key]}"
                       style="width:54px;height:54px;border:none;border-radius:14px;cursor:pointer;padding:0;background:transparent;">
            </div>
            <div style="flex:1;">
                <div style="font-weight:700;font-size:14px;display:flex;align-items:center;gap:8px;">
                    <i class="fas ${c.icon}" style="color:${colors[c.key]};"></i> ${c.label}
                </div>
                <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">${c.desc}</div>
            </div>
            <div>
                <input type="text" class="theme-color-text" data-key="${c.key}" value="${colors[c.key] || DEFAULT_THEME[c.key]}"
                       style="width:100px;padding:8px;text-align:center;font-family:monospace;border:1px solid var(--border);border-radius:8px;">
            </div>
        </div>
    `).join('');

    return `
        <h2 style="margin-bottom:8px;"><i class="fa-solid fa-palette"></i> الألوان والمظهر</h2>
        <p style="color:var(--text-secondary);margin-bottom:18px;font-size:13px;">
            <i class="fas fa-info-circle"></i> الألوان تُطبَّق فوراً على الواجهة وعلى كل التقارير المُصدَّرة كـ PDF.
        </p>

        <div style="margin-bottom:24px;">
            <h3 style="font-size:15px;margin-bottom:12px;">🎨 ثيمات جاهزة</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;">
                ${presetCards}
            </div>
        </div>

        <div>
            <h3 style="font-size:15px;margin-bottom:12px;">🎨 تخصيص الألوان يدوياً</h3>
            ${colorPickers}
        </div>

        <!-- معاينة حية -->
        <div style="margin-top:20px;padding:16px;background:var(--bg-secondary);border:2px solid var(--border);border-radius:14px;">
            <h4 style="margin-bottom:12px;font-size:14px;">معاينة حية</h4>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button class="btn btn-primary"><i class="fas fa-save"></i> زر أساسي</button>
                <button class="btn btn-success"><i class="fas fa-check"></i> زر نجاح</button>
                <button class="btn btn-danger"><i class="fas fa-trash"></i> زر خطر</button>
                <button class="btn btn-warning"><i class="fas fa-bell"></i> تحذير</button>
                <span class="status paid">مسدَّد</span>
                <span class="status unpaid">غير مسدَّد</span>
            </div>
        </div>

        <div style="display:flex;gap:10px;margin-top:20px;flex-wrap:wrap;justify-content:flex-end;">
            <button class="btn btn-secondary" onclick="resetThemeToDefault()">
                <i class="fas fa-rotate-left"></i> استعادة الافتراضي
            </button>
            <button class="btn btn-primary" onclick="saveThemeColors()">
                <i class="fas fa-save"></i> حفظ الألوان
            </button>
        </div>
    `;
}

// ربط أحداث الألوان (لتحديث الحقول النصية والمعاينة الحية)
function initThemeListeners() {
    const colorInputs = document.querySelectorAll('.theme-color-input');
    const textInputs = document.querySelectorAll('.theme-color-text');

    colorInputs.forEach(inp => {
        inp.addEventListener('input', (e) => {
            const key = e.target.dataset.key;
            const txt = document.querySelector(`.theme-color-text[data-key="${key}"]`);
            if (txt) txt.value = e.target.value;
            previewThemeChange();
        });
    });

    textInputs.forEach(inp => {
        inp.addEventListener('input', (e) => {
            const v = e.target.value.trim();
            if (/^#[0-9a-fA-F]{6}$/.test(v)) {
                const key = e.target.dataset.key;
                const col = document.querySelector(`.theme-color-input[data-key="${key}"]`);
                if (col) col.value = v;
                previewThemeChange();
            }
        });
    });
}

function previewThemeChange() {
    const colors = {};
    document.querySelectorAll('.theme-color-input').forEach(inp => {
        colors[inp.dataset.key] = inp.value;
    });
    applyCustomTheme(colors);
}

// تطبيق فعلي للألوان على الـ CSS variables
function applyCustomTheme(colors) {
    if (!colors) return;
    const root = document.documentElement;
    const map = {
        primary: '--primary',
        primaryDark: '--primary-dark',
        secondary: '--secondary',
        success: '--success',
        danger: '--danger',
        warning: '--warning',
        info: '--info'
    };
    for (const k in map) {
        if (colors[k]) root.style.setProperty(map[k], colors[k]);
    }
    // أيضاً نُحدّث ألوان الخلفية الشفافة
    if (colors.primary) root.style.setProperty('--primary-bg', hexToRgba(colors.primary, 0.1));
    if (colors.primary) root.style.setProperty('--primary-light', hexToRgba(colors.primary, 0.15));
    if (colors.success) root.style.setProperty('--success-bg', hexToRgba(colors.success, 0.12));
    if (colors.danger) root.style.setProperty('--danger-bg', hexToRgba(colors.danger, 0.12));
    if (colors.warning) root.style.setProperty('--warning-bg', hexToRgba(colors.warning, 0.12));
    if (colors.info) root.style.setProperty('--info-bg', hexToRgba(colors.info, 0.12));
}

function hexToRgba(hex, alpha = 1) {
    const m = hex.replace('#', '').match(/.{2}/g);
    if (!m || m.length < 3) return hex;
    const [r, g, b] = m.map(x => parseInt(x, 16));
    return `rgba(${r},${g},${b},${alpha})`;
}

async function applyPresetTheme(idx) {
    const preset = PRESET_THEMES[idx];
    if (!preset) return;
    // حدّث الحقول
    Object.entries(preset.colors).forEach(([key, val]) => {
        const col = document.querySelector(`.theme-color-input[data-key="${key}"]`);
        const txt = document.querySelector(`.theme-color-text[data-key="${key}"]`);
        if (col) col.value = val;
        if (txt) txt.value = val;
    });
    applyCustomTheme(preset.colors);
    showToast(`تم تطبيق ثيم: ${preset.name}`, 'success');
}

async function resetThemeToDefault() {
    Object.entries(DEFAULT_THEME).forEach(([key, val]) => {
        const col = document.querySelector(`.theme-color-input[data-key="${key}"]`);
        const txt = document.querySelector(`.theme-color-text[data-key="${key}"]`);
        if (col) col.value = val;
        if (txt) txt.value = val;
    });
    applyCustomTheme(DEFAULT_THEME);
    showToast('تمت استعادة الألوان الافتراضية', 'info');
}

async function saveThemeColors() {
    const colors = {};
    document.querySelectorAll('.theme-color-input').forEach(inp => {
        colors[inp.dataset.key] = inp.value;
    });
    let settings = await db.get('settings', 'main') || { id: 'main' };
    settings.colors = colors;
    await db.update('settings', settings);
    applyCustomTheme(colors);
    showToast('تم حفظ الألوان بنجاح', 'success');
}
