// ===== قسم ديون المرضى =====
//
// مرضى لديهم ديون (دفعوا جزءاً وباقي مبلغ)
// لكل مريض:
//   - بيانات شخصية (اسم، هاتف)
//   - إجمالي الدين، المدفوع، المتبقي
//   - سجل الدفعات (مبلغ + طريقة دفع + تاريخ + ملاحظات)
//   - تعديل / حذف أي دفعة

let currentPatientSearch = '';
let currentPatientSort = 'name_asc';
function setPatientSort(v) { currentPatientSort = v; loadPatientDebts(); }

// ============== الواجهة الرئيسية ==============
async function renderPatientDebts() {
    const content = document.getElementById('content');
    content.innerHTML = `
        <div class="page-header">
            <h2><i class="fas fa-user-injured"></i> ديون المرضى</h2>
            <button class="btn btn-primary" onclick="showPatientDebtModal()">
                <i class="fas fa-plus"></i> دين جديد
            </button>
        </div>

        <div id="patientDebtsStats" class="stats-grid" style="margin-bottom:14px;"></div>

        <div class="card">
            <div class="toolbar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="بحث بالاسم أو رقم الهاتف..." oninput="onPatientSearch(this.value)">
                </div>
                ${buildSortSelect(currentPatientSort, 'setPatientSort')}
                <button class="btn btn-secondary" onclick="exportPatientDebtsPDF()">
                    <i class="fas fa-file-pdf"></i> تصدير PDF
                </button>
            </div>
            <div id="patientDebtsList"></div>
        </div>
    `;
    await loadPatientDebts();
}

function onPatientSearch(v) {
    currentPatientSearch = v;
    loadPatientDebts();
}

async function loadPatientDebts() {
    let debts = await db.getAll('patientDebts');

    if (currentPatientSearch) {
        const s = currentPatientSearch.toLowerCase();
        debts = debts.filter(d =>
            (d.name || '').toLowerCase().includes(s) ||
            (d.phone || '').includes(s)
        );
    }

    // احسب لكل مريض
    const enriched = await Promise.all(debts.map(async d => {
        const payments = await getPatientPayments(d.id);
        const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
        const totalDebt = Number(d.totalDebt || 0);
        return { ...d, payments, totalPaid, remaining: totalDebt - totalPaid };
    }));

    enriched = sortRecords(enriched, currentPatientSort);

    // الإحصائيات
    const totalDebt = enriched.reduce((s, d) => s + Number(d.totalDebt || 0), 0);
    const totalPaid = enriched.reduce((s, d) => s + d.totalPaid, 0);
    const totalRemaining = totalDebt - totalPaid;
    const overdueCount = enriched.filter(d => d.remaining > 0).length;

    document.getElementById('patientDebtsStats').innerHTML = `
        <div class="stat-card debt">
            <div class="stat-icon"><i class="fas fa-user-injured"></i></div>
            <div class="stat-label">عدد المرضى</div>
            <div class="stat-value">${enriched.length}</div>
            <div class="stat-meta">${overdueCount} مدين</div>
        </div>
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-coins"></i></div>
            <div class="stat-label">إجمالي الديون</div>
            <div class="stat-value">${formatCurrency(totalDebt)}</div>
        </div>
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
            <div class="stat-label">المحصَّل</div>
            <div class="stat-value">${formatCurrency(totalPaid)}</div>
        </div>
        <div class="stat-card profit">
            <div class="stat-icon"><i class="fas fa-exclamation-circle"></i></div>
            <div class="stat-label">المتبقي</div>
            <div class="stat-value">${formatCurrency(totalRemaining)}</div>
            <div class="stat-meta">${totalDebt > 0 ? Math.round(totalPaid / totalDebt * 100) : 0}% محصَّل</div>
        </div>
    `;

    const container = document.getElementById('patientDebtsList');
    if (enriched.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:40px 20px;">
                <i class="fas fa-user-injured" style="font-size:48px;color:#94a3b8;opacity:0.5;"></i>
                <h3 style="margin-top:12px;">لا توجد ديون مرضى</h3>
                <p style="color:var(--text-secondary);">اضغط "دين جديد" لإضافة دين</p>
            </div>
        `;
        return;
    }

    container.innerHTML = enriched.map(d => {
        const isPaid = d.remaining <= 0;
        const percentage = d.totalDebt > 0 ? Math.min((d.totalPaid / d.totalDebt) * 100, 100) : 0;
        return `
            <div class="lab-card" onclick="showPatientDebtDetails('${d.id}')" style="cursor:pointer;">
                <div class="lab-card-header">
                    <div>
                        <div class="lab-card-title">
                            <i class="fas fa-user-injured" style="color:var(--primary);"></i>
                            ${d.name}
                        </div>
                        <div style="font-size:13px;color:var(--text-tertiary);margin-top:4px;">
                            ${d.phone ? `<i class="fas fa-phone"></i> ${d.phone} • ` : ''}
                            <i class="fas fa-receipt"></i> ${d.payments.length} دفعة
                        </div>
                    </div>
                    <span class="status ${isPaid ? 'paid' : 'unpaid'}">
                        ${isPaid ? 'مسدد' : 'مدين'}
                    </span>
                </div>

                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0;">
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">إجمالي الدين</div>
                        <div style="font-weight:700;">${formatCurrency(d.totalDebt)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">المحصَّل</div>
                        <div style="font-weight:700;color:var(--success);">${formatCurrency(d.totalPaid)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">المتبقي</div>
                        <div style="font-weight:700;color:${isPaid ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(d.remaining)}</div>
                    </div>
                </div>

                <div style="background:var(--bg-tertiary);border-radius:8px;height:6px;overflow:hidden;">
                    <div style="height:100%;width:${percentage}%;background:linear-gradient(to right,var(--success),var(--primary));transition:width 0.5s;"></div>
                </div>

                <div style="display:flex;justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap;">
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        ${!isPaid ? `
                            <button class="btn btn-sm btn-success" onclick="event.stopPropagation(); showPatientPaymentModal('${d.id}')">
                                <i class="fas fa-money-bill-wave"></i> تحصيل دفعة
                            </button>
                        ` : ''}
                    </div>
                    <div style="display:flex;gap:6px;">
                        <button class="action-btn print" onclick="event.stopPropagation(); printPatientStatement('${d.id}')" title="كشف PDF">
                            <i class="fas fa-file-pdf"></i>
                        </button>
                        <button class="action-btn edit" onclick="event.stopPropagation(); showPatientDebtModal('${d.id}')" title="تعديل">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" onclick="event.stopPropagation(); deletePatientDebt('${d.id}')" title="حذف">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

async function getPatientPayments(patientDebtId) {
    const all = await db.getAll('patientPayments');
    return all.filter(p => p.debtId === patientDebtId).sort((a, b) => new Date(b.date) - new Date(a.date));
}

// ============== إضافة / تعديل دين ==============
async function showPatientDebtModal(id = null) {
    let debt = { name: '', phone: '', totalDebt: 0, notes: '' };
    if (id) {
        const found = await db.get('patientDebts', id);
        if (found) debt = found;
    }

    const body = `
        <form id="patientDebtForm" onsubmit="savePatientDebt(event, '${id || ''}')">
            <div class="form-group">
                <label>الاسم الكامل <span class="required">*</span></label>
                <input type="text" id="pd_name" value="${debt.name || ''}" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>رقم الهاتف</label>
                    <input type="tel" id="pd_phone" value="${debt.phone || ''}" placeholder="0912345678">
                </div>
                <div class="form-group">
                    <label>إجمالي الدين (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0" id="pd_totalDebt" value="${debt.totalDebt || ''}" required>
                </div>
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="pd_notes" rows="2" placeholder="نوع التحاليل، تاريخ الزيارة، إلخ...">${debt.notes || ''}</textarea>
            </div>
            ${!id ? `
                <div style="background:var(--primary-bg);padding:10px;border-radius:8px;margin-top:10px;font-size:12px;color:var(--text-secondary);">
                    <i class="fas fa-info-circle"></i> بعد حفظ الدين، يمكنك تسجيل الدفعات بشكل منفصل من بطاقة المريض.
                </div>
            ` : ''}
        </form>
    `;

    showModal(id ? 'تعديل دين مريض' : 'إضافة دين مريض جديد', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('patientDebtForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
}

async function savePatientDebt(event, id) {
    event.preventDefault();
    const data = {
        name: document.getElementById('pd_name').value.trim(),
        phone: document.getElementById('pd_phone').value.trim(),
        totalDebt: parseFloat(document.getElementById('pd_totalDebt').value) || 0,
        notes: document.getElementById('pd_notes').value.trim()
    };

    if (!data.name || data.totalDebt <= 0) {
        showToast('يرجى إدخال الاسم والمبلغ', 'error');
        return;
    }

    try {
        if (id) {
            const existing = await db.get('patientDebts', id);
            await db.update('patientDebts', { ...existing, ...data });
            showToast('تم تعديل البيانات', 'success');
        } else {
            data.createdAt = new Date().toISOString();
            await db.add('patientDebts', data);
            showToast('تم إضافة الدين', 'success');
        }
        closeModal();
        loadPatientDebts();
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

function deletePatientDebt(id) {
    confirmAction('هل تريد حذف هذا الدين؟ ستُحذف معه كل الدفعات المرتبطة.', async () => {
        const payments = (await db.getAll('patientPayments')).filter(p => p.debtId === id);
        for (const p of payments) {
            try { await db.delete('patientPayments', p.id); } catch (_) {}
        }
        await db.delete('patientDebts', id);
        showToast('تم الحذف', 'success');
        loadPatientDebts();
    }, 'حذف دين');
}

// ============== تفاصيل المريض ==============
async function showPatientDebtDetails(id) {
    const debt = await db.get('patientDebts', id);
    if (!debt) return;

    const payments = await getPatientPayments(id);
    const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    const totalDebt = Number(debt.totalDebt || 0);
    const remaining = totalDebt - totalPaid;
    const isPaid = remaining <= 0;

    // اجلب طرق الدفع للعرض
    const methods = await db.getAll('paymentMethods');
    const methodMap = Object.fromEntries(methods.map(m => [m.id, m.name]));

    const body = `
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px;">
            <div style="background:var(--bg-tertiary);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--text-tertiary);">إجمالي الدين</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;">${formatCurrency(totalDebt)}</div>
            </div>
            <div style="background:var(--success-bg);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--success);">المحصَّل</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:var(--success);">${formatCurrency(totalPaid)}</div>
            </div>
            <div style="background:${isPaid ? 'var(--success-bg)' : 'var(--danger-bg)'};padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:${isPaid ? 'var(--success)' : 'var(--danger)'};">المتبقي</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:${isPaid ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(remaining)}</div>
            </div>
        </div>

        <div style="background:var(--bg-tertiary);padding:12px;border-radius:10px;margin-bottom:16px;font-size:13px;">
            <div><strong>الاسم:</strong> ${debt.name}</div>
            ${debt.phone ? `<div style="margin-top:4px;"><i class="fas fa-phone" style="color:var(--primary);"></i> ${debt.phone}</div>` : ''}
            ${debt.notes ? `<div style="margin-top:4px;color:var(--text-secondary);">${debt.notes}</div>` : ''}
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <h4 style="font-size:15px;">سجل الدفعات (${payments.length})</h4>
            ${!isPaid ? `
                <button class="btn btn-sm btn-success" onclick="closeModal(); setTimeout(() => showPatientPaymentModal('${id}'), 200)">
                    <i class="fas fa-plus"></i> تحصيل دفعة
                </button>
            ` : ''}
        </div>

        ${payments.length === 0 ? `
            <div class="empty-state" style="padding:20px;">
                <i class="fas fa-receipt"></i>
                <p>لا توجد دفعات بعد</p>
            </div>
        ` : `
            <div style="max-height:300px;overflow-y:auto;display:flex;flex-direction:column;gap:8px;">
                ${payments.map(p => `
                    <div class="list-item">
                        <div class="list-icon" style="background:var(--success-bg);color:var(--success);">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="list-content">
                            <div class="list-title">${formatCurrency(p.amount)}</div>
                            <div class="list-meta">
                                ${formatDate(p.date, true)} • 
                                <i class="fas fa-credit-card"></i> ${methodMap[p.paymentMethod] || 'غير محدد'}
                                ${p.notes ? ` • ${p.notes}` : ''}
                            </div>
                        </div>
                        <div style="display:flex;gap:6px;">
                            <button class="action-btn edit" onclick="closeModal(); setTimeout(() => showPatientPaymentModal('${id}', '${p.id}'), 200)" title="تعديل">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete" onclick="deletePatientPayment('${p.id}', '${id}')" title="حذف">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `}
    `;

    showModal(debt.name, body, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
        <button class="btn btn-warning" onclick="printPatientStatement('${id}')">
            <i class="fas fa-file-pdf"></i> كشف حساب PDF
        </button>
    `, 'lg');
}

// ============== تحصيل دفعة (إضافة / تعديل) ==============
async function showPatientPaymentModal(debtId, paymentId = null) {
    const debt = await db.get('patientDebts', debtId);
    if (!debt) return;

    const payments = await getPatientPayments(debtId);
    const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    const remaining = Number(debt.totalDebt || 0) - totalPaid;

    let payment = null;
    if (paymentId) {
        payment = await db.get('patientPayments', paymentId);
        if (!payment) {
            showToast('الدفعة غير موجودة', 'error');
            return;
        }
    }

    const methods = (await db.getAll('paymentMethods')).filter(m => m.active !== false);

    const body = `
        <div style="background:var(--primary-bg);padding:14px;border-radius:10px;margin-bottom:16px;">
            <div style="font-weight:700;font-size:15px;margin-bottom:6px;">${debt.name}</div>
            <div style="font-size:13px;color:var(--text-secondary);">
                إجمالي: <strong>${formatCurrency(debt.totalDebt)}</strong> • 
                المحصَّل: <strong style="color:var(--success);">${formatCurrency(totalPaid)}</strong> • 
                المتبقي: <strong style="color:var(--danger);">${formatCurrency(remaining)}</strong>
            </div>
            ${payment ? `<div style="margin-top:8px;font-size:12px;color:var(--text-tertiary);">
                <i class="fas fa-info-circle"></i> تُعدّل دفعة موجودة - أي تعديل يحدّث الإجمالي تلقائياً
            </div>` : ''}
        </div>

        <form id="patientPaymentForm" onsubmit="savePatientPayment(event, '${debtId}', '${paymentId || ''}')">
            <div class="form-row">
                <div class="form-group">
                    <label>مبلغ الدفعة (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0.01" id="pp_amount" value="${payment?.amount || ''}" required autofocus>
                </div>
                <div class="form-group">
                    <label>طريقة الدفع <span class="required">*</span></label>
                    <select id="pp_method" required>
                        <option value="">-- اختر --</option>
                        ${methods.map(m => `
                            <option value="${m.id}" ${payment?.paymentMethod === m.id ? 'selected' : ''}>${m.name}</option>
                        `).join('')}
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>التاريخ والوقت</label>
                <input type="datetime-local" id="pp_date" value="${payment ? formatDateTimeInput(payment.date) : formatDateTimeInput()}">
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="pp_notes" rows="2" placeholder="رقم الإيصال، ملاحظات...">${payment?.notes || ''}</textarea>
            </div>
        </form>
    `;

    showModal(paymentId ? 'تعديل دفعة' : 'تحصيل دفعة', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-success" onclick="document.getElementById('patientPaymentForm').requestSubmit()">
            <i class="fas fa-check"></i> ${paymentId ? 'تحديث الدفعة' : 'تأكيد التحصيل'}
        </button>
    `);
}

async function savePatientPayment(event, debtId, paymentId) {
    event.preventDefault();
    const amount = parseFloat(document.getElementById('pp_amount').value);
    const paymentMethod = document.getElementById('pp_method').value;
    const date = new Date(document.getElementById('pp_date').value).toISOString();
    const notes = document.getElementById('pp_notes').value.trim();

    if (!amount || amount <= 0) {
        showToast('مبلغ غير صحيح', 'error');
        return;
    }
    if (!paymentMethod) {
        showToast('يرجى اختيار طريقة الدفع', 'error');
        return;
    }

    try {
        if (paymentId) {
            const existing = await db.get('patientPayments', paymentId);
            if (!existing) {
                showToast('الدفعة غير موجودة', 'error');
                return;
            }
            await db.update('patientPayments', { ...existing, amount, paymentMethod, date, notes });
            showToast('تم تعديل الدفعة', 'success');
        } else {
            await db.add('patientPayments', { debtId, amount, paymentMethod, date, notes });
            showToast('تم تحصيل الدفعة', 'success');

            // أيضاً سجّل العملية في الإيرادات لتظهر في التقارير
            try {
                const debt = await db.get('patientDebts', debtId);
                await db.add('revenues', {
                    patientName: debt?.name || 'مريض',
                    description: `تحصيل دين من ${debt?.name || 'مريض'}`,
                    amount,
                    paymentMethod,
                    date,
                    notes: 'تحصيل دين مريض' + (notes ? ' — ' + notes : ''),
                    sourceType: 'patient_debt_payment',
                    sourceId: debtId
                });
            } catch (_) {}
        }
        closeModal();
        loadPatientDebts();
        // أعد فتح التفاصيل
        setTimeout(() => showPatientDebtDetails(debtId), 200);
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

async function deletePatientPayment(paymentId, debtId) {
    confirmAction('هل تريد حذف هذه الدفعة؟', async () => {
        // احذف من الإيرادات إن وُجد ربط
        try {
            const all = await db.getAll('revenues');
            const linked = all.find(r => r.sourceType === 'patient_debt_payment' && r.sourceId === debtId);
            // ملاحظة: نحذف بالربط بمعرّف المريض فقط — قد تكون متعددة، لذا نطابق التاريخ والمبلغ
            const payment = await db.get('patientPayments', paymentId);
            if (payment && linked) {
                // ابحث عن أقرب إيراد مطابق
                const match = all.find(r =>
                    r.sourceType === 'patient_debt_payment' &&
                    r.sourceId === debtId &&
                    Number(r.amount) === Number(payment.amount) &&
                    String(r.date).slice(0,10) === String(payment.date).slice(0,10)
                );
                if (match) await db.delete('revenues', match.id);
            }
        } catch (_) {}

        await db.delete('patientPayments', paymentId);
        showToast('تم الحذف', 'success');
        closeModal();
        loadPatientDebts();
        setTimeout(() => showPatientDebtDetails(debtId), 200);
    }, 'حذف دفعة');
}

// ============== تصدير قائمة الديون ==============
async function exportPatientDebtsPDF() {
    let debts = await db.getAll('patientDebts');
    if (!debts.length) {
        showToast('لا توجد ديون', 'warning');
        return;
    }

    const enriched = await Promise.all(debts.map(async d => {
        const payments = await getPatientPayments(d.id);
        const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
        return {
            name: d.name,
            phone: d.phone || '-',
            totalDebt: formatCurrency(d.totalDebt),
            totalPaid: formatCurrency(totalPaid),
            remaining: formatCurrency(Number(d.totalDebt || 0) - totalPaid),
            status: (Number(d.totalDebt || 0) - totalPaid) <= 0 ? 'مسدد' : 'مدين'
        };
    }));

    enriched.sort((a, b) => a.status === 'مدين' ? -1 : 1);

    const totalDebt = debts.reduce((s, d) => s + Number(d.totalDebt || 0), 0);
    const payments = await db.getAll('patientPayments');
    const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);

    await generatePDFReport({
        title: 'تقرير ديون المرضى',
        subtitle: `إجمالي المرضى: ${debts.length}`,
        filename: `ديون_المرضى_${getTodayString()}.pdf`,
        columns: [
            { key: 'name',      label: 'الاسم',      width: '25%' },
            { key: 'phone',     label: 'الهاتف',    width: '17%' },
            { key: 'totalDebt', label: 'إجمالي',   width: '15%' },
            { key: 'totalPaid', label: 'المحصَّل', width: '15%' },
            { key: 'remaining', label: 'المتبقي',  width: '15%' },
            { key: 'status',    label: 'الحالة',   width: '13%' }
        ],
        rows: enriched,
        summary: [
            { label: 'إجمالي الديون', value: formatCurrency(totalDebt) },
            { label: 'المحصَّل', value: formatCurrency(totalPaid) },
            { label: 'المتبقي', value: formatCurrency(totalDebt - totalPaid), highlight: true }
        ]
    });
}

// ============== كشف حساب لمريض واحد ==============
async function printPatientStatement(id) {
    const debt = await db.get('patientDebts', id);
    if (!debt) return;
    const payments = await getPatientPayments(id);
    const methods = await db.getAll('paymentMethods');
    const methodMap = Object.fromEntries(methods.map(m => [m.id, m.name]));

    const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    const totalDebt = Number(debt.totalDebt || 0);
    const remaining = totalDebt - totalPaid;

    await generatePDFReport({
        title: `كشف حساب: ${debt.name}`,
        subtitle: `${debt.phone ? 'هاتف: ' + debt.phone + ' • ' : ''}عدد الدفعات: ${payments.length}`,
        filename: `كشف_${debt.name.replace(/[\/\\]/g, '_')}_${getTodayString()}.pdf`,
        columns: [
            { key: 'date',     label: 'التاريخ',     width: '20%' },
            { key: 'amount',   label: 'المبلغ',      width: '20%' },
            { key: 'method',   label: 'طريقة الدفع', width: '20%' },
            { key: 'notes',    label: 'ملاحظات',    width: '40%' }
        ],
        rows: payments.map(p => ({
            date: formatDate(p.date, true),
            amount: formatCurrency(p.amount),
            method: methodMap[p.paymentMethod] || '-',
            notes: p.notes || '-'
        })),
        summary: [
            { label: 'إجمالي الدين', value: formatCurrency(totalDebt) },
            { label: 'المحصَّل', value: formatCurrency(totalPaid) },
            { label: 'المتبقي', value: formatCurrency(remaining), highlight: true }
        ]
    });
}
