// ===== Employees & Salaries + Attendance Module =====

// عدد أيام العمل في شهر معين (كل الأيام ما عدا الجمعة)
function getWorkingDaysInMonth(year, month) {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    let count = 0;
    for (let d = 1; d <= daysInMonth; d++) {
        const day = new Date(year, month, d).getDay();
        // 5 = الجمعة في JavaScript
        if (day !== 5) count++;
    }
    return count;
}

// عدد أيام الحضور الفعلية في الشهر
async function getEmployeeAttendanceForMonth(empId, year, month) {
    const records = await db.getAll('attendance');
    return records.filter(r => {
        if (r.employeeId !== empId) return false;
        const d = new Date(r.date);
        return d.getFullYear() === year && d.getMonth() === month;
    });
}

// حساب الراتب للموظف لشهر معين
async function calculateEmployeeSalary(empId, year, month) {
    const emp = await db.get('employees', empId);
    if (!emp) return null;
    
    const baseSalary = Number(emp.baseSalary || 0);
    const advances = await db.getAll('advances');
    const monthAdvances = advances.filter(a => {
        if (a.employeeId !== empId) return false;
        const d = new Date(a.date);
        return d.getFullYear() === year && d.getMonth() === month;
    });
    const totalAdvances = monthAdvances.reduce((s, a) => s + Number(a.amount || 0), 0);
    
    const attendance = await getEmployeeAttendanceForMonth(empId, year, month);
    const absentDates = new Set(attendance.filter(a => a.status === 'absent').map(a => a.date.split('T')[0]));
    const markedPresentDates = new Set(attendance.filter(a => a.status === 'present').map(a => a.date.split('T')[0]));
    
    // عدد أيام العمل الكلي في الشهر (كل الأيام عدا الجمعة)
    const workingDays = getWorkingDaysInMonth(year, month);

    // حساب أيام الحضور والغياب الفعليّة:
    // - الغياب = أي يوم في attendance مع status=absent
    // - الحضور = باقي أيام العمل (افتراضي: حاضر) - حتى نهاية اليوم الحالي (لا نحسب المستقبل)
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    let workingDaysPassed = 0;
    let absentDays = 0;
    let presentDays = 0;

    for (let d = 1; d <= daysInMonth; d++) {
        const date = new Date(year, month, d);
        if (date > today) break; // لا نحسب أيام المستقبل
        if (date.getDay() === 5) continue; // تخطّ الجمعة
        workingDaysPassed++;
        const dateStr = date.toISOString().split('T')[0];
        if (absentDates.has(dateStr)) {
            absentDays++;
        } else {
            // افتراضياً اعتبره حاضراً (إلا إذا كان غير ذلك مُعلَّمًا صراحة)
            presentDays++;
        }
    }

    let calculation = {
        baseSalary,
        totalAdvances,
        presentDays,
        absentDays,
        workingDays,           // إجمالي أيام العمل في الشهر كاملاً
        workingDaysPassed,     // أيام العمل التي مرّت حتى اليوم
        salaryType: emp.salaryType,
        deductions: 0,
        earnedSalary: 0,
        netSalary: 0
    };
    
    if (emp.salaryType === 'monthly') {
        // راتب شهري: نخصم بنسبة أيام الغياب من الراتب الشهري كله
        const dailyEquivalent = workingDays > 0 ? baseSalary / workingDays : 0;
        calculation.deductions = absentDays * dailyEquivalent;
        calculation.earnedSalary = baseSalary - calculation.deductions;
        calculation.netSalary = calculation.earnedSalary - totalAdvances;
    } else {
        // راتب يومي: عدد أيام الحضور × سعر اليوم
        calculation.earnedSalary = presentDays * baseSalary;
        calculation.deductions = absentDays * baseSalary;
        calculation.netSalary = calculation.earnedSalary - totalAdvances;
    }
    
    return calculation;
}

async function renderEmployees() {
    const employees = await db.getAll('employees');
    const advances = await db.getAll('advances');
    
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    
    // حساب إجمالي للشهر الحالي
    let totalMonthlyPayroll = 0;
    for (const emp of employees.filter(e => e.status !== 'inactive')) {
        const calc = await calculateEmployeeSalary(emp.id, year, month);
        if (calc) totalMonthlyPayroll += calc.netSalary;
    }
    
    const monthAdvances = advances.filter(a => {
        const d = new Date(a.date);
        return d.getFullYear() === year && d.getMonth() === month;
    });
    const totalAdvances = monthAdvances.reduce((s, a) => s + Number(a.amount || 0), 0);
    
    document.getElementById('content').innerHTML = `
        <div class="page-header">
            <h2><i class="fas fa-users"></i> الموظفين والرواتب</h2>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                <button class="btn btn-primary" onclick="showEmployeeModal()">
                    <i class="fas fa-user-plus"></i> موظف جديد
                </button>
                <button class="btn btn-secondary" onclick="showAdvanceModal()">
                    <i class="fas fa-hand-holding-dollar"></i> سلفة
                </button>
                <button class="btn btn-success" onclick="showPayrollModal()">
                    <i class="fas fa-money-bill-transfer"></i> صرف الرواتب
                </button>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card employees">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-label">عدد الموظفين</div>
                <div class="stat-value">${employees.length}</div>
            </div>
            <div class="stat-card revenue">
                <div class="stat-icon"><i class="fas fa-money-check-dollar"></i></div>
                <div class="stat-label">إجمالي الرواتب الشهرية</div>
                <div class="stat-value">${formatCurrency(totalMonthlyPayroll + totalAdvances)}</div>
            </div>
            <div class="stat-card expense">
                <div class="stat-icon"><i class="fas fa-hand-holding-dollar"></i></div>
                <div class="stat-label">سلف هذا الشهر</div>
                <div class="stat-value">${formatCurrency(totalAdvances)}</div>
            </div>
            <div class="stat-card profit">
                <div class="stat-icon"><i class="fas fa-file-invoice-dollar"></i></div>
                <div class="stat-label">صافي الرواتب المتوقع</div>
                <div class="stat-value">${formatCurrency(totalMonthlyPayroll)}</div>
            </div>
        </div>

        <div class="card">
            <div class="toolbar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="emp-search" placeholder="بحث..." oninput="loadEmployees()">
                </div>
                <select class="filter-select" id="emp-sort" onchange="loadEmployees()">
                    <option value="name_asc">أ-ي (الاسم)</option>
                    <option value="name_desc">ي-أ (الاسم)</option>
                </select>
                <button class="btn btn-secondary" onclick="exportEmployees()">
                    <i class="fas fa-file-pdf"></i> تصدير PDF
                </button>
            </div>
            <div id="employees-container" class="cards-grid"></div>
        </div>
    `;

    await loadEmployees();
}

async function loadEmployees() {
    const search = (document.getElementById('emp-search')?.value || '').toLowerCase();
    let employees = await db.getAll('employees');

    if (search) {
        employees = employees.filter(e =>
            (e.name || '').toLowerCase().includes(search) ||
            (e.position || '').toLowerCase().includes(search) ||
            (e.phone || '').includes(search)
        );
    }

    const sortBy = document.getElementById('emp-sort')?.value || 'name_asc';
    employees = sortRecords(employees, sortBy);

    const container = document.getElementById('employees-container');
    if (!employees.length) {
        container.innerHTML = `<div class="empty-state"><i class="fas fa-users-slash"></i><p>لا يوجد موظفين</p></div>`;
        return;
    }

    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    
    const cards = await Promise.all(employees.map(async emp => {
        const calc = await calculateEmployeeSalary(emp.id, year, month);
        const typeLabel = emp.salaryType === 'monthly' ? 'شهري' : 'يومي';
        const statusBadge = emp.status === 'inactive'
            ? '<span class="badge badge-danger">غير نشط</span>'
            : '<span class="badge badge-success">نشط</span>';

        return `
            <div class="entity-card">
                <div class="entity-card-header">
                    <div class="entity-avatar">
                        <i class="fas fa-user-doctor"></i>
                    </div>
                    <div class="entity-info">
                        <h3>${emp.name}</h3>
                        <p>${emp.position || '—'} ${statusBadge}</p>
                    </div>
                </div>
                <div class="entity-stats">
                    <div class="entity-stat">
                        <span class="label">نوع الراتب:</span>
                        <span class="value">${typeLabel}</span>
                    </div>
                    <div class="entity-stat">
                        <span class="label">${emp.salaryType === 'monthly' ? 'الراتب الشهري:' : 'سعر اليوم:'}</span>
                        <span class="value">${formatCurrency(calc.baseSalary)}</span>
                    </div>
                    ${emp.salaryType === 'monthly' ? `
                        <div class="entity-stat">
                            <span class="label">الحضور / الغياب:</span>
                            <span class="value">${calc.presentDays} / ${calc.absentDays}</span>
                        </div>
                        <div class="entity-stat">
                            <span class="label">خصم الغياب:</span>
                            <span class="value text-danger">${formatCurrency(calc.deductions)}</span>
                        </div>
                    ` : `
                        <div class="entity-stat">
                            <span class="label">أيام الحضور:</span>
                            <span class="value text-success">${calc.presentDays}</span>
                        </div>
                        <div class="entity-stat">
                            <span class="label">المستحق:</span>
                            <span class="value">${formatCurrency(calc.earnedSalary)}</span>
                        </div>
                    `}
                    <div class="entity-stat">
                        <span class="label">سلف الشهر:</span>
                        <span class="value text-danger">${formatCurrency(calc.totalAdvances)}</span>
                    </div>
                    <div class="entity-stat">
                        <span class="label">الصافي:</span>
                        <span class="value text-success" style="font-size:15px;font-weight:800;">${formatCurrency(calc.netSalary)}</span>
                    </div>
                </div>
                <div class="entity-actions">
                    <button class="btn btn-sm btn-info" onclick="showAttendanceModal('${emp.id}')">
                        <i class="fas fa-calendar-check"></i> الحضور
                    </button>
                    <button class="btn btn-sm btn-warning" onclick="showEmployeeAdvances('${emp.id}')">
                        <i class="fas fa-hand-holding-dollar"></i> السلف
                    </button>
                    <button class="btn btn-sm btn-success" onclick="printPayslip('${emp.id}')">
                        <i class="fas fa-file-pdf"></i> قسيمة الراتب
                    </button>
                    <button class="action-btn edit" onclick="showEmployeeModal('${emp.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" onclick="deleteEmployee('${emp.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }));

    container.innerHTML = cards.join('');
}

async function showEmployeeModal(id = null) {
    let emp = { name: '', position: '', salaryType: 'monthly', baseSalary: 0, phone: '', hireDate: getTodayString(), status: 'active', notes: '' };
    if (id) emp = await db.get('employees', id);

    const html = `
        <form id="employee-form" onsubmit="saveEmployee(event, '${id || ''}')">
            <div class="form-row">
                <div class="form-group">
                    <label>الاسم <span class="required">*</span></label>
                    <input type="text" id="emp_name" value="${emp.name || ''}" required>
                </div>
                <div class="form-group">
                    <label>المنصب / الوظيفة</label>
                    <input type="text" id="emp_position" value="${emp.position || ''}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>نوع الراتب <span class="required">*</span></label>
                    <select id="emp_salaryType" required>
                        <option value="monthly" ${emp.salaryType === 'monthly' ? 'selected' : ''}>شهري</option>
                        <option value="daily" ${emp.salaryType === 'daily' ? 'selected' : ''}>يومي</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>قيمة الراتب (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0" id="emp_baseSalary" value="${emp.baseSalary || 0}" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>رقم الهاتف</label>
                    <input type="tel" id="emp_phone" value="${emp.phone || ''}">
                </div>
                <div class="form-group">
                    <label>تاريخ التعيين</label>
                    <input type="date" id="emp_hireDate" value="${emp.hireDate || getTodayString()}">
                </div>
            </div>
            <div class="form-group">
                <label>الحالة</label>
                <select id="emp_status">
                    <option value="active" ${emp.status === 'active' ? 'selected' : ''}>نشط</option>
                    <option value="inactive" ${emp.status === 'inactive' ? 'selected' : ''}>غير نشط</option>
                </select>
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="emp_notes" rows="2">${emp.notes || ''}</textarea>
            </div>
        </form>
    `;

    showModal(id ? 'تعديل موظف' : 'إضافة موظف', html, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('employee-form').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
}

async function saveEmployee(event, id) {
    event.preventDefault();
    const data = {
        name: document.getElementById('emp_name').value.trim(),
        position: document.getElementById('emp_position').value.trim(),
        salaryType: document.getElementById('emp_salaryType').value,
        baseSalary: parseFloat(document.getElementById('emp_baseSalary').value) || 0,
        phone: document.getElementById('emp_phone').value.trim(),
        hireDate: document.getElementById('emp_hireDate').value,
        status: document.getElementById('emp_status').value,
        notes: document.getElementById('emp_notes').value.trim()
    };

    try {
        if (id) {
            const existing = await db.get('employees', id);
            await db.update('employees', { ...existing, ...data });
            showToast('تم تحديث الموظف');
        } else {
            await db.add('employees', { ...data, createdAt: new Date().toISOString() });
            showToast('تم إضافة الموظف');
        }
        closeModal();
        loadEmployees();
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

async function deleteEmployee(id) {
    confirmAction('هل تريد حذف هذا الموظف؟ سيتم حذف السلف وسجل الحضور المرتبطة به.', async () => {
        try {
            const advances = await db.getAll('advances');
            const salaries = await db.getAll('salaryRecords');
            const attendance = await db.getAll('attendance');
            for (const a of advances.filter(x => x.employeeId === id)) await db.delete('advances', a.id);
            for (const s of salaries.filter(x => x.employeeId === id)) await db.delete('salaryRecords', s.id);
            for (const at of attendance.filter(x => x.employeeId === id)) await db.delete('attendance', at.id);
            await db.delete('employees', id);
            showToast('تم الحذف');
            loadEmployees();
        } catch (e) {
            showToast('خطأ', 'error');
        }
    });
}

// ==== نظام الحضور ====
async function showAttendanceModal(empId) {
    const emp = await db.get('employees', empId);
    if (!emp) return;
    
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();
    
    window._attendanceState = { empId, year: currentYear, month: currentMonth };
    
    const body = `
        <div style="background:var(--primary-bg);padding:14px;border-radius:10px;margin-bottom:16px;">
            <div style="font-weight:700;font-size:15px;">${emp.name}</div>
            <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">
                ${emp.position || ''} • ${emp.salaryType === 'monthly' ? 'راتب شهري' : 'راتب يومي'} • ${formatCurrency(emp.baseSalary)}
            </div>
        </div>
        
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <button class="btn btn-sm btn-secondary" onclick="changeAttendanceMonth(-1)">
                <i class="fas fa-chevron-right"></i> السابق
            </button>
            <div id="attendanceMonthLabel" style="font-weight:700;font-size:15px;"></div>
            <button class="btn btn-sm btn-secondary" onclick="changeAttendanceMonth(1)">
                التالي <i class="fas fa-chevron-left"></i>
            </button>
        </div>
        
        <div class="attendance-legend">
            <div><span class="legend-color" style="background:#10b981;"></span> حضور</div>
            <div><span class="legend-color" style="background:#ef4444;"></span> غياب</div>
            <div><span class="legend-color" style="background:#6366f1;"></span> جمعة (إجازة)</div>
            <div><span class="legend-color" style="background:#e5e7eb;"></span> مستقبل</div>
        </div>
        
        <div style="font-size:12px;color:var(--text-secondary);margin-bottom:8px;">
            <i class="fas fa-info-circle"></i> اضغط على اليوم لتغيير حالته (حضور / غياب / فراغ)
        </div>
        
        <div id="attendanceGridContainer"></div>
        <div id="attendanceSummaryContainer"></div>
        
        <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap;">
            <button class="btn btn-sm btn-success" onclick="markAllPresent()">
                <i class="fas fa-check-double"></i> تعليم كل الأيام حضور
            </button>
            <button class="btn btn-sm btn-secondary" onclick="clearAttendance()">
                <i class="fas fa-eraser"></i> مسح الشهر
            </button>
        </div>
    `;
    
    showModal('سجل الحضور والغياب', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
    `, 'lg');
    
    await renderAttendanceGrid();
}

function changeAttendanceMonth(delta) {
    const s = window._attendanceState;
    s.month += delta;
    if (s.month > 11) { s.month = 0; s.year++; }
    if (s.month < 0)  { s.month = 11; s.year--; }
    renderAttendanceGrid();
}

async function renderAttendanceGrid() {
    const { empId, year, month } = window._attendanceState;
    const monthNames = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    
    document.getElementById('attendanceMonthLabel').textContent = `${monthNames[month]} ${year}`;
    
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const records = await getEmployeeAttendanceForMonth(empId, year, month);
    const recordMap = {};
    records.forEach(r => { recordMap[new Date(r.date).getDate()] = r; });
    
    const today = new Date();
    const isCurrentOrPastMonth = (year < today.getFullYear()) ||
        (year === today.getFullYear() && month <= today.getMonth());
    
    const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const shortDayNames = ['أحد', 'إث', 'ثل', 'أر', 'خم', 'جم', 'سب'];
    
    let html = '<div class="attendance-grid">';
    for (let d = 1; d <= daysInMonth; d++) {
        const dayDate = new Date(year, month, d);
        const dayOfWeek = dayDate.getDay();
        const isFriday = dayOfWeek === 5;
        const isFuture = !isCurrentOrPastMonth || (year === today.getFullYear() && month === today.getMonth() && d > today.getDate());
        const record = recordMap[d];
        
        let cls = '';
        if (isFriday) cls = 'friday';
        else if (isFuture) cls = 'future';
        else if (record?.status === 'present') cls = 'present';
        else if (record?.status === 'absent') cls = 'absent';
        
        const clickHandler = (!isFriday && !isFuture) ? `onclick="toggleAttendance(${d})"` : '';
        
        html += `
            <div class="attendance-day ${cls}" ${clickHandler}>
                <div class="day-num">${d}</div>
                <div class="day-name">${shortDayNames[dayOfWeek]}</div>
            </div>
        `;
    }
    html += '</div>';
    
    document.getElementById('attendanceGridContainer').innerHTML = html;
    
    // ملخص
    const calc = await calculateEmployeeSalary(empId, year, month);
    document.getElementById('attendanceSummaryContainer').innerHTML = `
        <div class="attendance-summary">
            <div class="attendance-stat">
                <div class="label">أيام العمل</div>
                <div class="value">${calc.workingDays}</div>
            </div>
            <div class="attendance-stat">
                <div class="label">الحضور</div>
                <div class="value" style="color:#10b981;">${calc.presentDays}</div>
            </div>
            <div class="attendance-stat">
                <div class="label">الغياب</div>
                <div class="value" style="color:#ef4444;">${calc.absentDays}</div>
            </div>
            <div class="attendance-stat">
                <div class="label">خصم الغياب</div>
                <div class="value" style="color:#ef4444;">${formatCurrency(calc.deductions)}</div>
            </div>
            <div class="attendance-stat">
                <div class="label">الصافي</div>
                <div class="value" style="color:#10b981;font-size:16px;">${formatCurrency(calc.netSalary)}</div>
            </div>
        </div>
    `;
}

async function toggleAttendance(day) {
    const { empId, year, month } = window._attendanceState;
    const dateStr = new Date(year, month, day).toISOString();
    const records = await db.getAll('attendance');
    const existing = records.find(r => {
        if (r.employeeId !== empId) return false;
        const d = new Date(r.date);
        return d.getFullYear() === year && d.getMonth() === month && d.getDate() === day;
    });
    
    if (!existing) {
        // لا يوجد سجل: أضف حضور
        await db.add('attendance', { employeeId: empId, date: dateStr, status: 'present' });
    } else if (existing.status === 'present') {
        // حضور -> غياب
        existing.status = 'absent';
        await db.update('attendance', existing);
    } else {
        // غياب -> امسح السجل
        await db.delete('attendance', existing.id);
    }
    
    await renderAttendanceGrid();
}

async function markAllPresent() {
    const { empId, year, month } = window._attendanceState;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();
    const isCurrent = year === today.getFullYear() && month === today.getMonth();
    const maxDay = isCurrent ? today.getDate() : daysInMonth;
    
    const existing = await getEmployeeAttendanceForMonth(empId, year, month);
    const existingMap = {};
    existing.forEach(r => { existingMap[new Date(r.date).getDate()] = r; });
    
    for (let d = 1; d <= maxDay; d++) {
        const dayDate = new Date(year, month, d);
        if (dayDate.getDay() === 5) continue; // تخطي الجمعة
        
        const record = existingMap[d];
        if (record) {
            if (record.status !== 'present') {
                record.status = 'present';
                await db.update('attendance', record);
            }
        } else {
            await db.add('attendance', {
                employeeId: empId,
                date: dayDate.toISOString(),
                status: 'present'
            });
        }
    }
    
    showToast('تم تعليم كل الأيام كحضور');
    await renderAttendanceGrid();
}

async function clearAttendance() {
    confirmAction('هل تريد مسح سجل الحضور لهذا الشهر؟', async () => {
        const { empId, year, month } = window._attendanceState;
        const records = await getEmployeeAttendanceForMonth(empId, year, month);
        for (const r of records) {
            await db.delete('attendance', r.id);
        }
        showToast('تم المسح');
        await renderAttendanceGrid();
    });
}

// ==== السلف ====
async function showAdvanceModal() {
    const employees = (await db.getAll('employees')).filter(e => e.status === 'active');
    const options = employees.map(e => `
        <option value="${e.id}" data-type="${e.salaryType || 'monthly'}" data-base="${e.baseSalary || 0}">
            ${e.name} ${e.salaryType === 'daily' ? '(يومي)' : '(شهري)'} - ${formatCurrency(e.baseSalary || 0)}
        </option>
    `).join('');

    const html = `
        <form id="advance-form" onsubmit="saveAdvance(event)">
            <div class="form-group">
                <label>الموظف <span class="required">*</span></label>
                <select id="adv_employee" required onchange="onAdvEmployeeChange()">
                    <option value="">-- اختر --</option>
                    ${options}
                </select>
                <small id="adv_employee_hint" style="color:var(--text-secondary);font-size:11px;display:block;margin-top:4px;"></small>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0.01" id="adv_amount" required>
                </div>
                <div class="form-group">
                    <label>التاريخ</label>
                    <input type="date" id="adv_date" value="${getTodayString()}">
                </div>
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="adv_notes" rows="2"></textarea>
            </div>
        </form>
    `;
    showModal('إضافة سلفة', html, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('advance-form').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
}

function onAdvEmployeeChange() {
    const select = document.getElementById('adv_employee');
    const hint = document.getElementById('adv_employee_hint');
    if (!select || !hint) return;
    const opt = select.options[select.selectedIndex];
    const type = opt?.dataset.type || '';
    const base = parseFloat(opt?.dataset.base || 0);
    if (type === 'daily') {
        hint.textContent = `موظف براتب يومي (${formatCurrency(base)} / يوم) - ستُخصم السلفة من راتبه`;
        hint.style.color = '#0d9488';
    } else if (type === 'monthly') {
        hint.textContent = `موظف براتب شهري (${formatCurrency(base)}) - ستُخصم السلفة من راتبه`;
        hint.style.color = '#0d9488';
    } else {
        hint.textContent = '';
    }
}

async function saveAdvance(event) {
    event.preventDefault();
    const data = {
        employeeId: document.getElementById('adv_employee').value,
        amount: parseFloat(document.getElementById('adv_amount').value) || 0,
        date: document.getElementById('adv_date').value,
        notes: document.getElementById('adv_notes').value.trim()
    };
    if (!data.employeeId || data.amount <= 0) {
        showToast('املأ الحقول المطلوبة', 'error');
        return;
    }
    try {
        await db.add('advances', { ...data, createdAt: new Date().toISOString() });
        showToast('تم إضافة السلفة');
        closeModal();
        loadEmployees();
    } catch (e) {
        showToast('خطأ', 'error');
    }
}

// ==== صرف الرواتب ====
async function showPayrollModal() {
    const employees = (await db.getAll('employees')).filter(e => e.status === 'active');
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const monthNames = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const period = `${monthNames[month]} ${year}`;
    const periodKey = `${year}-${String(month + 1).padStart(2, '0')}`;

    const rows = await Promise.all(employees.map(async emp => {
        const calc = await calculateEmployeeSalary(emp.id, year, month);
        return `
            <tr>
                <td><input type="checkbox" class="payroll-check" data-id="${emp.id}" data-base="${calc.baseSalary}" data-adv="${calc.totalAdvances}" data-ded="${calc.deductions}" data-earn="${calc.earnedSalary}" data-net="${calc.netSalary}" data-presdays="${calc.presentDays}" data-absdays="${calc.absentDays}" checked></td>
                <td>${emp.name}</td>
                <td>${emp.salaryType === 'monthly' ? 'شهري' : 'يومي'}</td>
                <td>${formatCurrency(calc.baseSalary)}</td>
                <td>${emp.salaryType === 'daily' ? calc.presentDays + ' يوم' : calc.absentDays + ' غياب'}</td>
                <td style="color:#ef4444;">${formatCurrency(calc.deductions + calc.totalAdvances)}</td>
                <td><strong>${formatCurrency(calc.netSalary)}</strong></td>
            </tr>
        `;
    }));

    const html = `
        <p>صرف رواتب شهر <strong>${period}</strong>:</p>
        <div class="table-wrapper" style="max-height:400px;overflow-y:auto;">
            <table>
                <thead><tr>
                    <th>✓</th><th>الموظف</th><th>النوع</th><th>الأساسي</th>
                    <th>الحضور/الغياب</th><th>الخصومات</th><th>الصافي</th>
                </tr></thead>
                <tbody>${rows.join('') || '<tr><td colspan="7" class="text-center">لا يوجد موظفين</td></tr>'}</tbody>
            </table>
        </div>
    `;
    showModal('صرف الرواتب', html, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-success" onclick="processPayroll('${periodKey}', '${period}')">
            <i class="fas fa-check"></i> تأكيد الصرف
        </button>
    `, 'lg');
}

async function processPayroll(periodKey, periodLabel) {
    const checks = document.querySelectorAll('.payroll-check:checked');
    if (!checks.length) {
        showToast('اختر موظف واحد على الأقل', 'warning');
        return;
    }

    let count = 0;
    for (const ch of checks) {
        await db.add('salaryRecords', {
            employeeId: ch.dataset.id,
            period: periodKey,
            periodLabel,
            date: new Date().toISOString().split('T')[0],
            baseSalary: Number(ch.dataset.base),
            advances: Number(ch.dataset.adv),
            deductions: Number(ch.dataset.ded),
            earnedSalary: Number(ch.dataset.earn),
            netAmount: Number(ch.dataset.net),
            presentDays: Number(ch.dataset.presdays || 0),
            absentDays: Number(ch.dataset.absdays || 0),
            createdAt: new Date().toISOString()
        });
        count++;
    }

    showToast(`تم صرف ${count} راتب`);
    closeModal();
    loadEmployees();
}

// ==== قسيمة الراتب PDF ====
async function printPayslip(empId) {
    const emp = await db.get('employees', empId);
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const monthNames = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    const periodLabel = `${monthNames[month]} ${year}`;
    
    const calc = await calculateEmployeeSalary(empId, year, month);
    const advances = (await db.getAll('advances')).filter(a => {
        if (a.employeeId !== empId) return false;
        const d = new Date(a.date);
        return d.getFullYear() === year && d.getMonth() === month;
    });
    
    const advRows = advances.length ? advances.map(a => `
        <tr>
            <td>${formatDate(a.date, false)}</td>
            <td>${a.notes || 'سلفة'}</td>
            <td>${formatCurrency(a.amount)}</td>
        </tr>
    `).join('') : '';
    
    await generatePDFReport({
        title: `قسيمة راتب - ${emp.name}`,
        subtitle: `الفترة: ${periodLabel} • ${emp.position || ''}`,
        filename: `قسيمة_راتب_${emp.name.replace(/[/\\]/g, '_')}_${periodLabel}.pdf`,
        columns: [
            { key: 'item', label: 'البند', width: '60%' },
            { key: 'value', label: 'القيمة', width: '40%' }
        ],
        rows: [
            { item: 'نوع الراتب', value: emp.salaryType === 'monthly' ? 'شهري' : 'يومي' },
            { item: emp.salaryType === 'monthly' ? 'الراتب الأساسي الشهري' : 'سعر اليوم', value: formatCurrency(calc.baseSalary) },
            { item: 'أيام العمل في الشهر (عدا الجمعة)', value: calc.workingDays + ' يوم' },
            { item: 'أيام الحضور', value: calc.presentDays + ' يوم' },
            { item: 'أيام الغياب', value: calc.absentDays + ' يوم' },
            ...(emp.salaryType === 'daily' 
                ? [{ item: 'الراتب المستحق (الحضور × سعر اليوم)', value: formatCurrency(calc.earnedSalary) }]
                : [{ item: 'خصم الغياب', value: formatCurrency(calc.deductions) }]),
            { item: 'إجمالي السلف', value: formatCurrency(calc.totalAdvances) }
        ],
        summary: [
            { label: emp.salaryType === 'monthly' ? 'الراتب بعد خصم الغياب' : 'الراتب المستحق',
              value: formatCurrency(calc.earnedSalary) },
            { label: 'إجمالي الخصومات والسلف', value: formatCurrency(calc.deductions + calc.totalAdvances) },
            { label: 'صافي الراتب', value: formatCurrency(calc.netSalary), highlight: true }
        ],
        extraSections: advRows ? [{
            title: 'تفاصيل السلف خلال الشهر',
            html: `<table style="width:100%;"><thead><tr><th>التاريخ</th><th>البيان</th><th>المبلغ</th></tr></thead><tbody>${advRows}</tbody></table>`
        }] : []
    });
}

// ==== تصدير قائمة الموظفين PDF ====
async function exportEmployees() {
    const employees = await db.getAll('employees');
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    
    const enriched = await Promise.all(employees.map(async emp => {
        const calc = await calculateEmployeeSalary(emp.id, year, month);
        return {
            name: emp.name,
            position: emp.position || '-',
            phone: emp.phone || '-',
            salaryType: emp.salaryType === 'monthly' ? 'شهري' : 'يومي',
            baseSalary: calc.baseSalary,
            presentDays: calc.presentDays,
            absentDays: calc.absentDays,
            netSalary: calc.netSalary,
            status: emp.status === 'inactive' ? 'غير نشط' : 'نشط'
        };
    }));
    
    const total = enriched.reduce((s, e) => s + e.netSalary, 0);
    
    await generatePDFReport({
        title: 'تقرير الموظفين والرواتب',
        subtitle: `الشهر الحالي • عدد الموظفين: ${employees.length}`,
        filename: `تقرير_الموظفين_${getTodayString()}.pdf`,
        columns: [
            { key: 'name', label: 'الاسم', width: '18%' },
            { key: 'position', label: 'المنصب', width: '14%' },
            { key: 'salaryType', label: 'النوع', width: '8%' },
            { key: 'baseSalary', label: 'الأساسي', width: '13%', format: v => formatCurrency(v) },
            { key: 'presentDays', label: 'حضور', width: '7%' },
            { key: 'absentDays', label: 'غياب', width: '7%' },
            { key: 'netSalary', label: 'الصافي', width: '15%', format: v => formatCurrency(v) },
            { key: 'phone', label: 'الهاتف', width: '12%' },
            { key: 'status', label: 'الحالة', width: '6%' }
        ],
        rows: enriched,
        summary: [
            { label: 'عدد الموظفين', value: employees.length },
            { label: 'إجمالي صافي الرواتب', value: formatCurrency(total), highlight: true }
        ]
    });
}

// ==== عرض وحذف السلف لموظف معيّن ====
async function showEmployeeAdvances(empId) {
    const emp = await db.get('employees', empId);
    if (!emp) return;

    const advances = (await db.getAll('advances'))
        .filter(a => a.employeeId === empId)
        .sort((a, b) => new Date(b.date) - new Date(a.date));

    const now = new Date();
    const monthAdvances = advances.filter(a => {
        const d = new Date(a.date);
        return !isNaN(d) && d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    });
    const totalMonth = monthAdvances.reduce((s, a) => s + Number(a.amount || 0), 0);
    const totalAll = advances.reduce((s, a) => s + Number(a.amount || 0), 0);

    const rows = advances.length ? advances.map(a => {
        // إذا كانت السلفة مرتبطة بمصروف، اشرح ذلك
        const fromExpense = a.expenseId ? '<span class="badge badge-info" style="font-size:10px;">من المصروفات</span>' : '';
        return `
            <tr>
                <td>${formatDate(a.date, false)}</td>
                <td>${a.notes || 'سلفة'} ${fromExpense}</td>
                <td style="color:var(--danger);font-weight:700;">${formatCurrency(a.amount)}</td>
                <td>
                    <button class="action-btn delete" onclick="deleteEmployeeAdvance('${a.id}', '${empId}', ${a.expenseId ? `'${a.expenseId}'` : 'null'})" title="حذف">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('') : '<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-secondary);">لا توجد سلف</td></tr>';

    const body = `
        <div class="card" style="background:var(--bg-tertiary);padding:12px;margin-bottom:12px;">
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;">
                <div>
                    <div style="font-size:12px;color:var(--text-secondary);">الموظف</div>
                    <div style="font-weight:700;">${emp.name}</div>
                </div>
                <div>
                    <div style="font-size:12px;color:var(--text-secondary);">سلف الشهر الحالي</div>
                    <div style="font-weight:700;color:var(--danger);">${formatCurrency(totalMonth)}</div>
                </div>
                <div>
                    <div style="font-size:12px;color:var(--text-secondary);">إجمالي كل السلف</div>
                    <div style="font-weight:700;">${formatCurrency(totalAll)}</div>
                </div>
                <div>
                    <div style="font-size:12px;color:var(--text-secondary);">عدد السلف</div>
                    <div style="font-weight:700;">${advances.length}</div>
                </div>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>التاريخ</th>
                        <th>البيان</th>
                        <th>المبلغ</th>
                        <th>إجراء</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;

    showModal(`سلف الموظف: ${emp.name}`, body, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
        <button class="btn btn-primary" onclick="closeModal(); showAdvanceModal();">
            <i class="fas fa-plus"></i> إضافة سلفة
        </button>
    `);
}

async function deleteEmployeeAdvance(advanceId, empId, expenseId) {
    confirmAction('هل تريد حذف هذه السلفة؟ سيتم إعادة احتساب راتب الموظف.', async () => {
        try {
            // احذف السلفة
            await db.delete('advances', advanceId);
            // إذا كانت مرتبطة بمصروف، احذف المصروف أيضاً
            if (expenseId && expenseId !== 'null' && expenseId !== null) {
                try {
                    const exp = await db.get('expenses', expenseId);
                    if (exp) await db.delete('expenses', expenseId);
                } catch (_) {}
            }
            showToast('تم حذف السلفة', 'success');
            // أعد فتح النافذة محدّثة
            await showEmployeeAdvances(empId);
            // وحدّث قائمة الموظفين خلف النافذة
            loadEmployees();
        } catch (e) {
            showToast('خطأ في الحذف: ' + e.message, 'error');
        }
    }, 'حذف سلفة');
}
