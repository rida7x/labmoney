/**
 * نظام المصادقة
 */

const SESSION_KEY = 'alhaytham_session';

function getCurrentUser() {
    try {
        const data = localStorage.getItem(SESSION_KEY);
        return data ? JSON.parse(data) : null;
    } catch (e) {
        return null;
    }
}

function setCurrentUser(user) {
    const sessionUser = { ...user };
    delete sessionUser.password;
    localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
}

function logout() {
    confirmAction('هل تريد تسجيل الخروج؟', () => {
        localStorage.removeItem(SESSION_KEY);
        location.reload();
    }, 'تسجيل الخروج');
}

async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errorEl = document.getElementById('loginError');
    
    errorEl.classList.remove('show');
    
    if (!username || !password) {
        errorEl.textContent = 'يرجى إدخال اسم المستخدم وكلمة المرور';
        errorEl.classList.add('show');
        return;
    }
    
    const users = await db.getAll('users');
    const user = users.find(u => 
        u.username === username && 
        u.password === hashPassword(password) &&
        u.active !== false
    );
    
    if (!user) {
        errorEl.textContent = 'اسم المستخدم أو كلمة المرور غير صحيحة';
        errorEl.classList.add('show');
        return;
    }
    
    setCurrentUser(user);
    showApp();
    showToast(`مرحباً ${user.fullName}`, 'success');
}

function showApp() {
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    
    const user = getCurrentUser();
    if (user) {
        document.getElementById('currentUserName').textContent = user.fullName;
        document.getElementById('currentUserRole').textContent = getRoleLabel(user.role);
    }
}

function getRoleLabel(role) {
    const labels = {
        admin: 'مدير',
        accountant: 'محاسب',
        receptionist: 'استقبال',
        viewer: 'عارض'
    };
    return labels[role] || role;
}

function checkAuth() {
    const user = getCurrentUser();
    if (user) {
        showApp();
        return true;
    } else {
        document.getElementById('loginScreen').classList.remove('hidden');
        document.getElementById('app').classList.add('hidden');
        return false;
    }
}
