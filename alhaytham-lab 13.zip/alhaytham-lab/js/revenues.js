/**
 * إدارة الإيرادات
 */

let currentRevenuePeriod = 'all';
let currentRevenueSearch = '';
let currentRevenueMethod = 'all';
let currentRevenueSort = 'date_desc';

function setRevenueSort(v) { currentRevenueSort = v; loadRevenues(); }

async function renderRevenues() {
    const paymentMethods = await db.getAll('paymentMethods');
    
    const html = `
        <div class="page-header">
            <h2><i class="fas fa-coins"></i> إدارة الإيرادات</h2>
            <button class="btn btn-primary" onclick="showRevenueModal()">
                <i class="fas fa-plus"></i> إيراد جديد
            </button>
        </div>
        
        <div id="revenueStats" class="stats-grid"></div>
        
        <div class="card">
            <div class="toolbar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="revenueSearch" placeholder="بحث عن مريض، وصف..." oninput="onRevenueSearch(this.value)">
                </div>
                <select class="filter-select" id="revenuePeriod" onchange="currentRevenuePeriod = this.value; loadRevenues()">
                    <option value="all">كل الفترات</option>
                    <option value="today">اليوم</option>
                    <option value="yesterday">أمس</option>
                    <option value="week">آخر أسبوع</option>
                    <option value="month">هذا الشهر</option>
                    <option value="year">هذا العام</option>
                </select>
                <select class="filter-select" id="revenueMethodFilter" onchange="currentRevenueMethod = this.value; loadRevenues()">
                    <option value="all">كل طرق الدفع</option>
                    ${paymentMethods.map(m => `<option value="${m.id}">${m.name}</option>`).join('')}
                </select>
                ${buildSortSelect(currentRevenueSort, 'setRevenueSort')}
                <button class="btn btn-secondary" onclick="exportRevenues()">
                    <i class="fas fa-file-export"></i> تصدير
                </button>
            </div>
            
            <div id="revenuesTableContainer"></div>
        </div>
    `;
    
    document.getElementById('content').innerHTML = html;
    loadRevenues();
}

async function loadRevenues() {
    let revenues = await db.getAll('revenues');
    const paymentMethods = await db.getAll('paymentMethods');
    const methodsMap = Object.fromEntries(paymentMethods.map(m => [m.id, m]));
    
    // الفلترة
    if (currentRevenuePeriod !== 'all') {
        revenues = filterByPeriod(revenues, currentRevenuePeriod);
    }
    
    if (currentRevenueMethod !== 'all') {
        revenues = revenues.filter(r => r.paymentMethod === currentRevenueMethod);
    }
    
    if (currentRevenueSearch) {
        const s = currentRevenueSearch.toLowerCase();
        revenues = revenues.filter(r => 
            (r.patientName || '').toLowerCase().includes(s) ||
            (r.description || '').toLowerCase().includes(s) ||
            (r.notes || '').toLowerCase().includes(s)
        );
    }
    
    revenues = sortRecords(revenues, currentRevenueSort);
    
    // الإحصائيات
    const total = sumField(revenues, 'amount');
    const todayTotal = sumField(revenues.filter(r => filterByPeriod([r], 'today').length > 0), 'amount');
    const monthTotal = sumField(revenues.filter(r => filterByPeriod([r], 'month').length > 0), 'amount');
    const avgPerOp = revenues.length > 0 ? total / revenues.length : 0;
    
    document.getElementById('revenueStats').innerHTML = `
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-coins"></i></div>
            <div class="stat-label">إجمالي المعروض</div>
            <div class="stat-value">${formatCurrency(total)}</div>
            <div class="stat-meta">${revenues.length} عملية</div>
        </div>
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-calendar-day"></i></div>
            <div class="stat-label">اليوم</div>
            <div class="stat-value">${formatCurrency(todayTotal)}</div>
        </div>
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
            <div class="stat-label">هذا الشهر</div>
            <div class="stat-value">${formatCurrency(monthTotal)}</div>
        </div>
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-calculator"></i></div>
            <div class="stat-label">متوسط العملية</div>
            <div class="stat-value">${formatCurrency(avgPerOp)}</div>
        </div>
    `;
    
    // الجدول
    const container = document.getElementById('revenuesTableContainer');
    
    if (revenues.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>لا توجد إيرادات</h3>
                <p>ابدأ بإضافة إيراد جديد</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = `
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>المريض / الوصف</th>
                        <th>المبلغ</th>
                        <th>طريقة الدفع</th>
                        <th>التاريخ</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    ${revenues.map(r => {
                        const method = methodsMap[r.paymentMethod];
                        return `
                            <tr>
                                <td>
                                    <div style="font-weight:600;">${r.patientName || '-'}</div>
                                    <div style="font-size:12px;color:var(--text-tertiary);">${r.description || ''}</div>
                                </td>
                                <td style="font-weight:700;color:var(--success);">${formatCurrency(r.amount)}</td>
                                <td>
                                    ${method ? `
                                        <span style="display:inline-flex;align-items:center;gap:6px;color:${method.color};">
                                            <i class="fas ${method.icon}"></i> ${method.name}
                                        </span>
                                    ` : '-'}
                                </td>
                                <td style="white-space:nowrap;font-size:13px;">${formatDate(r.date, true)}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn print" onclick="printReceipt('${r.id}')" title="طباعة">
                                            <i class="fas fa-print"></i>
                                        </button>
                                        <button class="action-btn edit" onclick="showRevenueModal('${r.id}')" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="action-btn delete" onclick="deleteRevenue('${r.id}')" title="حذف">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
}

const onRevenueSearch = debounce((value) => {
    currentRevenueSearch = value;
    loadRevenues();
}, 250);

async function showRevenueModal(id = null) {
    const paymentMethods = await db.getAll('paymentMethods');
    const activeMethods = paymentMethods.filter(m => m.active !== false);
    
    let revenue = null;
    if (id) {
        revenue = await db.get('revenues', id);
    }
    
    const body = `
        <form id="revenueForm" onsubmit="saveRevenue(event, '${id || ''}')">
            <div class="form-row">
                <div class="form-group">
                    <label>اسم المريض <span class="required">*</span></label>
                    <input type="text" id="rev_patient" value="${revenue?.patientName || ''}" required placeholder="مثال: أحمد محمد">
                </div>
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0" id="rev_amount" value="${revenue?.amount || ''}" required placeholder="0.00">
                </div>
            </div>
            
            <div class="form-group">
                <label>نوع الفحص / الوصف</label>
                <input type="text" id="rev_description" value="${revenue?.description || ''}" placeholder="مثال: تحليل دم شامل">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>طريقة الدفع <span class="required">*</span></label>
                    <select id="rev_method" required>
                        <option value="">-- اختر طريقة الدفع --</option>
                        ${activeMethods.map(m => `
                            <option value="${m.id}" ${revenue?.paymentMethod === m.id ? 'selected' : ''}>${m.name}</option>
                        `).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label>التاريخ والوقت</label>
                    <input type="datetime-local" id="rev_date" value="${formatDateTimeInput(revenue?.date)}">
                </div>
            </div>
            
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="rev_notes" placeholder="ملاحظات إضافية...">${revenue?.notes || ''}</textarea>
            </div>
        </form>
    `;
    
    const footer = `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('revenueForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `;
    
    showModal(id ? 'تعديل إيراد' : 'إيراد جديد', body, footer);
}

async function saveRevenue(event, id) {
    event.preventDefault();
    
    const data = {
        patientName: document.getElementById('rev_patient').value.trim(),
        amount: parseFloat(document.getElementById('rev_amount').value),
        description: document.getElementById('rev_description').value.trim(),
        paymentMethod: document.getElementById('rev_method').value,
        date: new Date(document.getElementById('rev_date').value).toISOString(),
        notes: document.getElementById('rev_notes').value.trim()
    };
    
    if (!data.patientName || !data.amount || !data.paymentMethod) {
        showToast('يرجى ملء الحقول المطلوبة', 'error');
        return;
    }
    
    try {
        if (id) {
            const existing = await db.get('revenues', id);
            await db.update('revenues', { ...existing, ...data });
            showToast('تم تعديل الإيراد بنجاح');
        } else {
            await db.add('revenues', data);
            showToast('تم إضافة الإيراد بنجاح');
        }
        closeModal();
        loadRevenues();
    } catch (e) {
        showToast('حدث خطأ: ' + e.message, 'error');
    }
}

function deleteRevenue(id) {
    confirmAction('هل تريد حذف هذا الإيراد؟', async () => {
        await db.delete('revenues', id);
        showToast('تم الحذف بنجاح');
        loadRevenues();
    }, 'حذف الإيراد');
}

async function printReceipt(id) {
    const revenue = await db.get('revenues', id);
    if (!revenue) return;
    
    const settings = await db.get('settings', 'main');
    const methods = await db.getAll('paymentMethods');
    const method = methods.find(m => m.id === revenue.paymentMethod);
    
    const receiptHtml = `
        <div id="printArea" class="receipt">
            <div class="receipt-header">
                <h2>${settings?.labName || 'مختبر الهيثم'}</h2>
                <div>${settings?.labAddress || ''}</div>
                <div>هاتف: ${settings?.labPhone || ''}</div>
            </div>
            <div class="receipt-body">
                <div><span>رقم الإيصال:</span><span>${revenue.id.slice(-8).toUpperCase()}</span></div>
                <div><span>التاريخ:</span><span>${formatDate(revenue.date, true)}</span></div>
                <div><span>المريض:</span><span>${revenue.patientName}</span></div>
                <div><span>الوصف:</span><span>${revenue.description || '-'}</span></div>
                <div><span>طريقة الدفع:</span><span>${method?.name || '-'}</span></div>
                <div style="font-weight:800;font-size:16px;margin-top:8px;">
                    <span>المبلغ:</span><span>${formatCurrency(revenue.amount)}</span>
                </div>
            </div>
            <div class="receipt-footer">
                <div>${settings?.printFooter || ''}</div>
                <div style="margin-top:4px;font-size:10px;">تم الإصدار: ${formatDate(new Date(), true)}</div>
            </div>
        </div>
    `;
    
    showModal('معاينة الإيصال', receiptHtml, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
        <button class="btn btn-primary" onclick="printElement('printArea')">
            <i class="fas fa-print"></i> طباعة
        </button>
    `, 'sm');
}

async function exportRevenues() {
    let revenues = await db.getAll('revenues');
    const methods = await db.getAll('paymentMethods');
    const methodsMap = Object.fromEntries(methods.map(m => [m.id, m.name]));
    
    if (currentRevenuePeriod !== 'all') {
        revenues = filterByPeriod(revenues, currentRevenuePeriod);
    }
    
    // ترتيب من الأحدث
    revenues.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    const totalAmount = revenues.reduce((s, r) => s + Number(r.amount || 0), 0);
    
    // تجميع حسب طريقة الدفع للملخص
    const byMethod = {};
    revenues.forEach(r => {
        const name = methodsMap[r.paymentMethod] || 'غير محدد';
        byMethod[name] = (byMethod[name] || 0) + Number(r.amount || 0);
    });
    const methodRows = Object.entries(byMethod).map(([name, total]) => `
        <tr><td>${name}</td><td>${formatCurrency(total)}</td></tr>
    `).join('');
    
    const periodLabels = {
        all: 'كل الفترات', today: 'اليوم', yesterday: 'أمس',
        week: 'آخر 7 أيام', month: 'هذا الشهر',
        lastMonth: 'الشهر الماضي', year: 'هذه السنة'
    };
    
    await generatePDFReport({
        title: 'تقرير الإيرادات',
        subtitle: `الفترة: ${periodLabels[currentRevenuePeriod] || 'كل الفترات'} • عدد العمليات: ${revenues.length}`,
        filename: `تقرير_الإيرادات_${getTodayString()}.pdf`,
        columns: [
            { key: 'patientName', label: 'اسم المريض', width: '20%' },
            { key: 'description', label: 'الوصف', width: '25%' },
            { key: 'amount', label: 'المبلغ', width: '15%', format: v => formatCurrency(v) },
            { key: 'paymentMethod', label: 'طريقة الدفع', width: '15%', format: v => methodsMap[v] || '-' },
            { key: 'date', label: 'التاريخ', width: '15%', format: v => formatDate(v, false) },
            { key: 'notes', label: 'ملاحظات', width: '10%' }
        ],
        rows: revenues,
        summary: [
            { label: 'عدد العمليات', value: revenues.length },
            { label: 'إجمالي الإيرادات', value: formatCurrency(totalAmount), highlight: true }
        ],
        extraSections: methodRows ? [{
            title: 'تفصيل حسب طريقة الدفع',
            html: `<table style="width:100%;"><thead><tr><th>طريقة الدفع</th><th>المبلغ</th></tr></thead><tbody>${methodRows}</tbody></table>`
        }] : []
    });
}
