/**
 * إدارة المصروفات
 */

let currentExpensePeriod = 'all';
let currentExpenseSearch = '';
let currentExpenseCategory = 'all';
let currentExpenseSort = 'date_desc';
function setExpenseSort(v) { currentExpenseSort = v; loadExpenses(); }

async function renderExpenses() {
    const categories = await db.getAll('expenseCategories');
    
    const html = `
        <div class="page-header">
            <h2><i class="fas fa-receipt"></i> إدارة المصروفات</h2>
            <button class="btn btn-primary" onclick="showExpenseModal()">
                <i class="fas fa-plus"></i> مصروف جديد
            </button>
        </div>
        
        <div id="expenseStats" class="stats-grid"></div>
        
        <div class="card">
            <div class="toolbar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="expenseSearch" placeholder="بحث في المصروفات..." oninput="onExpenseSearch(this.value)">
                </div>
                <select class="filter-select" onchange="currentExpensePeriod = this.value; loadExpenses()">
                    <option value="all">كل الفترات</option>
                    <option value="today">اليوم</option>
                    <option value="week">آخر أسبوع</option>
                    <option value="month">هذا الشهر</option>
                    <option value="year">هذا العام</option>
                </select>
                <select class="filter-select" onchange="currentExpenseCategory = this.value; loadExpenses()">
                    <option value="all">كل التصنيفات</option>
                    ${categories.map(c => `<option value="${c.id}">${c.name}</option>`).join('')}
                </select>
                ${buildSortSelect(currentExpenseSort, 'setExpenseSort')}
                <button class="btn btn-secondary" onclick="exportExpenses()">
                    <i class="fas fa-file-export"></i> تصدير
                </button>
            </div>
            
            <div id="expensesTableContainer"></div>
        </div>
    `;
    
    document.getElementById('content').innerHTML = html;
    loadExpenses();
}

async function loadExpenses() {
    let expenses = await db.getAll('expenses');
    const categories = await db.getAll('expenseCategories');
    const catsMap = Object.fromEntries(categories.map(c => [c.id, c]));
    const employees = await db.getAll('employees');
    const empMap = Object.fromEntries(employees.map(e => [e.id, e]));
    
    if (currentExpensePeriod !== 'all') {
        expenses = filterByPeriod(expenses, currentExpensePeriod);
    }
    
    if (currentExpenseCategory !== 'all') {
        expenses = expenses.filter(e => e.categoryId === currentExpenseCategory);
    }
    
    if (currentExpenseSearch) {
        const s = currentExpenseSearch.toLowerCase();
        expenses = expenses.filter(e => 
            (e.description || '').toLowerCase().includes(s) ||
            (e.notes || '').toLowerCase().includes(s)
        );
    }
    
    expenses = sortRecords(expenses, currentExpenseSort);
    
    const total = sumField(expenses, 'amount');
    const todayTotal = sumField(filterByPeriod(expenses, 'today'), 'amount');
    const monthTotal = sumField(filterByPeriod(expenses, 'month'), 'amount');
    
    // أكثر فئة صرفاً
    const byCategory = groupBy(expenses, 'categoryId');
    let topCategory = { name: '-', amount: 0 };
    for (const [catId, items] of Object.entries(byCategory)) {
        const amt = sumField(items, 'amount');
        if (amt > topCategory.amount) {
            topCategory = { name: catsMap[catId]?.name || 'غير محدد', amount: amt };
        }
    }
    
    document.getElementById('expenseStats').innerHTML = `
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-receipt"></i></div>
            <div class="stat-label">إجمالي المعروض</div>
            <div class="stat-value">${formatCurrency(total)}</div>
            <div class="stat-meta">${expenses.length} عملية</div>
        </div>
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-calendar-day"></i></div>
            <div class="stat-label">اليوم</div>
            <div class="stat-value">${formatCurrency(todayTotal)}</div>
        </div>
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
            <div class="stat-label">هذا الشهر</div>
            <div class="stat-value">${formatCurrency(monthTotal)}</div>
        </div>
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-tags"></i></div>
            <div class="stat-label">أعلى تصنيف</div>
            <div class="stat-value" style="font-size:18px;">${topCategory.name}</div>
            <div class="stat-meta">${formatCurrency(topCategory.amount)}</div>
        </div>
    `;
    
    const container = document.getElementById('expensesTableContainer');
    
    if (expenses.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>لا توجد مصروفات</h3>
                <p>ابدأ بإضافة مصروف جديد</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = `
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>الوصف</th>
                        <th>التصنيف</th>
                        <th>المبلغ</th>
                        <th>التاريخ</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    ${expenses.map(e => {
                        const cat = catsMap[e.categoryId];
                        const linkedEmp = e.employeeId ? empMap[e.employeeId] : null;
                        return `
                            <tr>
                                <td>
                                    <div style="font-weight:600;">${e.description || '-'}</div>
                                    ${linkedEmp ? `<div style="font-size:12px;color:var(--primary);font-weight:600;"><i class="fas fa-user"></i> ${linkedEmp.name}</div>` : ''}
                                    ${e.notes ? `<div style="font-size:12px;color:var(--text-tertiary);">${e.notes}</div>` : ''}
                                </td>
                                <td>
                                    ${cat ? `
                                        <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:${cat.color}20;color:${cat.color};border-radius:12px;font-size:12px;font-weight:600;">
                                            <i class="fas ${cat.icon}"></i> ${cat.name}
                                        </span>
                                    ` : '-'}
                                </td>
                                <td style="font-weight:700;color:var(--danger);">${formatCurrency(e.amount)}</td>
                                <td style="white-space:nowrap;font-size:13px;">${formatDate(e.date, true)}</td>
                                <td>
                                    <div class="table-actions">
                                        <button class="action-btn edit" onclick="showExpenseModal('${e.id}')" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="action-btn delete" onclick="deleteExpense('${e.id}')" title="حذف">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
}

const onExpenseSearch = debounce((value) => {
    currentExpenseSearch = value;
    loadExpenses();
}, 250);

async function showExpenseModal(id = null) {
    const categories = await db.getAll('expenseCategories');
    const employees = (await db.getAll('employees')).filter(e => e.status !== 'inactive');
    
    let expense = null;
    if (id) {
        expense = await db.get('expenses', id);
    }
    
    const body = `
        <form id="expenseForm" onsubmit="saveExpense(event, '${id || ''}')">
            <div class="form-group">
                <label>وصف المصروف <span class="required">*</span></label>
                <input type="text" id="exp_description" value="${expense?.description || ''}" required placeholder="مثال: شراء كواشف">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0" id="exp_amount" value="${expense?.amount || ''}" required>
                </div>
                <div class="form-group">
                    <label>التصنيف <span class="required">*</span></label>
                    <select id="exp_category" required onchange="onExpenseCategoryChange()">
                        <option value="">-- اختر تصنيفاً --</option>
                        ${categories.map(c => `
                            <option value="${c.id}" data-system="${c.system || ''}" ${expense?.categoryId === c.id ? 'selected' : ''}>${c.name}</option>
                        `).join('')}
                    </select>
                </div>
            </div>
            
            <!-- خانة الموظف تظهر فقط لتصنيف سلفة/راتب -->
            <div class="form-group" id="exp_employee_group" style="display:none;">
                <label>الموظف <span class="required">*</span></label>
                <select id="exp_employee" onchange="onExpenseEmployeeChange()">
                    <option value="">-- اختر موظفاً --</option>
                    ${employees.map(e => `
                        <option value="${e.id}" data-type="${e.salaryType || 'monthly'}" data-base="${e.baseSalary || 0}" data-name="${e.name}" ${expense?.employeeId === e.id ? 'selected' : ''}>
                            ${e.name} ${e.salaryType === 'daily' ? '(يومي)' : '(شهري)'} - ${formatCurrency(e.baseSalary || 0)}${e.salaryType === 'daily' ? '/يوم' : ''}
                        </option>
                    `).join('')}
                </select>
                <small id="exp_employee_hint" style="color:var(--text-secondary);font-size:11px;display:block;margin-top:4px;"></small>
                <!-- لوحة تفاصيل الموظف اليومي -->
                <div id="exp_employee_info" style="display:none;margin-top:10px;"></div>
            </div>
            
            <div class="form-group">
                <label>التاريخ والوقت</label>
                <input type="datetime-local" id="exp_date" value="${formatDateTimeInput(expense?.date)}">
            </div>
            
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="exp_notes" placeholder="ملاحظات...">${expense?.notes || ''}</textarea>
            </div>
        </form>
    `;
    
    showModal(id ? 'تعديل مصروف' : 'مصروف جديد', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('expenseForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);

    // فعّل onChange مرّة واحدة عند الفتح لإظهار/إخفاء حقل الموظف إن كان للتعديل
    setTimeout(() => onExpenseCategoryChange(), 50);
}

// إظهار / إخفاء حقل الموظف بناءً على نوع التصنيف
function onExpenseCategoryChange() {
    const select = document.getElementById('exp_category');
    if (!select) return;
    const opt = select.options[select.selectedIndex];
    const system = opt?.dataset.system || '';
    const group = document.getElementById('exp_employee_group');
    const empSelect = document.getElementById('exp_employee');
    const hint = document.getElementById('exp_employee_hint');
    if (!group) return;
    if (system === 'employee_advance' || system === 'salary_payment') {
        group.style.display = '';
        if (empSelect) empSelect.setAttribute('required', 'required');
        if (hint) {
            hint.textContent = system === 'employee_advance'
                ? 'سيتم خصم هذه السلفة من راتب الموظف'
                : 'سيُسجَّل هذا المصروف كصرف راتب للموظف';
        }
        // أعرض تفاصيل الموظف الحالي إن كان مُختاراً
        onExpenseEmployeeChange();
    } else {
        group.style.display = 'none';
        if (empSelect) empSelect.removeAttribute('required');
        const infoEl = document.getElementById('exp_employee_info');
        if (infoEl) infoEl.style.display = 'none';
    }
}

// عند اختيار موظف في نموذج المصروفات، أعرض تفاصيل راتبه (خاصة لليومي)
async function onExpenseEmployeeChange() {
    const select = document.getElementById('exp_employee');
    const infoEl = document.getElementById('exp_employee_info');
    if (!select || !infoEl) return;

    const opt = select.options[select.selectedIndex];
    const empId = opt?.value;
    if (!empId) {
        infoEl.style.display = 'none';
        return;
    }

    const salaryType = opt.dataset.type || 'monthly';
    const baseSalary = parseFloat(opt.dataset.base) || 0;
    const name = opt.dataset.name || '';

    // اجمع البيانات
    const advances = (await db.getAll('advances')).filter(a => a.employeeId === empId);
    const salaryRecords = (await db.getAll('salaryRecords')).filter(s => s.employeeId === empId);
    const attendance = (await db.getAll('attendance')).filter(a => a.employeeId === empId);

    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const monthStart = new Date(year, month, 1);
    const monthEnd = new Date(year, month + 1, 0, 23, 59, 59);

    // سلف الشهر الحالي
    const monthAdvances = advances.filter(a => {
        const d = new Date(a.date);
        return !isNaN(d) && d >= monthStart && d <= monthEnd;
    });
    const totalAdvancesMonth = monthAdvances.reduce((s, a) => s + Number(a.amount || 0), 0);

    // رواتب الشهر المصروفة سابقاً
    const monthSalaryPayments = salaryRecords.filter(r => {
        const d = new Date(r.date);
        return !isNaN(d) && d >= monthStart && d <= monthEnd;
    });
    const totalSalaryPaidMonth = monthSalaryPayments.reduce((s, r) => s + Number(r.netAmount || 0), 0);

    if (salaryType === 'daily') {
        // ===== موظف يومي =====
        // عدد أيام العمل المنقضية في الشهر (عدا الجمعة) حتى اليوم
        const today = new Date();
        today.setHours(23, 59, 59, 999);
        const absentDates = new Set(
            attendance
                .filter(a => a.status === 'absent')
                .map(a => String(a.date).slice(0, 10))
        );

        const daysInMonth = new Date(year, month + 1, 0).getDate();
        let workingDaysPassed = 0;
        let absentDays = 0;

        for (let d = 1; d <= daysInMonth; d++) {
            const date = new Date(year, month, d);
            if (date > today) break;
            if (date.getDay() === 5) continue; // الجمعة
            workingDaysPassed++;
            const dateStr = date.toISOString().split('T')[0];
            if (absentDates.has(dateStr)) absentDays++;
        }

        const presentDays = workingDaysPassed - absentDays;
        const entitledAmount = presentDays * baseSalary;

        // إجمالي ما أخذه الموظف هذا الشهر = السلف + الرواتب المصروفة سابقاً
        const totalTakenMonth = totalAdvancesMonth + totalSalaryPaidMonth;
        const remaining = entitledAmount - totalTakenMonth;

        infoEl.style.display = '';
        infoEl.innerHTML = `
            <div style="background:#0ea5e914;border:1px solid #0ea5e9;border-radius:10px;padding:12px;">
                <div style="font-weight:700;font-size:13px;color:#0369a1;margin-bottom:10px;">
                    <i class="fas fa-calendar-check"></i> ${name} — راتب يومي
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;">
                    <div style="background:#fff;padding:8px;border-radius:6px;">
                        <div style="color:#64748b;font-size:11px;">أيام العمل المنقضية</div>
                        <div style="font-weight:700;color:#0369a1;font-size:15px;margin-top:2px;">${workingDaysPassed} يوم</div>
                    </div>
                    <div style="background:#fff;padding:8px;border-radius:6px;">
                        <div style="color:#64748b;font-size:11px;">أيام الغياب</div>
                        <div style="font-weight:700;color:#dc2626;font-size:15px;margin-top:2px;">${absentDays} يوم</div>
                    </div>
                    <div style="background:#fff;padding:8px;border-radius:6px;">
                        <div style="color:#64748b;font-size:11px;">أيام الحضور</div>
                        <div style="font-weight:700;color:#10b981;font-size:15px;margin-top:2px;">${presentDays} يوم</div>
                    </div>
                    <div style="background:#fff;padding:8px;border-radius:6px;">
                        <div style="color:#64748b;font-size:11px;">المبلغ المستحق (${presentDays}×${baseSalary})</div>
                        <div style="font-weight:700;color:#0369a1;font-size:15px;margin-top:2px;">${formatCurrency(entitledAmount)}</div>
                    </div>
                    <div style="background:#fef3c7;padding:8px;border-radius:6px;border-right:3px solid #f59e0b;">
                        <div style="color:#92400e;font-size:11px;">سلف هذا الشهر</div>
                        <div style="font-weight:700;color:#92400e;font-size:15px;margin-top:2px;">${formatCurrency(totalAdvancesMonth)}</div>
                    </div>
                    <div style="background:#fef3c7;padding:8px;border-radius:6px;border-right:3px solid #f59e0b;">
                        <div style="color:#92400e;font-size:11px;">رواتب صُرفت سابقاً</div>
                        <div style="font-weight:700;color:#92400e;font-size:15px;margin-top:2px;">${formatCurrency(totalSalaryPaidMonth)}</div>
                    </div>
                    <div style="background:${remaining > 0 ? '#d1fae5' : (remaining < 0 ? '#fee2e2' : '#f1f5f9')};padding:8px;border-radius:6px;grid-column:span 2;border-right:3px solid ${remaining > 0 ? '#10b981' : (remaining < 0 ? '#dc2626' : '#64748b')};">
                        <div style="color:${remaining > 0 ? '#047857' : (remaining < 0 ? '#b91c1c' : '#475569')};font-size:11px;">
                            ${remaining > 0 ? 'المستحق المتبقي للصرف' : (remaining < 0 ? '⚠ أخذ أكثر من المستحق بـ:' : 'مسدد بالكامل')}
                        </div>
                        <div style="font-weight:800;color:${remaining > 0 ? '#047857' : (remaining < 0 ? '#b91c1c' : '#475569')};font-size:18px;margin-top:2px;">${formatCurrency(Math.abs(remaining))}</div>
                    </div>
                </div>
                ${remaining > 0 ? `
                    <button type="button" class="btn btn-sm btn-primary" style="margin-top:8px;width:100%;" onclick="document.getElementById('exp_amount').value=${remaining.toFixed(2)};">
                        <i class="fas fa-magic"></i> تعبئة المبلغ المستحق تلقائياً (${formatCurrency(remaining)})
                    </button>
                ` : ''}
            </div>
        `;
    } else {
        // ===== موظف شهري =====
        const remaining = baseSalary - totalAdvancesMonth - totalSalaryPaidMonth;
        infoEl.style.display = '';
        infoEl.innerHTML = `
            <div style="background:#8b5cf614;border:1px solid #8b5cf6;border-radius:10px;padding:12px;">
                <div style="font-weight:700;font-size:13px;color:#7e22ce;margin-bottom:10px;">
                    <i class="fas fa-calendar"></i> ${name} — راتب شهري
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;">
                    <div style="background:#fff;padding:8px;border-radius:6px;">
                        <div style="color:#64748b;font-size:11px;">الراتب الأساسي</div>
                        <div style="font-weight:700;color:#7e22ce;font-size:15px;margin-top:2px;">${formatCurrency(baseSalary)}</div>
                    </div>
                    <div style="background:#fef3c7;padding:8px;border-radius:6px;">
                        <div style="color:#92400e;font-size:11px;">سلف هذا الشهر</div>
                        <div style="font-weight:700;color:#92400e;font-size:15px;margin-top:2px;">${formatCurrency(totalAdvancesMonth)}</div>
                    </div>
                    <div style="background:#fef3c7;padding:8px;border-radius:6px;">
                        <div style="color:#92400e;font-size:11px;">رواتب صُرفت سابقاً</div>
                        <div style="font-weight:700;color:#92400e;font-size:15px;margin-top:2px;">${formatCurrency(totalSalaryPaidMonth)}</div>
                    </div>
                    <div style="background:${remaining > 0 ? '#d1fae5' : '#fee2e2'};padding:8px;border-radius:6px;border-right:3px solid ${remaining > 0 ? '#10b981' : '#dc2626'};">
                        <div style="color:${remaining > 0 ? '#047857' : '#b91c1c'};font-size:11px;">${remaining > 0 ? 'المتبقي للصرف' : '⚠ تجاوز الراتب بـ:'}</div>
                        <div style="font-weight:800;color:${remaining > 0 ? '#047857' : '#b91c1c'};font-size:18px;margin-top:2px;">${formatCurrency(Math.abs(remaining))}</div>
                    </div>
                </div>
                ${remaining > 0 ? `
                    <button type="button" class="btn btn-sm btn-primary" style="margin-top:8px;width:100%;" onclick="document.getElementById('exp_amount').value=${remaining.toFixed(2)};">
                        <i class="fas fa-magic"></i> تعبئة المبلغ المستحق تلقائياً (${formatCurrency(remaining)})
                    </button>
                ` : ''}
            </div>
        `;
    }
}

async function saveExpense(event, id) {
    event.preventDefault();
    
    const categoryId = document.getElementById('exp_category').value;
    const employeeId = document.getElementById('exp_employee')?.value || '';
    
    // اكتشف نوع التصنيف (سلفة / صرف راتب)
    const categories = await db.getAll('expenseCategories');
    const selectedCat = categories.find(c => c.id === categoryId);
    const catSystem = selectedCat?.system || '';
    const isAdvance = catSystem === 'employee_advance';
    const isSalaryPayment = catSystem === 'salary_payment';
    
    const data = {
        description: document.getElementById('exp_description').value.trim(),
        amount: parseFloat(document.getElementById('exp_amount').value),
        categoryId,
        date: new Date(document.getElementById('exp_date').value).toISOString(),
        notes: document.getElementById('exp_notes').value.trim()
    };
    
    if (!data.description || !data.amount || !data.categoryId) {
        showToast('يرجى ملء الحقول المطلوبة', 'error');
        return;
    }
    
    // التحقق من اختيار موظف للتصنيفات التي تتطلب ذلك
    if ((isAdvance || isSalaryPayment) && !employeeId) {
        showToast('يرجى اختيار الموظف', 'error');
        return;
    }
    
    if (isAdvance || isSalaryPayment) {
        data.employeeId = employeeId;
    }
    
    try {
        if (id) {
            const existing = await db.get('expenses', id);
            
            // إذا كان للسجل القديم advanceId أو salaryRecordId مرتبط، احذفها لإعادة إنشائها
            if (existing.advanceId) {
                try { await db.delete('advances', existing.advanceId); } catch(_){}
            }
            if (existing.salaryRecordId) {
                try { await db.delete('salaryRecords', existing.salaryRecordId); } catch(_){}
            }
            
            // أنشئ السجل المرتبط إن لزم
            if (isAdvance) {
                const advanceId = db.generateId();
                await db.add('advances', {
                    id: advanceId,
                    employeeId,
                    amount: data.amount,
                    date: data.date,
                    notes: data.notes || 'مسجَّلة من المصروفات',
                    expenseId: id
                });
                data.advanceId = advanceId;
            } else if (isSalaryPayment) {
                const salaryId = db.generateId();
                const now = new Date(data.date);
                await db.add('salaryRecords', {
                    id: salaryId,
                    employeeId,
                    period: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`,
                    date: data.date,
                    netAmount: data.amount,
                    notes: data.notes || 'مسجَّل من المصروفات',
                    expenseId: id
                });
                data.salaryRecordId = salaryId;
            }
            
            await db.update('expenses', { ...existing, ...data });
            showToast('تم تعديل المصروف بنجاح');
        } else {
            // إنشاء المصروف أولاً للحصول على الـ ID
            data.id = db.generateId();
            
            if (isAdvance) {
                const advanceId = db.generateId();
                await db.add('advances', {
                    id: advanceId,
                    employeeId,
                    amount: data.amount,
                    date: data.date,
                    notes: data.notes || 'مسجَّلة من المصروفات',
                    expenseId: data.id
                });
                data.advanceId = advanceId;
            } else if (isSalaryPayment) {
                const salaryId = db.generateId();
                const now = new Date(data.date);
                await db.add('salaryRecords', {
                    id: salaryId,
                    employeeId,
                    period: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`,
                    date: data.date,
                    netAmount: data.amount,
                    notes: data.notes || 'مسجَّل من المصروفات',
                    expenseId: data.id
                });
                data.salaryRecordId = salaryId;
            }
            
            await db.add('expenses', data);
            showToast(isAdvance ? 'تم تسجيل السلفة وخصمها من راتب الموظف' : (isSalaryPayment ? 'تم تسجيل صرف الراتب' : 'تم إضافة المصروف بنجاح'));
        }
        closeModal();
        loadExpenses();
    } catch (e) {
        showToast('حدث خطأ: ' + e.message, 'error');
    }
}

function deleteExpense(id) {
    confirmAction('هل تريد حذف هذا المصروف؟', async () => {
        const exp = await db.get('expenses', id);
        if (exp?.advanceId) {
            try { await db.delete('advances', exp.advanceId); } catch(_){}
        }
        if (exp?.salaryRecordId) {
            try { await db.delete('salaryRecords', exp.salaryRecordId); } catch(_){}
        }
        await db.delete('expenses', id);
        showToast('تم الحذف بنجاح');
        loadExpenses();
    }, 'حذف المصروف');
}

async function exportExpenses() {
    let expenses = await db.getAll('expenses');
    const categories = await db.getAll('expenseCategories');
    const catsMap = Object.fromEntries(categories.map(c => [c.id, c.name]));
    
    if (currentExpensePeriod !== 'all') {
        expenses = filterByPeriod(expenses, currentExpensePeriod);
    }
    expenses.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    const totalAmount = expenses.reduce((s, e) => s + Number(e.amount || 0), 0);
    
    // تجميع حسب التصنيف
    const byCategory = {};
    expenses.forEach(e => {
        const name = catsMap[e.categoryId] || 'غير محدد';
        byCategory[name] = (byCategory[name] || 0) + Number(e.amount || 0);
    });
    const catRows = Object.entries(byCategory)
        .sort((a, b) => b[1] - a[1])
        .map(([name, total]) => {
            const pct = totalAmount > 0 ? ((total / totalAmount) * 100).toFixed(1) : 0;
            return `<tr><td>${name}</td><td>${formatCurrency(total)}</td><td>${pct}%</td></tr>`;
        }).join('');
    
    const periodLabels = {
        all: 'كل الفترات', today: 'اليوم', yesterday: 'أمس',
        week: 'آخر 7 أيام', month: 'هذا الشهر',
        lastMonth: 'الشهر الماضي', year: 'هذه السنة'
    };
    
    await generatePDFReport({
        title: 'تقرير المصروفات',
        subtitle: `الفترة: ${periodLabels[currentExpensePeriod] || 'كل الفترات'} • عدد المصروفات: ${expenses.length}`,
        filename: `تقرير_المصروفات_${getTodayString()}.pdf`,
        columns: [
            { key: 'description', label: 'البيان', width: '30%' },
            { key: 'categoryId', label: 'التصنيف', width: '20%', format: v => catsMap[v] || '-' },
            { key: 'amount', label: 'المبلغ', width: '18%', format: v => formatCurrency(v) },
            { key: 'date', label: 'التاريخ', width: '17%', format: v => formatDate(v, false) },
            { key: 'notes', label: 'ملاحظات', width: '15%' }
        ],
        rows: expenses,
        summary: [
            { label: 'عدد المصروفات', value: expenses.length },
            { label: 'إجمالي المصروفات', value: formatCurrency(totalAmount), highlight: true }
        ],
        extraSections: catRows ? [{
            title: 'تفصيل حسب التصنيف',
            html: `<table style="width:100%;"><thead><tr><th>التصنيف</th><th>المبلغ</th><th>النسبة</th></tr></thead><tbody>${catRows}</tbody></table>`
        }] : []
    });
}
