// ===== صفحة التقارير الاحترافية =====
// أقسام: نظرة عامة، الإيراد حسب طريقة الدفع، المصروفات حسب التصنيف،
//        الإيرادات والمصروفات، الموظفين، Lab to Lab، الديون والموردين.
// كل قسم يمكن تصديره كـ PDF احترافي.

let reportCharts = {};
let currentReportSection = 'overview';
let currentReportPeriod = 'month';
let currentReportFrom = null;
let currentReportTo = null;

async function renderReports() {
    const content = document.getElementById('content');
    content.innerHTML = `
        <div class="page-header">
            <h2><i class="fas fa-chart-bar"></i> التقارير المالية</h2>
        </div>

        <!-- شريط الفترات -->
        <div class="card" style="padding:14px;margin-bottom:14px;">
            <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
                <label style="font-weight:600;color:var(--text-secondary);">الفترة:</label>
                <select class="form-control" id="reportPeriod" onchange="onReportPeriodChange()" style="min-width:160px;">
                    <option value="today">اليوم</option>
                    <option value="yesterday">أمس</option>
                    <option value="week">آخر 7 أيام</option>
                    <option value="month" selected>هذا الشهر</option>
                    <option value="lastMonth">الشهر الماضي</option>
                    <option value="year">هذه السنة</option>
                    <option value="all">كل الفترات</option>
                    <option value="custom">فترة مخصصة</option>
                </select>
                <input type="date" id="reportFrom" class="form-control" style="display:none;width:auto;" onchange="loadReportSection()">
                <input type="date" id="reportTo" class="form-control" style="display:none;width:auto;" onchange="loadReportSection()">
                <div style="flex:1;"></div>
                <button class="btn btn-primary" onclick="exportCurrentReport()">
                    <i class="fas fa-file-pdf"></i> تصدير PDF
                </button>
            </div>
        </div>

        <!-- شريط الأقسام -->
        <div class="report-tabs" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;overflow-x:auto;-webkit-overflow-scrolling:touch;padding-bottom:4px;">
            ${[
                { id: 'overview', icon: 'fa-chart-pie', label: 'نظرة عامة' },
                { id: 'paymentMethods', icon: 'fa-credit-card', label: 'الإيراد حسب طريقة الدفع' },
                { id: 'expenseCategories', icon: 'fa-tags', label: 'المصروفات حسب التصنيف' },
                { id: 'revenueVsExpense', icon: 'fa-balance-scale', label: 'الإيرادات والمصروفات' },
                { id: 'labToLab', icon: 'fa-flask', label: 'Lab to Lab' },
                { id: 'suppliers', icon: 'fa-truck', label: 'الديون والموردين' },
                { id: 'employees', icon: 'fa-users', label: 'الموظفين والرواتب' },
            ].map(t => `
                <button class="report-tab-btn ${currentReportSection === t.id ? 'active' : ''}" onclick="switchReportSection('${t.id}')" data-section="${t.id}">
                    <i class="fas ${t.icon}"></i> ${t.label}
                </button>
            `).join('')}
        </div>

        <div id="reportContent"></div>
    `;

    // استعادة قيمة الفترة
    document.getElementById('reportPeriod').value = currentReportPeriod;
    onReportPeriodChange(false);

    await loadReportSection();
}

function onReportPeriodChange(reload = true) {
    const period = document.getElementById('reportPeriod').value;
    currentReportPeriod = period;
    const fromEl = document.getElementById('reportFrom');
    const toEl = document.getElementById('reportTo');
    const isCustom = period === 'custom';
    fromEl.style.display = isCustom ? '' : 'none';
    toEl.style.display = isCustom ? '' : 'none';
    if (reload && !isCustom) loadReportSection();
}

function switchReportSection(section) {
    currentReportSection = section;
    document.querySelectorAll('.report-tab-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.section === section);
    });
    loadReportSection();
}

async function getReportData() {
    const period = currentReportPeriod;
    let revenues = await db.getAll('revenues');
    let expenses = await db.getAll('expenses');
    let labSamples = await db.getAll('labToLab');
    let salaries = await db.getAll('salaryRecords');

    if (period === 'custom') {
        const from = document.getElementById('reportFrom').value;
        const to = document.getElementById('reportTo').value;
        if (from && to) {
            const fromDate = new Date(from);
            const toDate = new Date(to);
            toDate.setHours(23, 59, 59, 999);
            const inRange = (item) => {
                const d = new Date(item.date);
                return d >= fromDate && d <= toDate;
            };
            revenues = revenues.filter(inRange);
            expenses = expenses.filter(inRange);
            labSamples = labSamples.filter(inRange);
            salaries = salaries.filter(inRange);
        }
        currentReportFrom = from;
        currentReportTo = to;
    } else if (period !== 'all') {
        revenues = filterByPeriod(revenues, period);
        expenses = filterByPeriod(expenses, period);
        labSamples = filterByPeriod(labSamples, period);
        salaries = filterByPeriod(salaries, period);
    }

    const paymentMethods = await db.getAll('paymentMethods');
    const expenseCategories = await db.getAll('expenseCategories');
    const employees = await db.getAll('employees');
    const suppliers = await db.getAll('suppliers');

    const methodMap = Object.fromEntries(paymentMethods.map(m => [m.id, m.name]));
    const categoryMap = Object.fromEntries(expenseCategories.map(c => [c.id, c.name]));

    return { revenues, expenses, labSamples, salaries, paymentMethods, expenseCategories,
             employees, suppliers, methodMap, categoryMap, period };
}

function getPeriodLabel() {
    const labels = {
        today: 'اليوم', yesterday: 'أمس', week: 'آخر 7 أيام',
        month: 'هذا الشهر', lastMonth: 'الشهر الماضي', year: 'هذه السنة',
        all: 'كل الفترات', custom: `${currentReportFrom || ''} إلى ${currentReportTo || ''}`
    };
    return labels[currentReportPeriod] || '';
}

async function loadReportSection() {
    // أزل المخططات السابقة
    Object.values(reportCharts).forEach(c => { try { c.destroy(); } catch(_) {} });
    reportCharts = {};

    const container = document.getElementById('reportContent');
    if (!container) return;
    container.innerHTML = '<div style="text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:32px;color:var(--primary);"></i><p style="margin-top:10px;color:var(--text-secondary);">جاري التحميل...</p></div>';

    const data = await getReportData();

    switch (currentReportSection) {
        case 'overview': await renderOverviewReport(container, data); break;
        case 'paymentMethods': await renderPaymentMethodsReport(container, data); break;
        case 'expenseCategories': await renderExpenseCategoriesReport(container, data); break;
        case 'revenueVsExpense': await renderRevenueVsExpenseReport(container, data); break;
        case 'labToLab': await renderLabToLabReport(container, data); break;
        case 'suppliers': await renderSuppliersReport(container, data); break;
        case 'employees': await renderEmployeesReport(container, data); break;
    }
}

// ============== 1. نظرة عامة ==============
async function renderOverviewReport(container, data) {
    const totalRevenue = sumField(data.revenues, 'amount');
    const totalLabPaid = sumField(data.labSamples.filter(l => l.paymentStatus === 'paid'), 'price') +
                         sumField(data.labSamples.filter(l => l.paymentStatus === 'partial'), 'paidAmount');
    const totalExpense = sumField(data.expenses, 'amount');
    const totalSalaries = sumField(data.salaries, 'netAmount');
    const grossRevenue = totalRevenue + totalLabPaid;
    const totalCost = totalExpense + totalSalaries;
    const netProfit = grossRevenue - totalCost;
    const margin = grossRevenue > 0 ? ((netProfit / grossRevenue) * 100).toFixed(1) : 0;

    container.innerHTML = `
        <div class="card" style="padding:16px;">
            <h3 style="margin-bottom:14px;color:var(--primary);">
                <i class="fas fa-chart-pie"></i> نظرة عامة • ${getPeriodLabel()}
            </h3>

            <div class="stats-grid" style="margin-bottom:18px;">
                <div class="stat-card revenue">
                    <div class="stat-icon"><i class="fas fa-arrow-trend-up"></i></div>
                    <div class="stat-info">
                        <div class="stat-label">إجمالي الإيرادات</div>
                        <div class="stat-value">${formatCurrency(grossRevenue)}</div>
                        <div class="stat-meta">${data.revenues.length} عملية + Lab to Lab</div>
                    </div>
                </div>
                <div class="stat-card expense">
                    <div class="stat-icon"><i class="fas fa-arrow-trend-down"></i></div>
                    <div class="stat-info">
                        <div class="stat-label">إجمالي المصروفات</div>
                        <div class="stat-value">${formatCurrency(totalCost)}</div>
                        <div class="stat-meta">${data.expenses.length} مصروف + ${data.salaries.length} راتب</div>
                    </div>
                </div>
                <div class="stat-card profit">
                    <div class="stat-icon"><i class="fas fa-sack-dollar"></i></div>
                    <div class="stat-info">
                        <div class="stat-label">صافي الربح</div>
                        <div class="stat-value" style="color:${netProfit >= 0 ? 'var(--success)' : 'var(--danger)'};">
                            ${formatCurrency(netProfit)}
                        </div>
                        <div class="stat-meta">هامش ${margin}%</div>
                    </div>
                </div>
                <div class="stat-card lab">
                    <div class="stat-icon"><i class="fas fa-flask"></i></div>
                    <div class="stat-info">
                        <div class="stat-label">عينات Lab to Lab</div>
                        <div class="stat-value">${data.labSamples.length}</div>
                        <div class="stat-meta">${formatCurrency(sumField(data.labSamples, 'price'))}</div>
                    </div>
                </div>
            </div>

            <div style="position:relative;height:300px;width:100%;margin-top:10px;">
                <canvas id="overviewChart"></canvas>
            </div>
        </div>
    `;

    // مخطط مقارنة (إيرادات vs مصروفات vs صافي)
    setTimeout(() => {
        const canvas = document.getElementById('overviewChart');
        if (!canvas) return;
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        const textColor = isDark ? '#cbd5e1' : '#475569';

        reportCharts.overview = new Chart(canvas, {
            type: 'bar',
            data: {
                labels: ['الإيرادات', 'المصروفات', 'صافي الربح'],
                datasets: [{
                    data: [grossRevenue, totalCost, netProfit],
                    backgroundColor: ['#10b981', '#ef4444', netProfit >= 0 ? '#0d9488' : '#dc2626'],
                    borderRadius: 8,
                    barThickness: 70
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: ctx => formatCurrency(ctx.parsed.y) } }
                },
                scales: {
                    y: { ticks: { color: textColor, callback: v => formatCurrency(v) } },
                    x: { ticks: { color: textColor, font: { family: 'Cairo', size: 13 } } }
                }
            }
        });
    }, 50);
}

// ============== 2. الإيراد حسب طريقة الدفع ==============
async function renderPaymentMethodsReport(container, data) {
    const byMethod = {};
    data.revenues.forEach(r => {
        const name = data.methodMap[r.paymentMethod] || 'غير محدد';
        byMethod[name] = byMethod[name] || { total: 0, count: 0 };
        byMethod[name].total += Number(r.amount || 0);
        byMethod[name].count += 1;
    });
    const total = sumField(data.revenues, 'amount');
    const sorted = Object.entries(byMethod).sort((a, b) => b[1].total - a[1].total);

    const rows = sorted.map(([name, info]) => `
        <tr>
            <td>${name}</td>
            <td>${info.count}</td>
            <td>${formatCurrency(info.total)}</td>
            <td>${total > 0 ? ((info.total / total) * 100).toFixed(1) : 0}%</td>
        </tr>
    `).join('');

    container.innerHTML = `
        <div class="card" style="padding:16px;">
            <h3 style="margin-bottom:14px;color:var(--primary);">
                <i class="fas fa-credit-card"></i> الإيراد حسب طريقة الدفع • ${getPeriodLabel()}
            </h3>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start;" class="report-split">
                <div style="position:relative;height:330px;width:100%;">
                    <canvas id="paymentMethodsChart"></canvas>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>طريقة الدفع</th>
                                <th>عدد العمليات</th>
                                <th>الإجمالي</th>
                                <th>النسبة</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${rows || '<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-secondary);">لا توجد بيانات</td></tr>'}
                        </tbody>
                        ${sorted.length ? `<tfoot><tr style="font-weight:700;background:var(--bg-tertiary);">
                            <td>الإجمالي</td>
                            <td>${data.revenues.length}</td>
                            <td>${formatCurrency(total)}</td>
                            <td>100%</td>
                        </tr></tfoot>` : ''}
                    </table>
                </div>
            </div>
        </div>
    `;

    setTimeout(() => {
        const canvas = document.getElementById('paymentMethodsChart');
        if (!canvas || !sorted.length) return;
        const colors = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#06b6d4', '#ec4899', '#64748b', '#ef4444'];
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

        reportCharts.paymentMethods = new Chart(canvas, {
            type: 'doughnut',
            data: {
                labels: sorted.map(([n]) => n),
                datasets: [{
                    data: sorted.map(([_, info]) => info.total),
                    backgroundColor: colors,
                    borderWidth: 2,
                    borderColor: isDark ? '#1e293b' : '#fff'
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: isDark ? '#cbd5e1' : '#475569', font: { family: 'Cairo', size: 12 }, padding: 10, usePointStyle: true } },
                    tooltip: { callbacks: { label: ctx => `${ctx.label}: ${formatCurrency(ctx.parsed)}` } }
                }
            }
        });
    }, 50);
}

// ============== 3. المصروفات حسب التصنيف ==============
async function renderExpenseCategoriesReport(container, data) {
    const byCategory = {};
    data.expenses.forEach(e => {
        const name = data.categoryMap[e.categoryId] || 'غير محدد';
        byCategory[name] = byCategory[name] || { total: 0, count: 0 };
        byCategory[name].total += Number(e.amount || 0);
        byCategory[name].count += 1;
    });
    const total = sumField(data.expenses, 'amount');
    const sorted = Object.entries(byCategory).sort((a, b) => b[1].total - a[1].total);

    const rows = sorted.map(([name, info]) => `
        <tr>
            <td>${name}</td>
            <td>${info.count}</td>
            <td>${formatCurrency(info.total)}</td>
            <td>${total > 0 ? ((info.total / total) * 100).toFixed(1) : 0}%</td>
        </tr>
    `).join('');

    container.innerHTML = `
        <div class="card" style="padding:16px;">
            <h3 style="margin-bottom:14px;color:var(--primary);">
                <i class="fas fa-tags"></i> المصروفات حسب التصنيف • ${getPeriodLabel()}
            </h3>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start;" class="report-split">
                <div style="position:relative;height:330px;width:100%;">
                    <canvas id="expenseCategoriesChart"></canvas>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>التصنيف</th>
                                <th>عدد المعاملات</th>
                                <th>الإجمالي</th>
                                <th>النسبة</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${rows || '<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-secondary);">لا توجد بيانات</td></tr>'}
                        </tbody>
                        ${sorted.length ? `<tfoot><tr style="font-weight:700;background:var(--bg-tertiary);">
                            <td>الإجمالي</td>
                            <td>${data.expenses.length}</td>
                            <td>${formatCurrency(total)}</td>
                            <td>100%</td>
                        </tr></tfoot>` : ''}
                    </table>
                </div>
            </div>
        </div>
    `;

    setTimeout(() => {
        const canvas = document.getElementById('expenseCategoriesChart');
        if (!canvas || !sorted.length) return;
        const colors = ['#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6', '#06b6d4', '#10b981', '#ec4899', '#64748b'];
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

        reportCharts.expenseCategories = new Chart(canvas, {
            type: 'bar',
            data: {
                labels: sorted.map(([n]) => n),
                datasets: [{
                    data: sorted.map(([_, info]) => info.total),
                    backgroundColor: colors,
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: ctx => formatCurrency(ctx.parsed.x) } }
                },
                scales: {
                    x: { ticks: { color: isDark ? '#cbd5e1' : '#475569', callback: v => formatCurrency(v) } },
                    y: { ticks: { color: isDark ? '#cbd5e1' : '#475569', font: { family: 'Cairo', size: 12 } } }
                }
            }
        });
    }, 50);
}

// ============== 4. الإيرادات والمصروفات (مقارنة يومية) ==============
async function renderRevenueVsExpenseReport(container, data) {
    // تجميع حسب اليوم
    const dailyMap = {};
    data.revenues.forEach(r => {
        const d = (r.date || '').split('T')[0];
        if (!d) return;
        dailyMap[d] = dailyMap[d] || { revenue: 0, expense: 0 };
        dailyMap[d].revenue += Number(r.amount || 0);
    });
    data.expenses.forEach(e => {
        const d = (e.date || '').split('T')[0];
        if (!d) return;
        dailyMap[d] = dailyMap[d] || { revenue: 0, expense: 0 };
        dailyMap[d].expense += Number(e.amount || 0);
    });

    const sortedDates = Object.keys(dailyMap).sort();
    const totalRevenue = sumField(data.revenues, 'amount');
    const totalExpense = sumField(data.expenses, 'amount');
    const net = totalRevenue - totalExpense;

    const rows = sortedDates.map(d => {
        const info = dailyMap[d];
        const dailyNet = info.revenue - info.expense;
        return `
            <tr>
                <td>${formatDate(d, false)}</td>
                <td style="color:var(--success);">${formatCurrency(info.revenue)}</td>
                <td style="color:var(--danger);">${formatCurrency(info.expense)}</td>
                <td style="font-weight:700;color:${dailyNet >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(dailyNet)}</td>
            </tr>
        `;
    }).join('');

    container.innerHTML = `
        <div class="card" style="padding:16px;">
            <h3 style="margin-bottom:14px;color:var(--primary);">
                <i class="fas fa-balance-scale"></i> الإيرادات والمصروفات • ${getPeriodLabel()}
            </h3>

            <div class="stats-grid" style="margin-bottom:18px;">
                <div class="stat-card revenue">
                    <div class="stat-info">
                        <div class="stat-label">إجمالي الإيرادات</div>
                        <div class="stat-value">${formatCurrency(totalRevenue)}</div>
                    </div>
                </div>
                <div class="stat-card expense">
                    <div class="stat-info">
                        <div class="stat-label">إجمالي المصروفات</div>
                        <div class="stat-value">${formatCurrency(totalExpense)}</div>
                    </div>
                </div>
                <div class="stat-card profit">
                    <div class="stat-info">
                        <div class="stat-label">الفرق (صافي)</div>
                        <div class="stat-value" style="color:${net >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(net)}</div>
                    </div>
                </div>
            </div>

            <div style="position:relative;height:320px;width:100%;margin-bottom:18px;">
                <canvas id="rvsChart"></canvas>
            </div>

            <div class="table-wrapper">
                <table class="data-table">
                    <thead><tr><th>التاريخ</th><th>الإيرادات</th><th>المصروفات</th><th>الصافي</th></tr></thead>
                    <tbody>${rows || '<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-secondary);">لا توجد بيانات</td></tr>'}</tbody>
                </table>
            </div>
        </div>
    `;

    setTimeout(() => {
        const canvas = document.getElementById('rvsChart');
        if (!canvas || !sortedDates.length) return;
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

        reportCharts.rvs = new Chart(canvas, {
            type: 'line',
            data: {
                labels: sortedDates.map(d => formatDate(d, false)),
                datasets: [
                    { label: 'الإيرادات', data: sortedDates.map(d => dailyMap[d].revenue),
                      borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.1)',
                      fill: true, tension: 0.35, borderWidth: 2.5, pointRadius: 3 },
                    { label: 'المصروفات', data: sortedDates.map(d => dailyMap[d].expense),
                      borderColor: '#ef4444', backgroundColor: 'rgba(239,68,68,0.1)',
                      fill: true, tension: 0.35, borderWidth: 2.5, pointRadius: 3 },
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                interaction: { intersect: false, mode: 'index' },
                plugins: {
                    legend: { position: 'bottom', labels: { color: isDark ? '#cbd5e1' : '#475569', font: { family: 'Cairo', size: 12 }, usePointStyle: true } },
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${formatCurrency(ctx.parsed.y)}` } }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { color: isDark ? '#cbd5e1' : '#475569', callback: v => formatCurrency(v) } },
                    x: { ticks: { color: isDark ? '#cbd5e1' : '#475569' } }
                }
            }
        });
    }, 50);
}

// ============== 5. Lab to Lab ==============
async function renderLabToLabReport(container, data) {
    const samples = data.labSamples;
    const totalPrice = sumField(samples, 'price');
    const totalPaid = sumField(samples, 'paidAmount');
    const totalRemaining = totalPrice - totalPaid;
    const paid = samples.filter(s => s.paymentStatus === 'paid').length;
    const partial = samples.filter(s => s.paymentStatus === 'partial').length;
    const unpaid = samples.filter(s => s.paymentStatus === 'unpaid').length;

    // تجميع حسب المختبر
    const byLab = {};
    samples.forEach(s => {
        const lab = s.labName || 'غير محدد';
        byLab[lab] = byLab[lab] || { count: 0, price: 0, paid: 0 };
        byLab[lab].count++;
        byLab[lab].price += Number(s.price || 0);
        byLab[lab].paid += Number(s.paidAmount || 0);
    });
    const labRows = Object.entries(byLab).sort((a,b) => b[1].price - a[1].price).map(([lab, info]) => `
        <tr>
            <td>${lab}</td>
            <td>${info.count}</td>
            <td>${formatCurrency(info.price)}</td>
            <td>${formatCurrency(info.paid)}</td>
            <td style="color:${info.price - info.paid > 0 ? 'var(--danger)' : 'var(--success)'};">${formatCurrency(info.price - info.paid)}</td>
        </tr>
    `).join('');

    container.innerHTML = `
        <div class="card" style="padding:16px;">
            <h3 style="margin-bottom:14px;color:var(--primary);">
                <i class="fas fa-flask"></i> تقرير Lab to Lab • ${getPeriodLabel()}
            </h3>

            <div class="stats-grid" style="margin-bottom:18px;">
                <div class="stat-card lab">
                    <div class="stat-info">
                        <div class="stat-label">عدد العينات</div>
                        <div class="stat-value">${samples.length}</div>
                        <div class="stat-meta">${paid} مدفوع • ${partial} جزئي • ${unpaid} غير مدفوع</div>
                    </div>
                </div>
                <div class="stat-card revenue">
                    <div class="stat-info">
                        <div class="stat-label">إجمالي القيمة</div>
                        <div class="stat-value">${formatCurrency(totalPrice)}</div>
                    </div>
                </div>
                <div class="stat-card profit">
                    <div class="stat-info">
                        <div class="stat-label">المدفوع</div>
                        <div class="stat-value">${formatCurrency(totalPaid)}</div>
                    </div>
                </div>
                <div class="stat-card debt">
                    <div class="stat-info">
                        <div class="stat-label">المتبقي</div>
                        <div class="stat-value">${formatCurrency(totalRemaining)}</div>
                    </div>
                </div>
            </div>

            <h4 style="margin:14px 0 10px;color:var(--text-secondary);">تفصيل حسب المختبر</h4>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead><tr><th>المختبر</th><th>عدد العينات</th><th>القيمة</th><th>المدفوع</th><th>المتبقي</th></tr></thead>
                    <tbody>${labRows || '<tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-secondary);">لا توجد بيانات</td></tr>'}</tbody>
                </table>
            </div>
        </div>
    `;
}

// ============== 6. الديون والموردين ==============
async function renderSuppliersReport(container, data) {
    const allInvoices = await db.getAll('supplierInvoices');
    const allPayments = await db.getAll('supplierPayments');

    const rows = data.suppliers.map(s => {
        const invs = allInvoices.filter(i => i.supplierId === s.id);
        const pays = allPayments.filter(p => p.supplierId === s.id);
        const totalDebt = sumField(invs, 'amount');
        const totalPaid = sumField(pays, 'amount');
        const remaining = totalDebt - totalPaid;
        const status = remaining <= 0 ? 'مسدد' : (totalPaid > 0 ? 'جزئي' : 'لم يسدد');
        const color = remaining <= 0 ? 'var(--success)' : (totalPaid > 0 ? 'var(--warning)' : 'var(--danger)');
        return `
            <tr>
                <td>${s.name}</td>
                <td>${s.phone || '-'}</td>
                <td>${invs.length}</td>
                <td>${formatCurrency(totalDebt)}</td>
                <td>${formatCurrency(totalPaid)}</td>
                <td style="color:${color};font-weight:700;">${formatCurrency(remaining)}</td>
                <td><span style="background:${color};color:#fff;padding:3px 10px;border-radius:12px;font-size:11px;">${status}</span></td>
            </tr>
        `;
    }).join('');

    const totalDebt = sumField(allInvoices, 'amount');
    const totalPaid = sumField(allPayments, 'amount');

    container.innerHTML = `
        <div class="card" style="padding:16px;">
            <h3 style="margin-bottom:14px;color:var(--primary);">
                <i class="fas fa-truck"></i> الديون والموردين
            </h3>

            <div class="stats-grid" style="margin-bottom:18px;">
                <div class="stat-card employees"><div class="stat-info">
                    <div class="stat-label">عدد الموردين</div>
                    <div class="stat-value">${data.suppliers.length}</div>
                </div></div>
                <div class="stat-card expense"><div class="stat-info">
                    <div class="stat-label">إجمالي الديون</div>
                    <div class="stat-value">${formatCurrency(totalDebt)}</div>
                </div></div>
                <div class="stat-card profit"><div class="stat-info">
                    <div class="stat-label">المسدد</div>
                    <div class="stat-value">${formatCurrency(totalPaid)}</div>
                </div></div>
                <div class="stat-card debt"><div class="stat-info">
                    <div class="stat-label">المتبقي</div>
                    <div class="stat-value">${formatCurrency(totalDebt - totalPaid)}</div>
                </div></div>
            </div>

            <div class="table-wrapper">
                <table class="data-table">
                    <thead><tr><th>المورد</th><th>الهاتف</th><th>عدد الفواتير</th><th>إجمالي الدين</th><th>المسدد</th><th>المتبقي</th><th>الحالة</th></tr></thead>
                    <tbody>${rows || '<tr><td colspan="7" style="text-align:center;padding:20px;color:var(--text-secondary);">لا يوجد موردين</td></tr>'}</tbody>
                </table>
            </div>
        </div>
    `;
}

// ============== 7. الموظفين والرواتب ==============
async function renderEmployeesReport(container, data) {
    const advances = await db.getAll('advances');
    const totalMonthlySalaries = data.employees
        .filter(e => e.salaryType === 'monthly' && e.status !== 'inactive')
        .reduce((s, e) => s + Number(e.baseSalary || 0), 0);
    const totalPaidSalaries = sumField(data.salaries, 'netAmount');
    const totalAdvances = sumField(advances, 'amount');

    const rows = data.employees.map(e => {
        const empAdv = sumField(advances.filter(a => a.employeeId === e.id), 'amount');
        const empSalaries = sumField(data.salaries.filter(s => s.employeeId === e.id), 'netAmount');
        const statusBadge = e.status === 'inactive'
            ? '<span style="background:var(--danger);color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;">غير نشط</span>'
            : '<span style="background:var(--success);color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;">نشط</span>';
        return `
            <tr>
                <td>${e.name}</td>
                <td>${e.position || '-'}</td>
                <td>${e.salaryType === 'monthly' ? 'شهري' : 'يومي'}</td>
                <td>${formatCurrency(e.baseSalary)}</td>
                <td>${formatCurrency(empAdv)}</td>
                <td>${formatCurrency(empSalaries)}</td>
                <td>${statusBadge}</td>
            </tr>
        `;
    }).join('');

    container.innerHTML = `
        <div class="card" style="padding:16px;">
            <h3 style="margin-bottom:14px;color:var(--primary);">
                <i class="fas fa-users"></i> الموظفين والرواتب • ${getPeriodLabel()}
            </h3>

            <div class="stats-grid" style="margin-bottom:18px;">
                <div class="stat-card employees"><div class="stat-info">
                    <div class="stat-label">عدد الموظفين</div>
                    <div class="stat-value">${data.employees.length}</div>
                </div></div>
                <div class="stat-card revenue"><div class="stat-info">
                    <div class="stat-label">إجمالي الرواتب الشهرية</div>
                    <div class="stat-value">${formatCurrency(totalMonthlySalaries)}</div>
                </div></div>
                <div class="stat-card expense"><div class="stat-info">
                    <div class="stat-label">الرواتب المصروفة</div>
                    <div class="stat-value">${formatCurrency(totalPaidSalaries)}</div>
                </div></div>
                <div class="stat-card debt"><div class="stat-info">
                    <div class="stat-label">إجمالي السلف</div>
                    <div class="stat-value">${formatCurrency(totalAdvances)}</div>
                </div></div>
            </div>

            <div class="table-wrapper">
                <table class="data-table">
                    <thead><tr><th>الاسم</th><th>المنصب</th><th>نوع الراتب</th><th>القيمة</th><th>السلف</th><th>الرواتب المصروفة</th><th>الحالة</th></tr></thead>
                    <tbody>${rows || '<tr><td colspan="7" style="text-align:center;padding:20px;color:var(--text-secondary);">لا يوجد موظفين</td></tr>'}</tbody>
                </table>
            </div>
        </div>
    `;
}

// ============== تصدير القسم الحالي كـ PDF ==============
async function exportCurrentReport() {
    const data = await getReportData();
    const periodLabel = getPeriodLabel();

    switch (currentReportSection) {
        case 'overview':            return exportOverviewPDF(data, periodLabel);
        case 'paymentMethods':      return exportPaymentMethodsPDF(data, periodLabel);
        case 'expenseCategories':   return exportExpenseCategoriesPDF(data, periodLabel);
        case 'revenueVsExpense':    return exportRevenueVsExpensePDF(data, periodLabel);
        case 'labToLab':            return exportLabToLabPDF(data, periodLabel);
        case 'suppliers':           return exportSuppliersPDF(data, periodLabel);
        case 'employees':           return exportEmployeesPDF(data, periodLabel);
    }
}

async function exportOverviewPDF(data, period) {
    const totalRevenue = sumField(data.revenues, 'amount');
    const totalLabPaid = sumField(data.labSamples.filter(l => l.paymentStatus === 'paid'), 'price') +
                         sumField(data.labSamples.filter(l => l.paymentStatus === 'partial'), 'paidAmount');
    const totalExpense = sumField(data.expenses, 'amount');
    const totalSalaries = sumField(data.salaries, 'netAmount');
    const grossRevenue = totalRevenue + totalLabPaid;
    const totalCost = totalExpense + totalSalaries;
    const netProfit = grossRevenue - totalCost;

    await generatePDFReport({
        title: 'التقرير العام (نظرة عامة)',
        subtitle: `الفترة: ${period}`,
        filename: `تقرير_عام_${getTodayString()}.pdf`,
        columns: [
            { key: 'label', label: 'البند', width: '50%' },
            { key: 'value', label: 'القيمة', width: '50%' }
        ],
        rows: [
            { label: 'إجمالي الإيرادات (عيادة)', value: formatCurrency(totalRevenue) },
            { label: 'إيرادات Lab to Lab (المدفوع)', value: formatCurrency(totalLabPaid) },
            { label: 'إجمالي الإيرادات', value: formatCurrency(grossRevenue) },
            { label: 'إجمالي المصروفات', value: formatCurrency(totalExpense) },
            { label: 'إجمالي الرواتب المصروفة', value: formatCurrency(totalSalaries) },
            { label: 'إجمالي التكاليف', value: formatCurrency(totalCost) },
        ],
        summary: [
            { label: 'صافي الربح', value: formatCurrency(netProfit), highlight: true },
            { label: 'هامش الربح', value: grossRevenue > 0 ? `${((netProfit / grossRevenue) * 100).toFixed(1)}%` : '0%' }
        ]
    });
}

async function exportPaymentMethodsPDF(data, period) {
    const byMethod = {};
    data.revenues.forEach(r => {
        const name = data.methodMap[r.paymentMethod] || 'غير محدد';
        byMethod[name] = byMethod[name] || { total: 0, count: 0 };
        byMethod[name].total += Number(r.amount || 0);
        byMethod[name].count += 1;
    });
    const total = sumField(data.revenues, 'amount');
    const rows = Object.entries(byMethod).sort((a, b) => b[1].total - a[1].total).map(([name, info]) => ({
        name,
        count: info.count,
        total: formatCurrency(info.total),
        pct: total > 0 ? `${((info.total / total) * 100).toFixed(1)}%` : '0%'
    }));

    await generatePDFReport({
        title: 'الإيرادات حسب طريقة الدفع',
        subtitle: `الفترة: ${period} • إجمالي العمليات: ${data.revenues.length}`,
        filename: `إيرادات_طرق_دفع_${getTodayString()}.pdf`,
        columns: [
            { key: 'name', label: 'طريقة الدفع', width: '40%' },
            { key: 'count', label: 'عدد العمليات', width: '20%' },
            { key: 'total', label: 'الإجمالي', width: '25%' },
            { key: 'pct', label: 'النسبة', width: '15%' }
        ],
        rows,
        summary: [
            { label: 'إجمالي الإيرادات', value: formatCurrency(total), highlight: true },
            { label: 'عدد العمليات', value: data.revenues.length }
        ]
    });
}

async function exportExpenseCategoriesPDF(data, period) {
    const byCategory = {};
    data.expenses.forEach(e => {
        const name = data.categoryMap[e.categoryId] || 'غير محدد';
        byCategory[name] = byCategory[name] || { total: 0, count: 0 };
        byCategory[name].total += Number(e.amount || 0);
        byCategory[name].count += 1;
    });
    const total = sumField(data.expenses, 'amount');
    const rows = Object.entries(byCategory).sort((a, b) => b[1].total - a[1].total).map(([name, info]) => ({
        name,
        count: info.count,
        total: formatCurrency(info.total),
        pct: total > 0 ? `${((info.total / total) * 100).toFixed(1)}%` : '0%'
    }));

    await generatePDFReport({
        title: 'المصروفات حسب التصنيف',
        subtitle: `الفترة: ${period} • إجمالي المعاملات: ${data.expenses.length}`,
        filename: `مصروفات_تصنيفات_${getTodayString()}.pdf`,
        columns: [
            { key: 'name', label: 'التصنيف', width: '40%' },
            { key: 'count', label: 'عدد المعاملات', width: '20%' },
            { key: 'total', label: 'الإجمالي', width: '25%' },
            { key: 'pct', label: 'النسبة', width: '15%' }
        ],
        rows,
        summary: [
            { label: 'إجمالي المصروفات', value: formatCurrency(total), highlight: true },
            { label: 'عدد المعاملات', value: data.expenses.length }
        ]
    });
}

async function exportRevenueVsExpensePDF(data, period) {
    const dailyMap = {};
    data.revenues.forEach(r => {
        const d = (r.date || '').split('T')[0];
        if (!d) return;
        dailyMap[d] = dailyMap[d] || { revenue: 0, expense: 0 };
        dailyMap[d].revenue += Number(r.amount || 0);
    });
    data.expenses.forEach(e => {
        const d = (e.date || '').split('T')[0];
        if (!d) return;
        dailyMap[d] = dailyMap[d] || { revenue: 0, expense: 0 };
        dailyMap[d].expense += Number(e.amount || 0);
    });
    const sortedDates = Object.keys(dailyMap).sort();
    const totalRevenue = sumField(data.revenues, 'amount');
    const totalExpense = sumField(data.expenses, 'amount');
    const net = totalRevenue - totalExpense;

    const rows = sortedDates.map(d => ({
        date: formatDate(d, false),
        revenue: formatCurrency(dailyMap[d].revenue),
        expense: formatCurrency(dailyMap[d].expense),
        net: formatCurrency(dailyMap[d].revenue - dailyMap[d].expense)
    }));

    await generatePDFReport({
        title: 'الإيرادات والمصروفات (مقارنة يومية)',
        subtitle: `الفترة: ${period}`,
        filename: `ايرادات_مصروفات_${getTodayString()}.pdf`,
        columns: [
            { key: 'date', label: 'التاريخ', width: '25%' },
            { key: 'revenue', label: 'الإيرادات', width: '25%' },
            { key: 'expense', label: 'المصروفات', width: '25%' },
            { key: 'net', label: 'الصافي اليومي', width: '25%' }
        ],
        rows,
        summary: [
            { label: 'إجمالي الإيرادات', value: formatCurrency(totalRevenue) },
            { label: 'إجمالي المصروفات', value: formatCurrency(totalExpense) },
            { label: 'الفرق (صافي)', value: formatCurrency(net), highlight: true }
        ]
    });
}

async function exportLabToLabPDF(data, period) {
    const samples = data.labSamples;
    const byLab = {};
    samples.forEach(s => {
        const lab = s.labName || 'غير محدد';
        byLab[lab] = byLab[lab] || { count: 0, price: 0, paid: 0 };
        byLab[lab].count++;
        byLab[lab].price += Number(s.price || 0);
        byLab[lab].paid += Number(s.paidAmount || 0);
    });
    const rows = Object.entries(byLab).sort((a,b) => b[1].price - a[1].price).map(([lab, info]) => ({
        lab,
        count: info.count,
        price: formatCurrency(info.price),
        paid: formatCurrency(info.paid),
        remaining: formatCurrency(info.price - info.paid)
    }));

    await generatePDFReport({
        title: 'تقرير Lab to Lab',
        subtitle: `الفترة: ${period} • عدد العينات: ${samples.length}`,
        filename: `lab_to_lab_${getTodayString()}.pdf`,
        columns: [
            { key: 'lab', label: 'المختبر', width: '30%' },
            { key: 'count', label: 'العينات', width: '15%' },
            { key: 'price', label: 'القيمة', width: '20%' },
            { key: 'paid', label: 'المدفوع', width: '20%' },
            { key: 'remaining', label: 'المتبقي', width: '15%' }
        ],
        rows,
        summary: [
            { label: 'إجمالي القيمة', value: formatCurrency(sumField(samples, 'price')) },
            { label: 'المدفوع', value: formatCurrency(sumField(samples, 'paidAmount')) },
            { label: 'المتبقي', value: formatCurrency(sumField(samples, 'price') - sumField(samples, 'paidAmount')), highlight: true }
        ]
    });
}

async function exportSuppliersPDF(data, period) {
    const allInvoices = await db.getAll('supplierInvoices');
    const allPayments = await db.getAll('supplierPayments');

    const rows = data.suppliers.map(s => {
        const invs = allInvoices.filter(i => i.supplierId === s.id);
        const pays = allPayments.filter(p => p.supplierId === s.id);
        const totalDebt = sumField(invs, 'amount');
        const totalPaid = sumField(pays, 'amount');
        const remaining = totalDebt - totalPaid;
        const status = remaining <= 0 ? 'مسدد' : (totalPaid > 0 ? 'جزئي' : 'لم يسدد');
        return {
            name: s.name,
            phone: s.phone || '-',
            invoices: invs.length,
            totalDebt: formatCurrency(totalDebt),
            totalPaid: formatCurrency(totalPaid),
            remaining: formatCurrency(remaining),
            status
        };
    });

    const totalDebt = sumField(allInvoices, 'amount');
    const totalPaid = sumField(allPayments, 'amount');

    await generatePDFReport({
        title: 'تقرير الديون والموردين',
        subtitle: `عدد الموردين: ${data.suppliers.length}`,
        filename: `موردين_ديون_${getTodayString()}.pdf`,
        columns: [
            { key: 'name', label: 'المورد', width: '20%' },
            { key: 'phone', label: 'الهاتف', width: '15%' },
            { key: 'invoices', label: 'الفواتير', width: '8%' },
            { key: 'totalDebt', label: 'الدين', width: '15%' },
            { key: 'totalPaid', label: 'المسدد', width: '15%' },
            { key: 'remaining', label: 'المتبقي', width: '15%' },
            { key: 'status', label: 'الحالة', width: '12%' }
        ],
        rows,
        summary: [
            { label: 'إجمالي الديون', value: formatCurrency(totalDebt) },
            { label: 'المسدد', value: formatCurrency(totalPaid) },
            { label: 'المتبقي', value: formatCurrency(totalDebt - totalPaid), highlight: true }
        ]
    });
}

async function exportEmployeesPDF(data, period) {
    const advances = await db.getAll('advances');
    const rows = data.employees.map(e => {
        const empAdv = sumField(advances.filter(a => a.employeeId === e.id), 'amount');
        const empSalaries = sumField(data.salaries.filter(s => s.employeeId === e.id), 'netAmount');
        return {
            name: e.name,
            position: e.position || '-',
            type: e.salaryType === 'monthly' ? 'شهري' : 'يومي',
            base: formatCurrency(e.baseSalary),
            advances: formatCurrency(empAdv),
            paid: formatCurrency(empSalaries),
            status: e.status === 'inactive' ? 'غير نشط' : 'نشط'
        };
    });

    const totalMonthlySalaries = data.employees
        .filter(e => e.salaryType === 'monthly' && e.status !== 'inactive')
        .reduce((s, e) => s + Number(e.baseSalary || 0), 0);

    await generatePDFReport({
        title: 'تقرير الموظفين والرواتب',
        subtitle: `الفترة: ${period} • عدد الموظفين: ${data.employees.length}`,
        filename: `موظفين_رواتب_${getTodayString()}.pdf`,
        columns: [
            { key: 'name', label: 'الاسم', width: '20%' },
            { key: 'position', label: 'المنصب', width: '18%' },
            { key: 'type', label: 'النوع', width: '10%' },
            { key: 'base', label: 'الراتب', width: '14%' },
            { key: 'advances', label: 'السلف', width: '14%' },
            { key: 'paid', label: 'المصروف', width: '14%' },
            { key: 'status', label: 'الحالة', width: '10%' }
        ],
        rows,
        summary: [
            { label: 'إجمالي الرواتب الشهرية', value: formatCurrency(totalMonthlySalaries), highlight: true },
            { label: 'إجمالي الرواتب المصروفة', value: formatCurrency(sumField(data.salaries, 'netAmount')) },
            { label: 'إجمالي السلف', value: formatCurrency(sumField(advances, 'amount')) }
        ]
    });
}
