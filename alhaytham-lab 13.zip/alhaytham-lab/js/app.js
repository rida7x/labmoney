// ===== Main Application Router =====

const PAGE_CONFIG = {
  dashboard: { title: 'لوحة التحكم', render: renderDashboard },
  revenues:  { title: 'الإيرادات',    render: renderRevenues  },
  expenses:  { title: 'المصروفات',    render: renderExpenses  },
  debts:     { title: 'الديون والموردين', render: renderDebts },
  patientDebts: { title: 'ديون المرضى', render: renderPatientDebts },
  contracts: { title: 'التعاقدات', render: renderContracts },
  labtolab:  { title: 'Lab to Lab',  render: renderLabToLab  },
  employees: { title: 'الموظفين والرواتب', render: renderEmployees },
  profitDist:{ title: 'تخصيص الأرباح',  render: renderProfitDistribution },
  reports:   { title: 'التقارير',     render: renderReports   },
  settings:  { title: 'الإعدادات',    render: renderSettings  },
};

let currentPage = 'dashboard';

async function navigateTo(page) {
  if (!PAGE_CONFIG[page]) return;

  const user = getCurrentUser();
  if (user?.role === 'viewer' && page === 'settings') {
    showToast('لا تملك صلاحية الوصول لهذه الصفحة', 'warning');
    return;
  }

  currentPage = page;

  // Update sidebar active state
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === page);
  });

  // Update page title
  const titleEl = document.getElementById('pageTitle');
  if (titleEl) titleEl.textContent = PAGE_CONFIG[page].title;

  // Close mobile sidebar
  const sidebar = document.getElementById('sidebar');
  if (sidebar && window.innerWidth < 992 && sidebar.classList.contains('open')) {
    sidebar.classList.remove('open');
    document.getElementById('sidebarOverlay')?.classList.remove('show');
  }

  // Prepare page content area
  const content = document.getElementById('content');
  if (content) {
    content.innerHTML = '<div class="loading-state"><i class="fa-solid fa-spinner fa-spin"></i><p>جاري التحميل...</p></div>';
  }

  try {
    await PAGE_CONFIG[page].render();
  } catch (e) {
    console.error('Page render error:', e);
    if (content) {
      content.innerHTML = `<div class="error-state"><i class="fa-solid fa-circle-exclamation"></i><p>حدث خطأ: ${e.message}</p></div>`;
    }
  }
}

// Logout: confirm then clear session & restore login screen
function logout() {
  confirmAction('هل تريد تسجيل الخروج؟', () => {
    localStorage.removeItem('alhaytham_session');
    document.getElementById('app').classList.add('hidden');
    document.getElementById('loginScreen').classList.remove('hidden');
    const form = document.getElementById('loginForm');
    if (form) form.reset();
    const errEl = document.getElementById('loginError');
    if (errEl) errEl.textContent = '';
  });
}

// Login handler
async function handleLogin(event) {
  event.preventDefault();
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;
  const errorEl = document.getElementById('loginError');
  errorEl.textContent = '';

  try {
    const users = await db.getAll('users');
    const user = users.find(u => u.username === username && u.active !== false);
    if (!user) {
      errorEl.textContent = 'اسم المستخدم غير صحيح أو الحساب موقوف';
      return;
    }
    if (user.password !== hashPassword(password)) {
      errorEl.textContent = 'كلمة المرور غير صحيحة';
      return;
    }
    setCurrentUser(user);
    await showApp();
    showToast('مرحبًا ' + (user.fullName || user.username), 'success');
  } catch (e) {
    errorEl.textContent = 'حدث خطأ: ' + e.message;
  }
}

async function showApp() {
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');

  const user = getCurrentUser();
  if (user) {
    const nameEl = document.getElementById('currentUserName');
    const roleEl = document.getElementById('currentUserRole');
    if (nameEl) nameEl.textContent = user.fullName || user.username;
    if (roleEl) roleEl.textContent = getRoleLabel(user.role);

    // Hide settings for viewer
    const settingsLink = document.querySelector('[data-page="settings"]');
    if (settingsLink) {
      settingsLink.style.display = user.role === 'viewer' ? 'none' : '';
    }
  }

  await navigateTo('dashboard');
  updateNotificationBadge();
}

async function initApp() {
  try {
    await db.init();
  } catch (e) {
    console.error('DB init failed:', e);
    // محاولة استرداد: حذف وإعادة إنشاء
    try {
      await new Promise((resolve, reject) => {
        const req = indexedDB.deleteDatabase('AlhaythamLabDB');
        req.onsuccess = resolve;
        req.onerror = reject;
      });
      await db.init();
      showToast('تم استرداد قاعدة البيانات بنجاح', 'success');
    } catch (e2) {
      console.error('DB recovery failed:', e2);
      alert('تعذر تهيئة قاعدة البيانات. يرجى مسح بيانات المتصفح والمحاولة مرة أخرى.\n\nالخطأ: ' + (e2.message || e2));
      return;
    }
  }

  try {
    await initializeDefaultData();
  } catch (e) {
    console.warn('Default data init issue (non-fatal):', e);
  }

  initTheme();
  updateCurrentDate();
  setInterval(updateCurrentDate, 60000);

  // Login form
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }

  // Nav items — event delegation on document (more reliable on mobile)
  document.addEventListener('click', (e) => {
    const navItem = e.target.closest('.nav-item');
    if (navItem && navItem.dataset.page) {
      e.preventDefault();
      navigateTo(navItem.dataset.page);
    }
  });

  // Check authentication
  const user = getCurrentUser();
  if (user) {
    await showApp();
  }

  // Periodic notification badge update
  setInterval(updateNotificationBadge, 30000);

  // Set lab name and logo in UI
  await applyLabBranding();
}

// تطبيق اسم وشعار المختبر والألوان المخصصة في الواجهة
async function applyLabBranding() {
  const settings = await db.get('settings', 'main');
  if (!settings) return;
  if (settings.labName) {
    const labNameEl = document.getElementById('labNameDisplay');
    if (labNameEl) labNameEl.textContent = settings.labName;
    document.title = settings.labName;
  }
  const sidebarLogo = document.getElementById('sidebarLabLogo');
  if (sidebarLogo) {
    if (settings.labLogo) {
      sidebarLogo.innerHTML = `<img src="${settings.labLogo}" alt="logo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit;">`;
    } else {
      sidebarLogo.innerHTML = '<i class="fas fa-microscope"></i>';
    }
  }
  // تطبيق ألوان المظهر المخصصة
  if (typeof applyCustomTheme === 'function' && settings.colors) {
    applyCustomTheme(settings.colors);
  }
}

// Start app
document.addEventListener('DOMContentLoaded', initApp);
