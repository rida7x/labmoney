// ===== Lab to Lab — نموذج مبسَّط =====
//
// لكل مختبر شريك:
//   - بيانات أساسية (اسم، هاتف، شخص مسؤول)
//   - "المستحق هذا الشهر" — رقم واحد قابل للتعديل
//   - "اتجاه المستحق" — لنا أو لهم
//   - سجل دفعات (تسديد جزئي أو كلي)
//   - الرصيد المتبقي = المستحق − مجموع الدفعات
//
// عمليات:
//   1. تسجيل المبلغ الشهري المستحق
//   2. تسديد دفعة → إيصال قبض PDF
//   3. كشف حساب شامل PDF
//   4. مطالبة PDF (للجهة المدينة)

let currentLabSearch = '';

async function renderLabToLab() {
    const content = document.getElementById('content');
    content.innerHTML = `
        <div class="page-header">
            <h2><i class="fas fa-flask-vial"></i> Lab to Lab</h2>
            <button class="btn btn-primary" onclick="showLabPartnerModal()">
                <i class="fas fa-plus"></i> مختبر جديد
            </button>
        </div>
        <div id="labStats" class="stats-grid" style="margin-bottom:14px;"></div>
        <div class="card">
            <div class="toolbar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="بحث باسم المختبر..." oninput="onLabSearch(this.value)">
                </div>
                <button class="btn btn-secondary" onclick="exportLabToLabPDF()">
                    <i class="fas fa-file-pdf"></i> تقرير شامل
                </button>
            </div>
            <div id="labPartnersList"></div>
        </div>
    `;
    await loadLabPartners();
}

function onLabSearch(v) { currentLabSearch = v; loadLabPartners(); }

// حسابات الشريك: الرصيد = المستحق - مجموع الدفعات
async function computeLabBalance(partnerId) {
    const partner = await db.get('labPartners', partnerId);
    if (!partner) return null;
    const payments = (await db.getAll('labPayments')).filter(p => p.partnerId === partnerId);
    const due = Number(partner.dueAmount || 0);
    const paid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    const remaining = due - paid;
    return {
        due,
        paid,
        remaining,
        direction: partner.direction || 'theirs_to_us',
        paymentCount: payments.length,
        payments: payments.sort((a, b) => new Date(b.date) - new Date(a.date))
    };
}

async function loadLabPartners() {
    let partners = await db.getAll('labPartners');
    if (currentLabSearch) {
        const s = currentLabSearch.toLowerCase();
        partners = partners.filter(p => (p.name || '').toLowerCase().includes(s));
    }

    const enriched = await Promise.all(partners.map(async p => {
        const b = await computeLabBalance(p.id);
        return { ...p, ...b };
    }));

    // ترتيب حسب المتبقي
    enriched.sort((a, b) => Math.abs(b.remaining) - Math.abs(a.remaining));

    // إحصائيات إجمالية: مجموع المستحق لنا، مجموع المستحق علينا
    let totalLana = 0, totalLahum = 0;
    enriched.forEach(p => {
        if (p.direction === 'theirs_to_us') totalLana += p.remaining;
        else totalLahum += p.remaining;
    });
    const netBalance = totalLana - totalLahum;

    document.getElementById('labStats').innerHTML = `
        <div class="stat-card lab">
            <div class="stat-icon"><i class="fas fa-flask"></i></div>
            <div class="stat-label">عدد المختبرات</div>
            <div class="stat-value">${enriched.length}</div>
        </div>
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-arrow-down"></i></div>
            <div class="stat-label">المتبقي لنا</div>
            <div class="stat-value">${formatCurrency(totalLana)}</div>
        </div>
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-arrow-up"></i></div>
            <div class="stat-label">المتبقي لهم</div>
            <div class="stat-value">${formatCurrency(totalLahum)}</div>
        </div>
        <div class="stat-card profit">
            <div class="stat-icon"><i class="fas fa-balance-scale"></i></div>
            <div class="stat-label">الصافي</div>
            <div class="stat-value" style="color:${netBalance >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(Math.abs(netBalance))}</div>
            <div class="stat-meta">${netBalance >= 0 ? 'لصالحنا' : 'علينا'}</div>
        </div>
    `;

    const container = document.getElementById('labPartnersList');
    if (enriched.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:50px 20px;text-align:center;">
                <i class="fas fa-flask-vial" style="font-size:48px;color:#94a3b8;opacity:0.5;"></i>
                <h3 style="margin-top:12px;">لا توجد مختبرات</h3>
                <p style="color:var(--text-secondary);">اضغط "مختبر جديد" لإضافة شريك Lab to Lab</p>
            </div>
        `;
        return;
    }

    container.innerHTML = enriched.map(p => {
        const isUs = p.direction === 'theirs_to_us';
        const isPaid = p.remaining <= 0;
        const dirLabel = isUs ? 'مستحق لنا' : 'مستحق علينا';
        const dirColor = isUs ? 'var(--success)' : 'var(--warning)';
        const progress = p.due > 0 ? Math.min((p.paid / p.due) * 100, 100) : 0;

        return `
            <div class="lab-card" onclick="showLabPartnerDetails('${p.id}')" style="cursor:pointer;">
                <div class="lab-card-header">
                    <div>
                        <div class="lab-card-title">
                            <i class="fas fa-flask" style="color:var(--primary);"></i> ${p.name}
                        </div>
                        <div style="font-size:13px;color:var(--text-tertiary);margin-top:4px;">
                            ${p.phone ? `<i class="fas fa-phone"></i> ${p.phone} • ` : ''}
                            <i class="fas fa-receipt"></i> ${p.paymentCount} دفعة
                        </div>
                    </div>
                    <span class="status ${isPaid ? 'paid' : (isUs ? 'partial' : 'unpaid')}">
                        ${isPaid ? 'مسدَّد' : dirLabel}
                    </span>
                </div>

                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0;">
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">المستحق الشهري</div>
                        <div style="font-weight:700;color:${dirColor};">${formatCurrency(p.due)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">المسدَّد</div>
                        <div style="font-weight:700;color:var(--success);">${formatCurrency(p.paid)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">المتبقي</div>
                        <div style="font-weight:800;color:${isPaid ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(p.remaining)}</div>
                    </div>
                </div>

                <div style="background:var(--bg-tertiary);border-radius:8px;height:6px;overflow:hidden;">
                    <div style="height:100%;width:${progress}%;background:linear-gradient(to right,var(--success),var(--primary));transition:width 0.5s;"></div>
                </div>

                <div style="display:flex;justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap;">
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        ${p.remaining > 0 ? `
                            <button class="btn btn-sm btn-success" onclick="event.stopPropagation(); showLabPaymentModal('${p.id}')">
                                <i class="fas fa-money-bill-wave"></i> تسديد دفعة
                            </button>
                        ` : ''}
                    </div>
                    <div style="display:flex;gap:6px;">
                        <button class="action-btn print" onclick="event.stopPropagation(); printLabStatement('${p.id}')" title="كشف حساب"><i class="fas fa-file-pdf"></i></button>
                        ${isUs && p.remaining > 0 ? `<button class="action-btn print" onclick="event.stopPropagation(); printLabClaim('${p.id}')" title="مطالبة" style="background:var(--warning-bg);color:var(--warning);"><i class="fas fa-file-invoice-dollar"></i></button>` : ''}
                        <button class="action-btn edit" onclick="event.stopPropagation(); showLabPartnerModal('${p.id}')" title="تعديل"><i class="fas fa-edit"></i></button>
                        <button class="action-btn delete" onclick="event.stopPropagation(); deleteLabPartner('${p.id}')" title="حذف"><i class="fas fa-trash"></i></button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// ============== إضافة / تعديل مختبر ==============
async function showLabPartnerModal(id = null) {
    let p = {
        name: '', phone: '', contactPerson: '', address: '', notes: '',
        dueAmount: 0, direction: 'theirs_to_us', dueMonth: ''
    };
    if (id) {
        const found = await db.get('labPartners', id);
        if (found) p = { ...p, ...found };
    }
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    if (!p.dueMonth) p.dueMonth = currentMonth;

    const body = `
        <form id="lpForm" onsubmit="saveLabPartner(event, '${id || ''}')">
            <div class="form-group">
                <label>اسم المختبر <span class="required">*</span></label>
                <input type="text" id="lp_name" value="${p.name || ''}" required placeholder="مثل: مختبر النور الطبي">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>الشخص المسؤول</label>
                    <input type="text" id="lp_contact" value="${p.contactPerson || ''}">
                </div>
                <div class="form-group">
                    <label>الهاتف</label>
                    <input type="tel" id="lp_phone" value="${p.phone || ''}">
                </div>
            </div>

            <div class="form-group">
                <label>العنوان</label>
                <input type="text" id="lp_address" value="${p.address || ''}">
            </div>

            <hr style="margin:14px 0;border:none;border-top:1px solid var(--border);">

            <h4 style="font-size:14px;margin-bottom:10px;color:var(--primary);"><i class="fas fa-coins"></i> المستحق الشهري</h4>

            <div class="form-row">
                <div class="form-group">
                    <label>اتجاه المستحق <span class="required">*</span></label>
                    <select id="lp_direction" required>
                        <option value="theirs_to_us" ${p.direction === 'theirs_to_us' ? 'selected' : ''}>لنا (يستحق علينا منهم)</option>
                        <option value="ours_to_them" ${p.direction === 'ours_to_them' ? 'selected' : ''}>لهم (نحن مدينون لهم)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0" id="lp_dueAmount" value="${p.dueAmount || 0}" required>
                </div>
            </div>

            <div class="form-group">
                <label>شهر الاستحقاق</label>
                <input type="month" id="lp_dueMonth" value="${p.dueMonth || currentMonth}">
            </div>

            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="lp_notes" rows="2">${p.notes || ''}</textarea>
            </div>

            ${!id ? `
                <div style="background:var(--primary-bg);padding:10px;border-radius:8px;margin-top:10px;font-size:12px;color:var(--text-secondary);">
                    <i class="fas fa-info-circle"></i> بعد الحفظ، يمكنك تسجيل الدفعات تباعاً وتحديث المبلغ الشهري في أي وقت.
                </div>
            ` : ''}
        </form>
    `;

    showModal(id ? 'تعديل مختبر' : 'إضافة مختبر شريك', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('lpForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
}

async function saveLabPartner(event, id) {
    event.preventDefault();
    const data = {
        name: document.getElementById('lp_name').value.trim(),
        contactPerson: document.getElementById('lp_contact').value.trim(),
        phone: document.getElementById('lp_phone').value.trim(),
        address: document.getElementById('lp_address').value.trim(),
        notes: document.getElementById('lp_notes').value.trim(),
        direction: document.getElementById('lp_direction').value,
        dueAmount: parseFloat(document.getElementById('lp_dueAmount').value) || 0,
        dueMonth: document.getElementById('lp_dueMonth').value
    };
    if (!data.name) { showToast('أدخل اسم المختبر', 'error'); return; }
    try {
        if (id) {
            const existing = await db.get('labPartners', id);
            await db.update('labPartners', { ...existing, ...data });
        } else {
            data.createdAt = new Date().toISOString();
            await db.add('labPartners', data);
        }
        showToast('تم الحفظ', 'success');
        closeModal();
        loadLabPartners();
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

function deleteLabPartner(id) {
    confirmAction('هل تريد حذف هذا المختبر؟ ستُحذف معه كل الدفعات.', async () => {
        const payments = (await db.getAll('labPayments')).filter(p => p.partnerId === id);
        for (const p of payments) { try { await db.delete('labPayments', p.id); } catch(_){} }
        await db.delete('labPartners', id);
        showToast('تم الحذف', 'success');
        loadLabPartners();
    }, 'حذف مختبر');
}

// ============== تفاصيل المختبر ==============
async function showLabPartnerDetails(id) {
    const p = await db.get('labPartners', id);
    if (!p) return;
    const b = await computeLabBalance(id);
    const isUs = b.direction === 'theirs_to_us';

    const body = `
        ${p.phone || p.contactPerson || p.address ? `
            <div style="background:var(--bg-tertiary);padding:10px;border-radius:8px;margin-bottom:14px;font-size:13px;">
                ${p.contactPerson ? `<div><i class="fas fa-user"></i> ${p.contactPerson}</div>` : ''}
                ${p.phone ? `<div style="margin-top:4px;"><i class="fas fa-phone"></i> ${p.phone}</div>` : ''}
                ${p.address ? `<div style="margin-top:4px;"><i class="fas fa-location-dot"></i> ${p.address}</div>` : ''}
            </div>
        ` : ''}

        <div style="background:${isUs ? 'var(--success-bg)' : 'var(--warning-bg)'};padding:10px;border-radius:8px;margin-bottom:14px;font-size:13px;text-align:center;">
            <i class="fas fa-${isUs ? 'arrow-down' : 'arrow-up'}"></i>
            <strong>${isUs ? 'المستحق علينا منهم (لنا)' : 'المستحق علينا لهم (لهم)'}</strong>
            ${p.dueMonth ? ` — ${p.dueMonth}` : ''}
        </div>

        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px;">
            <div style="background:var(--bg-tertiary);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--text-tertiary);">المستحق</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;">${formatCurrency(b.due)}</div>
            </div>
            <div style="background:var(--success-bg);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--success);">المسدَّد</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:var(--success);">${formatCurrency(b.paid)}</div>
            </div>
            <div style="background:${b.remaining <= 0 ? 'var(--success-bg)' : 'var(--danger-bg)'};padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:${b.remaining <= 0 ? 'var(--success)' : 'var(--danger)'};">المتبقي</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:${b.remaining <= 0 ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(b.remaining)}</div>
            </div>
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <h4 style="font-size:15px;">سجل الدفعات (${b.paymentCount})</h4>
            ${b.remaining > 0 ? `
                <button class="btn btn-sm btn-success" onclick="closeModal(); setTimeout(() => showLabPaymentModal('${id}'), 200)">
                    <i class="fas fa-plus"></i> تسديد دفعة
                </button>
            ` : ''}
        </div>

        ${b.payments.length === 0 ? `
            <div class="empty-state" style="padding:14px;text-align:center;color:var(--text-secondary);font-size:13px;">لا توجد دفعات بعد</div>
        ` : `
            <div style="max-height:300px;overflow-y:auto;display:flex;flex-direction:column;gap:6px;">
                ${b.payments.map(pay => `
                    <div class="list-item">
                        <div class="list-icon" style="background:var(--success-bg);color:var(--success);">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="list-content">
                            <div class="list-title">${formatCurrency(pay.amount)}</div>
                            <div class="list-meta">
                                ${formatDate(pay.date, false)}
                                ${pay.receiptNumber ? ` • إيصال: ${pay.receiptNumber}` : ''}
                                ${pay.notes ? ` • ${pay.notes}` : ''}
                            </div>
                        </div>
                        <div style="display:flex;gap:6px;">
                            <button class="action-btn print" onclick="printPaymentReceipt('${pay.id}')" title="إيصال قبض"><i class="fas fa-receipt"></i></button>
                            <button class="action-btn edit" onclick="closeModal(); setTimeout(() => showLabPaymentModal('${id}', '${pay.id}'), 200)" title="تعديل"><i class="fas fa-edit"></i></button>
                            <button class="action-btn delete" onclick="deleteLabPayment('${pay.id}', '${id}')" title="حذف"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `}
    `;

    showModal(p.name, body, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
        ${isUs && b.remaining > 0 ? `<button class="btn btn-warning" onclick="printLabClaim('${id}')"><i class="fas fa-file-invoice-dollar"></i> مطالبة</button>` : ''}
        <button class="btn btn-primary" onclick="printLabStatement('${id}')"><i class="fas fa-file-pdf"></i> كشف حساب</button>
    `, 'lg');
}

// ============== تسديد دفعة ==============
async function showLabPaymentModal(partnerId, paymentId = null) {
    const partner = await db.get('labPartners', partnerId);
    const b = await computeLabBalance(partnerId);
    let pay = { amount: 0, date: new Date().toISOString(), receiptNumber: '', notes: '' };
    if (paymentId) {
        const found = await db.get('labPayments', paymentId);
        if (found) pay = found;
    }

    // اقتراح رقم إيصال جديد
    const allPayments = await db.getAll('labPayments');
    const nextReceipt = paymentId ? pay.receiptNumber : `LL-${String(allPayments.length + 1).padStart(4, '0')}`;

    const isUs = b.direction === 'theirs_to_us';

    const body = `
        <div style="background:var(--primary-bg);padding:12px;border-radius:10px;margin-bottom:14px;">
            <div style="font-weight:700;">${partner?.name || ''}</div>
            <div style="font-size:13px;color:var(--text-secondary);margin-top:4px;">
                المستحق: <strong>${formatCurrency(b.due)}</strong> •
                مُسدَّد: <strong style="color:var(--success);">${formatCurrency(b.paid)}</strong> •
                متبقي: <strong style="color:var(--danger);">${formatCurrency(b.remaining)}</strong>
            </div>
            <div style="font-size:12px;color:var(--text-tertiary);margin-top:4px;">
                ${isUs ? 'نستلم دفعة من المختبر' : 'ندفع دفعة للمختبر'}
            </div>
        </div>

        <form id="lpayForm" onsubmit="saveLabPayment(event, '${partnerId}', '${paymentId || ''}')">
            <div class="form-row">
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0.01" id="lpay_amount" value="${pay.amount || ''}" required autofocus>
                </div>
                <div class="form-group">
                    <label>رقم الإيصال</label>
                    <input type="text" id="lpay_receipt" value="${nextReceipt}">
                </div>
            </div>
            <div class="form-group">
                <label>تاريخ الدفعة</label>
                <input type="date" id="lpay_date" value="${pay.date ? String(pay.date).slice(0,10) : getTodayString()}">
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="lpay_notes" rows="2">${pay.notes || ''}</textarea>
            </div>
        </form>
    `;
    showModal(paymentId ? 'تعديل دفعة' : 'تسديد دفعة', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-success" onclick="document.getElementById('lpayForm').requestSubmit()">
            <i class="fas fa-check"></i> ${paymentId ? 'تحديث' : 'تأكيد وإيصال PDF'}
        </button>
    `);
}

async function saveLabPayment(event, partnerId, paymentId) {
    event.preventDefault();
    const data = {
        partnerId,
        amount: parseFloat(document.getElementById('lpay_amount').value) || 0,
        receiptNumber: document.getElementById('lpay_receipt').value.trim(),
        date: new Date(document.getElementById('lpay_date').value).toISOString(),
        notes: document.getElementById('lpay_notes').value.trim()
    };
    if (data.amount <= 0) { showToast('مبلغ غير صحيح', 'error'); return; }
    try {
        let savedId = paymentId;
        if (paymentId) {
            const existing = await db.get('labPayments', paymentId);
            await db.update('labPayments', { ...existing, ...data });
            showToast('تم التعديل', 'success');
        } else {
            const newId = db.generateId();
            data.id = newId;
            savedId = newId;
            await db.add('labPayments', data);
            showToast('تم تسديد الدفعة', 'success');
        }
        closeModal();
        loadLabPartners();
        // اطبع إيصال القبض تلقائياً عند الإضافة
        if (!paymentId) {
            setTimeout(() => printPaymentReceipt(savedId), 400);
        } else {
            setTimeout(() => showLabPartnerDetails(partnerId), 200);
        }
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

async function deleteLabPayment(paymentId, partnerId) {
    confirmAction('هل تريد حذف هذه الدفعة؟', async () => {
        await db.delete('labPayments', paymentId);
        showToast('تم الحذف', 'success');
        closeModal();
        loadLabPartners();
        setTimeout(() => showLabPartnerDetails(partnerId), 200);
    }, 'حذف دفعة');
}

// ============== PDFs ==============

// إيصال قبض احترافي لدفعة واحدة
async function printPaymentReceipt(paymentId) {
    const pay = await db.get('labPayments', paymentId);
    if (!pay) { showToast('الدفعة غير موجودة', 'error'); return; }
    const partner = await db.get('labPartners', pay.partnerId);
    if (!partner) return;
    const b = await computeLabBalance(pay.partnerId);
    const isUs = b.direction === 'theirs_to_us';
    const direction = isUs ? 'من المختبر' : 'إلى المختبر';
    const settings = await db.get('settings', 'main') || {};

    // محتوى إيصال خاص يستخدم نظام التقارير
    await generatePDFReport({
        title: 'إيصال قبض',
        subtitle: `رقم الإيصال: ${pay.receiptNumber || pay.id.slice(-6)} • التاريخ: ${formatDate(pay.date, false)}`,
        filename: `إيصال_قبض_${pay.receiptNumber || pay.id.slice(-6)}.pdf`,
        columns: [
            { key: 'label', label: 'البيان', width: '50%' },
            { key: 'value', label: 'القيمة', width: '50%' }
        ],
        rows: [
            { label: 'استلمنا / دفعنا', value: direction },
            { label: 'اسم المختبر', value: partner.name },
            { label: 'الشخص المسؤول', value: partner.contactPerson || '-' },
            { label: 'الهاتف', value: partner.phone || '-' },
            { label: 'تاريخ الدفعة', value: formatDate(pay.date, false) },
            { label: 'رقم الإيصال', value: pay.receiptNumber || '-' },
            ...(pay.notes ? [{ label: 'ملاحظات', value: pay.notes }] : [])
        ],
        summary: [
            { label: 'المبلغ المستلم/المدفوع', value: formatCurrency(pay.amount), highlight: true },
            { label: 'إجمالي المستحق', value: formatCurrency(b.due) },
            { label: 'إجمالي المسدَّد', value: formatCurrency(b.paid) },
            { label: 'الرصيد المتبقي', value: formatCurrency(b.remaining) }
        ],
        extraSections: [{
            title: 'توقيع المستلم',
            html: `
                <div style="display:flex;justify-content:space-around;margin-top:30px;font-size:12px;">
                    <div style="text-align:center;width:40%;">
                        <div style="border-top:1px solid #333;padding-top:6px;">المستلم</div>
                    </div>
                    <div style="text-align:center;width:40%;">
                        <div style="border-top:1px solid #333;padding-top:6px;">المسلِّم</div>
                    </div>
                </div>
            `
        }]
    });
}

// كشف حساب كامل لمختبر
async function printLabStatement(id) {
    const p = await db.get('labPartners', id);
    if (!p) return;
    const b = await computeLabBalance(id);
    const isUs = b.direction === 'theirs_to_us';

    // بناء جدول الحركات: المستحق ثم الدفعات
    const sorted = [...b.payments].sort((a, b) => new Date(a.date) - new Date(b.date));
    let runningBalance = b.due;
    const rows = [
        {
            date: p.dueMonth ? `شهر ${p.dueMonth}` : '-',
            desc: `قيد المستحق الشهري (${isUs ? 'لنا' : 'لهم'})`,
            amount: formatCurrency(b.due),
            balance: formatCurrency(runningBalance)
        },
        ...sorted.map(pay => {
            runningBalance -= Number(pay.amount || 0);
            return {
                date: formatDate(pay.date, false),
                desc: `دفعة (${pay.receiptNumber || pay.id.slice(-6)})${pay.notes ? ' — ' + pay.notes : ''}`,
                amount: `- ${formatCurrency(pay.amount)}`,
                balance: formatCurrency(runningBalance)
            };
        })
    ];

    await generatePDFReport({
        title: `كشف حساب: ${p.name}`,
        subtitle: `${p.contactPerson ? `المسؤول: ${p.contactPerson} • ` : ''}${p.phone ? `الهاتف: ${p.phone}` : ''}`,
        filename: `كشف_${p.name.replace(/[\/\\]/g, '_')}_${getTodayString()}.pdf`,
        columns: [
            { key: 'date',    label: 'التاريخ',   width: '20%' },
            { key: 'desc',    label: 'البيان',    width: '45%' },
            { key: 'amount',  label: 'المبلغ',    width: '17%' },
            { key: 'balance', label: 'الرصيد',    width: '18%' }
        ],
        rows,
        summary: [
            { label: 'اتجاه الحساب', value: isUs ? 'لنا (نستحق منهم)' : 'لهم (نحن مدينون)' },
            { label: 'إجمالي المستحق', value: formatCurrency(b.due) },
            { label: 'إجمالي المسدَّد', value: formatCurrency(b.paid) },
            { label: 'الرصيد المتبقي', value: formatCurrency(b.remaining), highlight: true }
        ]
    });
}

// مطالبة (للمختبرات التي تدين لنا)
async function printLabClaim(id) {
    const p = await db.get('labPartners', id);
    if (!p) return;
    const b = await computeLabBalance(id);
    if (b.direction !== 'theirs_to_us') {
        showToast('المطالبة تصدر فقط للمختبرات المدينة لنا', 'warning');
        return;
    }
    if (b.remaining <= 0) {
        showToast('لا يوجد متبقي للمطالبة به', 'info');
        return;
    }
    const now = new Date();

    await generatePDFReport({
        title: 'مطالبة مالية',
        subtitle: `إلى السادة: ${p.name}${p.contactPerson ? ` • عناية: ${p.contactPerson}` : ''}`,
        filename: `مطالبة_${p.name.replace(/[\/\\]/g, '_')}_${getTodayString()}.pdf`,
        columns: [
            { key: 'label', label: 'البيان', width: '60%' },
            { key: 'value', label: 'القيمة', width: '40%' }
        ],
        rows: [
            { label: 'تاريخ المطالبة', value: formatDate(now, false) },
            { label: 'الشهر المستحق', value: p.dueMonth || '-' },
            { label: 'إجمالي المبلغ المستحق', value: formatCurrency(b.due) },
            { label: 'المسدَّد حتى تاريخه', value: formatCurrency(b.paid) },
            ...(p.phone ? [{ label: 'الهاتف', value: p.phone }] : []),
            ...(p.address ? [{ label: 'العنوان', value: p.address }] : [])
        ],
        summary: [
            { label: 'المتبقي المطلوب سداده', value: formatCurrency(b.remaining), highlight: true }
        ],
        extraSections: [{
            title: 'نص المطالبة',
            html: `
                <p style="font-size:12px;line-height:1.8;padding:8px;">
                    تحية طيبة وبعد،<br>
                    نتقدم إليكم بهذه المطالبة بسداد المبلغ المتبقي وقدره
                    <strong>${formatCurrency(b.remaining)}</strong>
                    والمستحق علينا منكم نظير الخدمات المقدَّمة.<br>
                    نرجو التكرم بسداد المبلغ في أقرب وقت ممكن.<br><br>
                    ولكم خالص التقدير،
                </p>
            `
        }]
    });
}

// تقرير شامل لكل المختبرات
async function exportLabToLabPDF() {
    const partners = await db.getAll('labPartners');
    if (!partners.length) { showToast('لا توجد مختبرات', 'warning'); return; }
    const enriched = await Promise.all(partners.map(async p => {
        const b = await computeLabBalance(p.id);
        return {
            name: p.name,
            phone: p.phone || '-',
            direction: b.direction === 'theirs_to_us' ? 'لنا' : 'لهم',
            due: formatCurrency(b.due),
            paid: formatCurrency(b.paid),
            remaining: formatCurrency(b.remaining),
            status: b.remaining <= 0 ? 'مسدَّد' : 'مفتوح',
            _due: b.due, _paid: b.paid, _rem: b.remaining, _dir: b.direction
        };
    }));

    const totalDue = enriched.reduce((s, p) => s + p._due, 0);
    const totalPaid = enriched.reduce((s, p) => s + p._paid, 0);
    const totalLana = enriched.filter(p => p._dir === 'theirs_to_us').reduce((s, p) => s + p._rem, 0);
    const totalLahum = enriched.filter(p => p._dir === 'ours_to_them').reduce((s, p) => s + p._rem, 0);

    await generatePDFReport({
        title: 'تقرير Lab to Lab الشامل',
        subtitle: `إجمالي المختبرات: ${partners.length}`,
        filename: `lab_to_lab_${getTodayString()}.pdf`,
        columns: [
            { key: 'name',      label: 'المختبر',    width: '22%' },
            { key: 'phone',     label: 'الهاتف',     width: '14%' },
            { key: 'direction', label: 'الاتجاه',    width: '10%' },
            { key: 'due',       label: 'المستحق',    width: '14%' },
            { key: 'paid',      label: 'المسدَّد',  width: '14%' },
            { key: 'remaining', label: 'المتبقي',    width: '14%' },
            { key: 'status',    label: 'الحالة',     width: '12%' }
        ],
        rows: enriched,
        summary: [
            { label: 'إجمالي المستحقات', value: formatCurrency(totalDue) },
            { label: 'إجمالي المسدَّد', value: formatCurrency(totalPaid) },
            { label: 'المتبقي لنا', value: formatCurrency(totalLana) },
            { label: 'المتبقي لهم', value: formatCurrency(totalLahum) },
            { label: 'صافي الفرق', value: formatCurrency(totalLana - totalLahum), highlight: true }
        ]
    });
}
