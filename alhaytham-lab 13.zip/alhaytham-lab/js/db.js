/**
 * مختبر الهيثم - قاعدة البيانات
 * يستخدم IndexedDB للتخزين المحلي مع إمكانية المزامنة مع Firebase/Supabase لاحقاً
 */

const DB_NAME = 'AlhaythamLabDB';
const DB_VERSION = 7;

const STORES = {
    users: 'users',
    revenues: 'revenues',
    expenses: 'expenses',
    paymentMethods: 'paymentMethods',
    expenseCategories: 'expenseCategories',
    suppliers: 'suppliers',
    supplierInvoices: 'supplierInvoices',
    supplierPayments: 'supplierPayments',
    labPartners: 'labPartners',
    labPayments: 'labPayments',
    employees: 'employees',
    salaryRecords: 'salaryRecords',
    advances: 'advances',
    attendance: 'attendance',
    testCatalog: 'testCatalog',
    profitDistributions: 'profitDistributions',
    profitDistributionConfig: 'profitDistributionConfig',
    patientDebts: 'patientDebts',
    patientPayments: 'patientPayments',
    contracts: 'contracts',
    contractInvoices: 'contractInvoices',
    contractPayments: 'contractPayments',
    settings: 'settings'
};

class Database {
    constructor() {
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onerror = () => {
                console.error('DB open error:', request.error);
                // إذا كان الخطأ بسبب version downgrade أو blocked، حاول الحذف
                if (request.error && (request.error.name === 'VersionError' || request.error.name === 'InvalidStateError')) {
                    console.warn('Version conflict — attempting to recreate DB');
                    const delReq = indexedDB.deleteDatabase(DB_NAME);
                    delReq.onsuccess = () => {
                        // إعادة المحاولة بعد الحذف
                        const retry = indexedDB.open(DB_NAME, DB_VERSION);
                        retry.onsuccess = () => { this.db = retry.result; resolve(this.db); };
                        retry.onerror = () => reject(retry.error);
                        retry.onupgradeneeded = (event) => this._createStores(event.target.result);
                    };
                    delReq.onerror = () => reject(request.error);
                } else {
                    reject(request.error);
                }
            };
            request.onsuccess = () => {
                this.db = request.result;
                this.db.onversionchange = () => { try { this.db.close(); } catch(_){} };
                resolve(this.db);
            };
            request.onblocked = () => {
                console.warn('DB blocked — another tab may be open');
            };
            request.onupgradeneeded = (event) => this._createStores(event.target.result);
        });
    }

    _createStores(db) {
        Object.values(STORES).forEach(storeName => {
            if (!db.objectStoreNames.contains(storeName)) {
                const store = db.createObjectStore(storeName, { keyPath: 'id', autoIncrement: false });
                if (storeName === 'revenues' || storeName === 'expenses') {
                    store.createIndex('date', 'date', { unique: false });
                    store.createIndex('paymentMethod', 'paymentMethod', { unique: false });
                }
                if (storeName === 'employees') {
                    store.createIndex('name', 'name', { unique: false });
                }
            }
        });
    }

    async add(storeName, data) {
        if (!data.id) data.id = this.generateId();
        if (!data.createdAt) data.createdAt = new Date().toISOString();
        data.updatedAt = new Date().toISOString();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.add(data);
            
            request.onsuccess = () => resolve(data);
            request.onerror = () => reject(request.error);
        });
    }

    async update(storeName, data) {
        data.updatedAt = new Date().toISOString();
        
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.put(data);
            
            request.onsuccess = () => resolve(data);
            request.onerror = () => reject(request.error);
        });
    }

    async get(storeName, id) {
        return new Promise((resolve, reject) => {
            try {
                if (!this.db.objectStoreNames.contains(storeName)) {
                    console.warn(`Store "${storeName}" missing in get(${id})`);
                    resolve(null);
                    return;
                }
                const transaction = this.db.transaction(storeName, 'readonly');
                const store = transaction.objectStore(storeName);
                const request = store.get(id);
                request.onsuccess = () => resolve(request.result);
                request.onerror = () => reject(request.error);
            } catch (e) {
                console.error(`get(${storeName},${id}) error:`, e);
                resolve(null);
            }
        });
    }

    async getAll(storeName) {
        return new Promise((resolve, reject) => {
            try {
                // إن لم يكن المخزن موجوداً (قاعدة بيانات قديمة)، أعد مصفوفة فارغة بدل خطأ
                if (!this.db.objectStoreNames.contains(storeName)) {
                    console.warn(`Store "${storeName}" missing — returning empty list`);
                    resolve([]);
                    return;
                }
                const transaction = this.db.transaction(storeName, 'readonly');
                const store = transaction.objectStore(storeName);
                const request = store.getAll();
                request.onsuccess = () => resolve(request.result || []);
                request.onerror = () => reject(request.error);
            } catch (e) {
                console.error(`getAll(${storeName}) error:`, e);
                resolve([]);
            }
        });
    }

    async delete(storeName, id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.delete(id);
            
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    }

    async clear(storeName) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.clear();
            
            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    }

    async getByIndex(storeName, indexName, value) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readonly');
            const store = transaction.objectStore(storeName);
            const index = store.index(indexName);
            const request = index.getAll(value);
            
            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    }

    // تصدير كل البيانات للنسخ الاحتياطي
    async exportAll() {
        const data = {};
        for (const storeName of Object.values(STORES)) {
            data[storeName] = await this.getAll(storeName);
        }
        data.exportedAt = new Date().toISOString();
        data.version = DB_VERSION;
        return data;
    }

    // استيراد بيانات من نسخة احتياطية
    async importAll(data) {
        for (const storeName of Object.values(STORES)) {
            if (data[storeName] && Array.isArray(data[storeName])) {
                await this.clear(storeName);
                for (const item of data[storeName]) {
                    await this.add(storeName, item);
                }
            }
        }
        return true;
    }
}

// إنشاء كائن قاعدة البيانات العام
const db = new Database();

// تهيئة البيانات الأولية والتجريبية
async function initializeDefaultData() {
    // المستخدم الافتراضي
    const users = await db.getAll('users');
    if (users.length === 0) {
        await db.add('users', {
            id: 'user_admin',
            username: 'admin',
            password: hashPassword('admin123'),
            fullName: 'المدير العام',
            role: 'admin',
            permissions: ['all'],
            active: true
        });
        
        await db.add('users', {
            id: 'user_accountant',
            username: 'accountant',
            password: hashPassword('account123'),
            fullName: 'المحاسب',
            role: 'accountant',
            permissions: ['revenues', 'expenses', 'reports'],
            active: true
        });
    }

    // طرق الدفع الافتراضية
    const paymentMethods = await db.getAll('paymentMethods');
    if (paymentMethods.length === 0) {
        const methods = [
            { name: 'كاش', icon: 'fa-money-bill-wave', color: '#10b981', active: true },
            { name: 'بطاقة مصرفية', icon: 'fa-credit-card', color: '#3b82f6', active: true },
            { name: 'يسر باي', icon: 'fa-mobile-alt', color: '#8b5cf6', active: true },
            { name: 'موبي كاش', icon: 'fa-wallet', color: '#f59e0b', active: true },
            { name: 'مصرفي باي', icon: 'fa-university', color: '#06b6d4', active: true }
        ];
        for (const method of methods) {
            await db.add('paymentMethods', method);
        }
    }

    // فئات المصروفات الافتراضية
    const categories = await db.getAll('expenseCategories');
    if (categories.length === 0) {
        const defaultCategories = [
            { name: 'مستلزمات مخبرية', icon: 'fa-flask', color: '#06b6d4' },
            { name: 'كواشف وأدوية', icon: 'fa-prescription-bottle', color: '#8b5cf6' },
            { name: 'إيجار', icon: 'fa-building', color: '#f59e0b' },
            { name: 'كهرباء وماء', icon: 'fa-bolt', color: '#ef4444' },
            { name: 'صيانة', icon: 'fa-tools', color: '#6366f1' },
            { name: 'نظافة', icon: 'fa-broom', color: '#10b981' },
            { name: 'مواصلات', icon: 'fa-car', color: '#ec4899' },
            { name: 'سلفة موظف', icon: 'fa-hand-holding-dollar', color: '#dc2626', system: 'employee_advance' },
            { name: 'صرف راتب', icon: 'fa-money-check-dollar', color: '#16a34a', system: 'salary_payment' },
            { name: 'أخرى', icon: 'fa-ellipsis-h', color: '#64748b' }
        ];
        for (const cat of defaultCategories) {
            await db.add('expenseCategories', cat);
        }
    } else {
        // إضافة الفئات النظامية للمستخدمين القدامى إن لم تكن موجودة
        const hasAdvance = categories.some(c => c.system === 'employee_advance' || c.name === 'سلفة موظف');
        const hasSalary = categories.some(c => c.system === 'salary_payment' || c.name === 'صرف راتب');
        if (!hasAdvance) {
            await db.add('expenseCategories', { name: 'سلفة موظف', icon: 'fa-hand-holding-dollar', color: '#dc2626', system: 'employee_advance' });
        }
        if (!hasSalary) {
            await db.add('expenseCategories', { name: 'صرف راتب', icon: 'fa-money-check-dollar', color: '#16a34a', system: 'salary_payment' });
        }
    }

    // إضافة store المخزون والإعدادات المخزنية للمنشآت القديمة
    // (يتم إنشاء الـ stores تلقائيًا عبر DB_VERSION upgrade)

    // الإعدادات الافتراضية
    const settings = await db.get('settings', 'main');
    if (!settings) {
        await db.add('settings', {
            id: 'main',
            labName: 'مختبر الهيثم للتحاليل الطبية',
            labAddress: 'طرابلس - ليبيا',
            labPhone: '+218-21-XXXXXXX',
            labLogo: '',
            currency: 'د.ل',
            currencyCode: 'LYD',
            taxRate: 0,
            theme: 'light',
            language: 'ar',
            backupEnabled: true,
            printHeader: 'مختبر الهيثم للتحاليل الطبية',
            printFooter: '',
            colors: {
                primary: '#0d9488',
                primaryDark: '#0f766e',
                secondary: '#8b5cf6',
                success: '#10b981',
                danger: '#ef4444',
                warning: '#f59e0b',
                info: '#0ea5e9'
            }
        });
    } else {
        // Migrations on existing installs
        let needsUpdate = false;
        if (settings.printFooter && settings.printFooter.includes('شكر')) {
            settings.printFooter = '';
            needsUpdate = true;
        }
        if (!settings.colors) {
            settings.colors = {
                primary: '#0d9488',
                primaryDark: '#0f766e',
                secondary: '#8b5cf6',
                success: '#10b981',
                danger: '#ef4444',
                warning: '#f59e0b',
                info: '#0ea5e9'
            };
            needsUpdate = true;
        }
        if (needsUpdate) await db.update('settings', settings);
    }

    // بيانات تجريبية
    const revenues = await db.getAll('revenues');
    if (revenues.length === 0) {
        await seedSampleData();
    }

    // كتالوج التحاليل الافتراضي
    const testCatalog = await db.getAll('testCatalog');
    if (testCatalog.length === 0) {
        const defaultTests = [
            { name: 'CBC - تحليل دم شامل', price: 25, category: 'دم', notes: '' },
            { name: 'Blood Sugar - السكر', price: 15, category: 'كيمياء حيوية', notes: '' },
            { name: 'Cholesterol - الكوليسترول', price: 20, category: 'كيمياء حيوية', notes: '' },
            { name: 'Liver Function - وظائف الكبد', price: 50, category: 'كيمياء حيوية', notes: '' },
            { name: 'Kidney Function - وظائف الكلى', price: 45, category: 'كيمياء حيوية', notes: '' },
            { name: 'Urine Analysis - تحليل البول', price: 10, category: 'بول', notes: '' },
            { name: 'Stool Analysis - تحليل البراز', price: 12, category: 'براز', notes: '' },
            { name: 'Thyroid - هرمونات الغدة', price: 80, category: 'هرمونات', notes: '' },
            { name: 'Vitamin D - فيتامين د', price: 60, category: 'فيتامينات', notes: '' },
        ];
        for (const t of defaultTests) {
            await db.add('testCatalog', t);
        }
    }
}

// كلمة مرور مشفرة بطريقة بسيطة (للإنتاج استخدم bcrypt على السيرفر)
function hashPassword(password) {
    let hash = 0;
    const str = password + 'alhaytham_salt_2024';
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash |= 0;
    }
    return 'h_' + Math.abs(hash).toString(36) + '_' + str.length;
}

// بيانات تجريبية للاختبار
async function seedSampleData() {
    const today = new Date();
    const methods = await db.getAll('paymentMethods');
    const categories = await db.getAll('expenseCategories');
    
    // الإيرادات التجريبية
    const sampleRevenues = [
        { patient: 'أحمد محمد علي', tests: 'تحليل دم شامل', amount: 85, method: methods[0]?.id, daysAgo: 0 },
        { patient: 'فاطمة عبدالله', tests: 'فحص السكر والكوليسترول', amount: 120, method: methods[1]?.id, daysAgo: 0 },
        { patient: 'محمد سالم', tests: 'تحليل وظائف الكبد', amount: 150, method: methods[0]?.id, daysAgo: 1 },
        { patient: 'عائشة الفيتوري', tests: 'تحليل هرمونات الغدة', amount: 200, method: methods[2]?.id, daysAgo: 1 },
        { patient: 'علي الترهوني', tests: 'فحص فيتامين D', amount: 95, method: methods[3]?.id, daysAgo: 2 },
        { patient: 'خديجة قنفود', tests: 'تحليل حمل', amount: 65, method: methods[0]?.id, daysAgo: 2 },
        { patient: 'يوسف الزروق', tests: 'فحص الغدة الدرقية', amount: 180, method: methods[1]?.id, daysAgo: 3 },
        { patient: 'مريم العياط', tests: 'تحليل بول كامل', amount: 45, method: methods[0]?.id, daysAgo: 3 },
        { patient: 'إبراهيم الفاسي', tests: 'فحص كورونا PCR', amount: 250, method: methods[4]?.id, daysAgo: 4 },
        { patient: 'زينب أبوحجر', tests: 'تحليل وظائف الكلى', amount: 130, method: methods[2]?.id, daysAgo: 5 },
        { patient: 'عمر الفقيه', tests: 'فحص دهون كامل', amount: 110, method: methods[0]?.id, daysAgo: 7 },
        { patient: 'سارة الحضيري', tests: 'تحليل هيموجلوبين', amount: 55, method: methods[1]?.id, daysAgo: 10 }
    ];
    
    for (const r of sampleRevenues) {
        const date = new Date(today);
        date.setDate(date.getDate() - r.daysAgo);
        await db.add('revenues', {
            patientName: r.patient,
            description: r.tests,
            amount: r.amount,
            paymentMethod: r.method,
            date: date.toISOString(),
            notes: ''
        });
    }
    
    // مصروفات تجريبية
    const sampleExpenses = [
        { desc: 'شراء كواشف تحاليل', amount: 850, cat: categories[1]?.id, daysAgo: 1 },
        { desc: 'فاتورة الكهرباء الشهرية', amount: 320, cat: categories[3]?.id, daysAgo: 3 },
        { desc: 'صيانة جهاز تحليل الدم', amount: 450, cat: categories[4]?.id, daysAgo: 5 },
        { desc: 'إيجار المختبر شهري', amount: 1500, cat: categories[2]?.id, daysAgo: 7 },
        { desc: 'مستلزمات نظافة', amount: 95, cat: categories[5]?.id, daysAgo: 10 },
        { desc: 'قفازات وأنابيب', amount: 220, cat: categories[0]?.id, daysAgo: 12 }
    ];
    
    for (const e of sampleExpenses) {
        const date = new Date(today);
        date.setDate(date.getDate() - e.daysAgo);
        await db.add('expenses', {
            description: e.desc,
            amount: e.amount,
            categoryId: e.cat,
            date: date.toISOString(),
            notes: ''
        });
    }
    
    // موردين تجريبيين
    const suppliers = [
        { name: 'شركة الكواشف الطبية الليبية', phone: '+218912345678', totalDebt: 2500, paid: 1500 },
        { name: 'مؤسسة المستلزمات الطبية', phone: '+218913456789', totalDebt: 1800, paid: 1800 },
        { name: 'شركة الأجهزة المخبرية', phone: '+218914567890', totalDebt: 5000, paid: 2000 }
    ];
    
    for (const s of suppliers) {
        await db.add('suppliers', {
            name: s.name,
            phone: s.phone,
            address: 'طرابلس',
            totalDebt: s.totalDebt,
            paidAmount: s.paid,
            notes: ''
        });
    }
    
    // عينات Lab to Lab
    const labSamples = [
        { lab: 'مختبر النور', test: 'تحليل هرمونات', price: 350, status: 'paid', daysAgo: 2 },
        { lab: 'مختبر الشفاء', test: 'فحص جيني', price: 800, status: 'unpaid', daysAgo: 4 },
        { lab: 'مختبر الأمل', test: 'تحاليل أورام', price: 1200, status: 'partial', daysAgo: 7 },
        { lab: 'مختبر النور', test: 'تحاليل خاصة', price: 450, status: 'paid', daysAgo: 10 }
    ];
    
    for (const l of labSamples) {
        const date = new Date(today);
        date.setDate(date.getDate() - l.daysAgo);
        await db.add('labToLab', {
            labName: l.lab,
            testType: l.test,
            price: l.price,
            paymentStatus: l.status,
            paidAmount: l.status === 'paid' ? l.price : (l.status === 'partial' ? l.price / 2 : 0),
            date: date.toISOString(),
            notes: ''
        });
    }
    
    // موظفين تجريبيين
    const employees = [
        { name: 'د. عبدالسلام الهيثم', position: 'مدير المختبر', salaryType: 'monthly', salary: 3500, phone: '+218911111111' },
        { name: 'سامية بن قاسم', position: 'أخصائية تحاليل', salaryType: 'monthly', salary: 1800, phone: '+218922222222' },
        { name: 'هند الفرجاني', position: 'موظفة استقبال', salaryType: 'monthly', salary: 1200, phone: '+218933333333' },
        { name: 'محمد الزواوي', position: 'فني مختبر', salaryType: 'daily', salary: 50, phone: '+218944444444' }
    ];
    
    for (const emp of employees) {
        await db.add('employees', {
            name: emp.name,
            position: emp.position,
            salaryType: emp.salaryType,
            baseSalary: emp.salary,
            phone: emp.phone,
            hireDate: new Date(today.getFullYear(), today.getMonth() - 6, 1).toISOString(),
            active: true,
            notes: ''
        });
    }
}
