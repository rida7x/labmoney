/**
 * إدارة الديون والموردين - نظام الفواتير المتعددة
 * كل مورد يمكن أن يكون له عدة فواتير، والدين الإجمالي = مجموع الفواتير - مجموع الدفعات
 */

let currentSupplierSearch = '';
let currentSupplierSort = 'name_asc';
function setSupplierSort(v) { currentSupplierSort = v; loadSuppliers(); }

// حساب إجماليات المورد من الفواتير والدفعات
async function computeSupplierTotals(supplierId) {
    const invoices = (await db.getAll('supplierInvoices')).filter(i => i.supplierId === supplierId);
    const payments = (await db.getAll('supplierPayments')).filter(p => p.supplierId === supplierId);
    const totalInvoices = invoices.reduce((s, i) => s + Number(i.amount || 0), 0);
    const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    return { totalDebt: totalInvoices, paidAmount: totalPaid, remaining: totalInvoices - totalPaid, invoiceCount: invoices.length };
}

// ترحيل البيانات القديمة: لو مورد عنده totalDebt قديم بدون فواتير، أنشئ فاتورة افتتاحية
async function migrateOldSupplierIfNeeded(supplierId) {
    const supplier = await db.get('suppliers', supplierId);
    if (!supplier || supplier._migrated) return;
    const invoices = (await db.getAll('supplierInvoices')).filter(i => i.supplierId === supplierId);
    if (invoices.length === 0 && Number(supplier.totalDebt || 0) > 0) {
        await db.add('supplierInvoices', {
            supplierId,
            description: 'رصيد افتتاحي',
            amount: Number(supplier.totalDebt),
            date: supplier.createdAt || new Date().toISOString(),
            notes: 'تم إنشاؤها تلقائياً من الرصيد السابق'
        });
        // لو كان عنده paidAmount قديم بدون دفعات
        const payments = (await db.getAll('supplierPayments')).filter(p => p.supplierId === supplierId);
        if (payments.length === 0 && Number(supplier.paidAmount || 0) > 0) {
            await db.add('supplierPayments', {
                supplierId,
                amount: Number(supplier.paidAmount),
                date: supplier.createdAt || new Date().toISOString(),
                notes: 'دفعة سابقة (ترحيل تلقائي)'
            });
        }
    }
    supplier._migrated = true;
    await db.update('suppliers', supplier);
}

async function renderDebts() {
    const html = `
        <div class="page-header">
            <h2><i class="fas fa-handshake"></i> الديون والموردين</h2>
            <button class="btn btn-primary" onclick="showSupplierModal()">
                <i class="fas fa-plus"></i> مورد جديد
            </button>
        </div>
        
        <div id="debtsStats" class="stats-grid"></div>
        
        <div class="card">
            <div class="toolbar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="بحث عن مورد..." oninput="onSupplierSearch(this.value)">
                </div>
                ${buildSortSelect(currentSupplierSort, 'setSupplierSort')}
                <button class="btn btn-secondary" onclick="exportSuppliers()">
                    <i class="fas fa-file-pdf"></i> تصدير PDF
                </button>
            </div>
            
            <div id="suppliersListContainer"></div>
        </div>
    `;
    
    document.getElementById('content').innerHTML = html;
    
    // ترحيل البيانات القديمة لأول مرة
    const suppliers = await db.getAll('suppliers');
    for (const s of suppliers) {
        await migrateOldSupplierIfNeeded(s.id);
    }
    
    loadSuppliers();
}

async function loadSuppliers() {
    let suppliers = await db.getAll('suppliers');
    
    if (currentSupplierSearch) {
        const s = currentSupplierSearch.toLowerCase();
        suppliers = suppliers.filter(sup => 
            (sup.name || '').toLowerCase().includes(s) ||
            (sup.phone || '').includes(s)
        );
    }
    
    // حساب الإجماليات لكل مورد
    const enriched = await Promise.all(suppliers.map(async s => {
        const t = await computeSupplierTotals(s.id);
        return { ...s, ...t };
    }));
    
    // فرز حسب الاختيار
    if (currentSupplierSort === 'amount_desc') enriched.sort((a,b) => b.remaining - a.remaining);
    else if (currentSupplierSort === 'amount_asc') enriched.sort((a,b) => a.remaining - b.remaining);
    else enriched.sort((a,b) => (a.name||'').localeCompare(b.name||'','ar') * (currentSupplierSort==='name_desc'?-1:1));
    
    const totalDebt = enriched.reduce((sum, s) => sum + s.totalDebt, 0);
    const totalPaid = enriched.reduce((sum, s) => sum + s.paidAmount, 0);
    const totalRemaining = totalDebt - totalPaid;
    const overdueCount = enriched.filter(s => s.remaining > 0).length;
    
    document.getElementById('debtsStats').innerHTML = `
        <div class="stat-card debt">
            <div class="stat-icon"><i class="fas fa-coins"></i></div>
            <div class="stat-label">إجمالي الديون</div>
            <div class="stat-value">${formatCurrency(totalDebt)}</div>
            <div class="stat-meta">${enriched.length} مورد</div>
        </div>
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
            <div class="stat-label">المدفوع</div>
            <div class="stat-value">${formatCurrency(totalPaid)}</div>
        </div>
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-exclamation-circle"></i></div>
            <div class="stat-label">المتبقي</div>
            <div class="stat-value">${formatCurrency(totalRemaining)}</div>
            <div class="stat-meta">${overdueCount} دين مستحق</div>
        </div>
        <div class="stat-card profit">
            <div class="stat-icon"><i class="fas fa-percentage"></i></div>
            <div class="stat-label">نسبة السداد</div>
            <div class="stat-value">${totalDebt > 0 ? Math.round(totalPaid / totalDebt * 100) : 0}%</div>
        </div>
    `;
    
    const container = document.getElementById('suppliersListContainer');
    
    if (enriched.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>لا يوجد موردين</h3>
                <p>ابدأ بإضافة مورد جديد</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = enriched.map(s => {
        const remaining = s.remaining;
        const percentage = s.totalDebt > 0 ? (s.paidAmount / s.totalDebt * 100) : 100;
        const isPaid = remaining <= 0 && s.invoiceCount > 0;
        const hasNoInvoices = s.invoiceCount === 0;
        
        return `
            <div class="lab-card" onclick="showSupplierDetails('${s.id}')" style="cursor:pointer;">
                <div class="lab-card-header">
                    <div>
                        <div class="lab-card-title">
                            <i class="fas fa-building" style="color:var(--primary);"></i>
                            ${s.name}
                        </div>
                        <div style="font-size:13px;color:var(--text-tertiary);margin-top:4px;">
                            ${s.phone ? `<i class="fas fa-phone"></i> ${s.phone} • ` : ''}
                            <i class="fas fa-file-invoice"></i> ${s.invoiceCount} فاتورة
                        </div>
                    </div>
                    <span class="status ${hasNoInvoices ? 'partial' : (isPaid ? 'paid' : 'unpaid')}">
                        ${hasNoInvoices ? 'بدون فواتير' : (isPaid ? 'مسدد' : 'مستحق')}
                    </span>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0;">
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">إجمالي</div>
                        <div style="font-weight:700;color:var(--text-primary);">${formatCurrency(s.totalDebt)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">مدفوع</div>
                        <div style="font-weight:700;color:var(--success);">${formatCurrency(s.paidAmount)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">متبقي</div>
                        <div style="font-weight:700;color:${remaining <= 0 ? 'var(--success)' : 'var(--danger)'}">${formatCurrency(remaining)}</div>
                    </div>
                </div>
                
                <div style="background:var(--bg-tertiary);border-radius:8px;height:6px;overflow:hidden;">
                    <div style="height:100%;width:${Math.min(percentage, 100)}%;background:linear-gradient(to right,var(--success),var(--primary));transition:width 0.5s;"></div>
                </div>
                
                <div style="display:flex;justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap;">
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); showInvoiceModal('${s.id}')">
                            <i class="fas fa-file-invoice"></i> فاتورة
                        </button>
                        <button class="btn btn-sm btn-success" onclick="event.stopPropagation(); showPaymentModal('${s.id}')">
                            <i class="fas fa-money-bill-wave"></i> دفعة
                        </button>
                    </div>
                    <div style="display:flex;gap:6px;">
                        <button class="action-btn print" onclick="event.stopPropagation(); printSupplierStatement('${s.id}')" title="كشف حساب PDF">
                            <i class="fas fa-file-pdf"></i>
                        </button>
                        <button class="action-btn edit" onclick="event.stopPropagation(); showSupplierModal('${s.id}')" title="تعديل">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" onclick="event.stopPropagation(); deleteSupplier('${s.id}')" title="حذف">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

const onSupplierSearch = debounce((value) => {
    currentSupplierSearch = value;
    loadSuppliers();
}, 250);

async function showSupplierModal(id = null) {
    let supplier = null;
    if (id) supplier = await db.get('suppliers', id);
    
    const body = `
        <form id="supplierForm" onsubmit="saveSupplier(event, '${id || ''}')">
            <div class="form-group">
                <label>اسم المورد / الجهة <span class="required">*</span></label>
                <input type="text" id="sup_name" value="${supplier?.name || ''}" required placeholder="مثال: شركة الشموخ">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>الهاتف</label>
                    <input type="tel" id="sup_phone" value="${supplier?.phone || ''}" placeholder="+218XXXXXXXXX">
                </div>
                <div class="form-group">
                    <label>العنوان</label>
                    <input type="text" id="sup_address" value="${supplier?.address || ''}" placeholder="المدينة">
                </div>
            </div>
            
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="sup_notes" placeholder="ملاحظات...">${supplier?.notes || ''}</textarea>
            </div>
            
            <div class="info-banner" style="margin-top:12px;">
                <i class="fas fa-info-circle"></i>
                <p>إجمالي الدين يُحسب تلقائياً من الفواتير. بعد حفظ المورد يمكنك إضافة فاتورة جديدة.</p>
            </div>
        </form>
    `;
    
    showModal(id ? 'تعديل مورد' : 'مورد جديد', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('supplierForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
}

async function saveSupplier(event, id) {
    event.preventDefault();
    
    const data = {
        name: document.getElementById('sup_name').value.trim(),
        phone: document.getElementById('sup_phone').value.trim(),
        address: document.getElementById('sup_address').value.trim(),
        notes: document.getElementById('sup_notes').value.trim()
    };
    
    if (!data.name) {
        showToast('يرجى إدخال اسم المورد', 'error');
        return;
    }
    
    try {
        if (id) {
            const existing = await db.get('suppliers', id);
            await db.update('suppliers', { ...existing, ...data });
            showToast('تم التعديل بنجاح');
        } else {
            await db.add('suppliers', { ...data, createdAt: new Date().toISOString(), _migrated: true });
            showToast('تم الإضافة بنجاح');
        }
        closeModal();
        loadSuppliers();
    } catch (e) {
        showToast('حدث خطأ: ' + e.message, 'error');
    }
}

function deleteSupplier(id) {
    confirmAction('هل تريد حذف هذا المورد؟ سيتم حذف كل الفواتير والدفعات المرتبطة به.', async () => {
        await db.delete('suppliers', id);
        const invoices = await db.getAll('supplierInvoices');
        for (const i of invoices.filter(x => x.supplierId === id)) {
            await db.delete('supplierInvoices', i.id);
        }
        const payments = await db.getAll('supplierPayments');
        for (const p of payments.filter(pp => pp.supplierId === id)) {
            await db.delete('supplierPayments', p.id);
        }
        showToast('تم الحذف بنجاح');
        loadSuppliers();
    }, 'حذف المورد');
}

// ==== الفواتير ====
async function showInvoiceModal(supplierId, invoiceId = null) {
    const supplier = await db.get('suppliers', supplierId);
    if (!supplier) return;
    
    let invoice = null;
    if (invoiceId) invoice = await db.get('supplierInvoices', invoiceId);
    
    const totals = await computeSupplierTotals(supplierId);
    
    const body = `
        <div style="background:var(--primary-bg);padding:14px;border-radius:10px;margin-bottom:16px;">
            <div style="font-weight:700;font-size:15px;margin-bottom:6px;">${supplier.name}</div>
            <div style="font-size:13px;color:var(--text-secondary);">
                دين حالي: <strong style="color:var(--danger);">${formatCurrency(totals.remaining)}</strong>
                • ${totals.invoiceCount} فاتورة
            </div>
        </div>
        
        <form id="invoiceForm" onsubmit="saveInvoice(event, '${supplierId}', '${invoiceId || ''}')">
            <div class="form-group">
                <label>بيان الفاتورة <span class="required">*</span></label>
                <input type="text" id="inv_description" value="${invoice?.description || ''}" required placeholder="مثال: شراء كواشف تحاليل دم">
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0.01" id="inv_amount" value="${invoice?.amount || ''}" required>
                </div>
                <div class="form-group">
                    <label>تاريخ الفاتورة</label>
                    <input type="datetime-local" id="inv_date" value="${invoice ? formatDateTimeInput(invoice.date) : formatDateTimeInput()}">
                </div>
            </div>
            
            <div class="form-group">
                <label>رقم الفاتورة (اختياري)</label>
                <input type="text" id="inv_number" value="${invoice?.invoiceNumber || ''}" placeholder="مثال: INV-2024-001">
            </div>
            
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="inv_notes" placeholder="تفاصيل المواد، شروط الدفع، إلخ...">${invoice?.notes || ''}</textarea>
            </div>
        </form>
    `;
    
    showModal(invoiceId ? 'تعديل فاتورة' : 'إضافة فاتورة جديدة', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('invoiceForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ الفاتورة
        </button>
    `);
}

async function saveInvoice(event, supplierId, invoiceId) {
    event.preventDefault();
    
    const data = {
        supplierId,
        description: document.getElementById('inv_description').value.trim(),
        amount: parseFloat(document.getElementById('inv_amount').value) || 0,
        date: new Date(document.getElementById('inv_date').value).toISOString(),
        invoiceNumber: document.getElementById('inv_number').value.trim(),
        notes: document.getElementById('inv_notes').value.trim()
    };
    
    if (!data.description || data.amount <= 0) {
        showToast('يرجى ملء البيان والمبلغ', 'error');
        return;
    }
    
    try {
        if (invoiceId) {
            const existing = await db.get('supplierInvoices', invoiceId);
            await db.update('supplierInvoices', { ...existing, ...data });
            showToast('تم تعديل الفاتورة');
        } else {
            await db.add('supplierInvoices', data);
            showToast('تم إضافة الفاتورة بنجاح');
        }
        closeModal();
        if (typeof loadSuppliers === 'function') loadSuppliers();
        setTimeout(() => showSupplierDetails(supplierId), 200);
    } catch (e) {
        showToast('حدث خطأ: ' + e.message, 'error');
    }
}

async function deleteInvoice(invoiceId, supplierId) {
    confirmAction('هل تريد حذف هذه الفاتورة؟', async () => {
        await db.delete('supplierInvoices', invoiceId);
        showToast('تم الحذف');
        closeModal();
        if (typeof loadSuppliers === 'function') loadSuppliers();
        setTimeout(() => showSupplierDetails(supplierId), 200);
    }, 'حذف الفاتورة');
}

// ==== الدفعات ====
async function showPaymentModal(supplierId, paymentId = null) {
    const supplier = await db.get('suppliers', supplierId);
    if (!supplier) return;
    const totals = await computeSupplierTotals(supplierId);
    
    let payment = null;
    if (paymentId) {
        payment = await db.get('supplierPayments', paymentId);
        if (!payment) {
            showToast('الدفعة غير موجودة', 'error');
            return;
        }
    } else {
        if (totals.invoiceCount === 0) {
            showToast('لا توجد فواتير لهذا المورد. أضف فاتورة أولاً.', 'warning');
            return;
        }
    }
    
    const body = `
        <div style="background:var(--primary-bg);padding:14px;border-radius:10px;margin-bottom:16px;">
            <div style="font-weight:700;font-size:15px;margin-bottom:6px;">${supplier.name}</div>
            <div style="font-size:13px;color:var(--text-secondary);">
                إجمالي الدين: <strong>${formatCurrency(totals.totalDebt)}</strong> • 
                المدفوع: <strong style="color:var(--success);">${formatCurrency(totals.paidAmount)}</strong> • 
                المتبقي: <strong style="color:var(--danger);">${formatCurrency(totals.remaining)}</strong>
            </div>
            ${payment ? `<div style="margin-top:8px;font-size:12px;color:var(--text-tertiary);">
                <i class="fas fa-info-circle"></i> أنت تُعدّل دفعة موجودة - عند تعديل المبلغ سيتغيّر الإجمالي تلقائياً
            </div>` : ''}
        </div>
        
        <form id="paymentForm" onsubmit="savePayment(event, '${supplierId}', '${paymentId || ''}')">
            <div class="form-row">
                <div class="form-group">
                    <label>مبلغ الدفعة (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0.01" id="pay_amount" value="${payment?.amount || ''}" required autofocus>
                </div>
                <div class="form-group">
                    <label>تاريخ الدفعة</label>
                    <input type="datetime-local" id="pay_date" value="${payment ? formatDateTimeInput(payment.date) : formatDateTimeInput()}">
                </div>
            </div>
            
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="pay_notes" placeholder="رقم الإيصال، طريقة الدفع، إلخ...">${payment?.notes || ''}</textarea>
            </div>
        </form>
    `;
    
    showModal(paymentId ? 'تعديل دفعة' : 'إضافة دفعة', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-success" onclick="document.getElementById('paymentForm').requestSubmit()">
            <i class="fas fa-check"></i> ${paymentId ? 'تحديث الدفعة' : 'تأكيد الدفعة'}
        </button>
    `);
}

async function savePayment(event, supplierId, paymentId = '') {
    event.preventDefault();
    
    const amount = parseFloat(document.getElementById('pay_amount').value);
    const date = new Date(document.getElementById('pay_date').value).toISOString();
    const notes = document.getElementById('pay_notes').value.trim();
    
    if (!amount || amount <= 0) {
        showToast('يرجى إدخال مبلغ صحيح', 'error');
        return;
    }
    
    try {
        if (paymentId) {
            // تعديل دفعة موجودة
            const existing = await db.get('supplierPayments', paymentId);
            if (!existing) {
                showToast('الدفعة غير موجودة', 'error');
                return;
            }
            await db.update('supplierPayments', { ...existing, amount, date, notes });
            showToast('تم تعديل الدفعة بنجاح');
        } else {
            // دفعة جديدة
            await db.add('supplierPayments', { supplierId, amount, date, notes });
            showToast('تم تسجيل الدفعة بنجاح');
        }
        closeModal();
        // أعد تحميل قائمة الموردين الرئيسية لتحديث الإجماليات
        if (typeof loadSuppliers === 'function') loadSuppliers();
        // ثم افتح تفاصيل المورد مرة أخرى
        setTimeout(() => showSupplierDetails(supplierId), 200);
    } catch (e) {
        showToast('حدث خطأ: ' + e.message, 'error');
    }
}

async function deletePayment(paymentId, supplierId) {
    confirmAction('هل تريد حذف هذه الدفعة؟', async () => {
        await db.delete('supplierPayments', paymentId);
        showToast('تم الحذف');
        closeModal();
        if (typeof loadSuppliers === 'function') loadSuppliers();
        setTimeout(() => showSupplierDetails(supplierId), 200);
    }, 'حذف الدفعة');
}

// ==== تفاصيل المورد - الفواتير + الدفعات ====
async function showSupplierDetails(supplierId) {
    const supplier = await db.get('suppliers', supplierId);
    if (!supplier) return;
    
    const invoices = (await db.getAll('supplierInvoices'))
        .filter(i => i.supplierId === supplierId)
        .sort((a, b) => new Date(b.date) - new Date(a.date));
    
    const payments = (await db.getAll('supplierPayments'))
        .filter(p => p.supplierId === supplierId)
        .sort((a, b) => new Date(b.date) - new Date(a.date));
    
    const totals = await computeSupplierTotals(supplierId);
    const isPaid = totals.remaining <= 0 && totals.invoiceCount > 0;
    
    const body = `
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px;">
            <div style="background:var(--bg-tertiary);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--text-tertiary);">إجمالي الدين</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;">${formatCurrency(totals.totalDebt)}</div>
            </div>
            <div style="background:var(--success-bg);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--success);">المدفوع</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:var(--success);">${formatCurrency(totals.paidAmount)}</div>
            </div>
            <div style="background:${isPaid ? 'var(--success-bg)' : 'var(--danger-bg)'};padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:${isPaid ? 'var(--success)' : 'var(--danger)'};">المتبقي</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:${isPaid ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(totals.remaining)}</div>
            </div>
        </div>
        
        ${supplier.phone || supplier.address ? `
            <div style="background:var(--bg-tertiary);padding:12px;border-radius:10px;margin-bottom:16px;font-size:13px;">
                ${supplier.phone ? `<div><i class="fas fa-phone" style="color:var(--primary);"></i> ${supplier.phone}</div>` : ''}
                ${supplier.address ? `<div style="margin-top:4px;"><i class="fas fa-map-marker-alt" style="color:var(--primary);"></i> ${supplier.address}</div>` : ''}
            </div>
        ` : ''}
        
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <h4 style="font-size:15px;">الفواتير (${invoices.length})</h4>
            <button class="btn btn-sm btn-primary" onclick="closeModal(); setTimeout(() => showInvoiceModal('${supplierId}'), 200)">
                <i class="fas fa-plus"></i> فاتورة جديدة
            </button>
        </div>
        
        ${invoices.length === 0 ? `
            <div class="empty-state" style="padding:20px;">
                <i class="fas fa-file-invoice"></i>
                <p>لا توجد فواتير بعد</p>
            </div>
        ` : `
            <div class="supplier-invoices-list">
                ${invoices.map(inv => `
                    <div class="invoice-item">
                        <div class="invoice-info">
                            <div class="invoice-desc">${inv.description}</div>
                            <div class="invoice-date">
                                ${formatDate(inv.date, false)}
                                ${inv.invoiceNumber ? ` • <i class="fas fa-hashtag"></i> ${inv.invoiceNumber}` : ''}
                                ${inv.notes ? ` • ${inv.notes}` : ''}
                            </div>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div class="invoice-amount">${formatCurrency(inv.amount)}</div>
                            <button class="action-btn edit" onclick="closeModal(); setTimeout(() => showInvoiceModal('${supplierId}', '${inv.id}'), 200)" title="تعديل">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete" onclick="deleteInvoice('${inv.id}', '${supplierId}')" title="حذف">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `}
        
        <div style="display:flex;justify-content:space-between;align-items:center;margin:20px 0 10px;">
            <h4 style="font-size:15px;">الدفعات (${payments.length})</h4>
            ${totals.invoiceCount > 0 && !isPaid ? `
                <button class="btn btn-sm btn-success" onclick="closeModal(); setTimeout(() => showPaymentModal('${supplierId}'), 200)">
                    <i class="fas fa-plus"></i> دفعة جديدة
                </button>
            ` : ''}
        </div>
        
        ${payments.length === 0 ? `
            <div class="empty-state" style="padding:20px;">
                <i class="fas fa-receipt"></i>
                <p>لا توجد دفعات بعد</p>
            </div>
        ` : `
            <div style="max-height:200px;overflow-y:auto;display:flex;flex-direction:column;gap:8px;">
                ${payments.map(p => `
                    <div class="list-item">
                        <div class="list-icon" style="background:var(--success-bg);color:var(--success);">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="list-content">
                            <div class="list-title">${formatCurrency(p.amount)}</div>
                            <div class="list-meta">${formatDate(p.date, true)}${p.notes ? ` • ${p.notes}` : ''}</div>
                        </div>
                        <div style="display:flex;gap:6px;">
                            <button class="action-btn edit" onclick="closeModal(); setTimeout(() => showPaymentModal('${supplierId}', '${p.id}'), 200)" title="تعديل المبلغ">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete" onclick="deletePayment('${p.id}', '${supplierId}')" title="حذف">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `}
    `;
    
    showModal(supplier.name, body, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
        <button class="btn btn-warning" onclick="printSupplierStatement('${supplierId}')">
            <i class="fas fa-file-pdf"></i> كشف حساب PDF
        </button>
    `, 'lg');
}

// ==== تصدير كشف حساب لمورد واحد كملف PDF ====
async function printSupplierStatement(supplierId) {
    const supplier = await db.get('suppliers', supplierId);
    if (!supplier) return;
    
    const invoices = (await db.getAll('supplierInvoices'))
        .filter(i => i.supplierId === supplierId)
        .sort((a, b) => new Date(a.date) - new Date(b.date));
    
    const payments = (await db.getAll('supplierPayments'))
        .filter(p => p.supplierId === supplierId)
        .sort((a, b) => new Date(a.date) - new Date(b.date));
    
    const totals = await computeSupplierTotals(supplierId);
    
    // دمج الحركات (مدين/دائن) مرتبة زمنياً
    const movements = [
        ...invoices.map(i => ({
            date: i.date,
            type: 'فاتورة',
            description: i.description + (i.invoiceNumber ? ` (${i.invoiceNumber})` : ''),
            debit: Number(i.amount || 0),
            credit: 0
        })),
        ...payments.map(p => ({
            date: p.date,
            type: 'دفعة',
            description: p.notes || 'دفعة نقدية',
            debit: 0,
            credit: Number(p.amount || 0)
        }))
    ].sort((a, b) => new Date(a.date) - new Date(b.date));
    
    // رصيد جاري
    let runningBalance = 0;
    movements.forEach(m => {
        runningBalance += m.debit - m.credit;
        m.balance = runningBalance;
    });
    
    await generatePDFReport({
        title: `كشف حساب: ${supplier.name}`,
        subtitle: `${supplier.phone ? 'هاتف: ' + supplier.phone + ' • ' : ''}عدد الفواتير: ${invoices.length} • عدد الدفعات: ${payments.length}`,
        filename: `كشف_حساب_${supplier.name.replace(/[/\\]/g, '_')}_${getTodayString()}.pdf`,
        columns: [
            { key: 'date', label: 'التاريخ', width: '14%', format: v => formatDate(v, false) },
            { key: 'type', label: 'نوع', width: '10%' },
            { key: 'description', label: 'البيان', width: '36%' },
            { key: 'debit', label: 'مدين (د.ل)', width: '13%', format: v => v > 0 ? formatCurrency(v) : '-' },
            { key: 'credit', label: 'دائن (د.ل)', width: '13%', format: v => v > 0 ? formatCurrency(v) : '-' },
            { key: 'balance', label: 'الرصيد', width: '14%', format: v => formatCurrency(v) }
        ],
        rows: movements,
        summary: [
            { label: 'إجمالي الفواتير (مدين)', value: formatCurrency(totals.totalDebt) },
            { label: 'إجمالي الدفعات (دائن)', value: formatCurrency(totals.paidAmount) },
            { label: 'الرصيد المتبقي', value: formatCurrency(totals.remaining), highlight: true }
        ]
    });
}

// ==== تصدير قائمة كل الموردين كملف PDF ====
async function exportSuppliers() {
    const suppliers = await db.getAll('suppliers');
    
    const enriched = await Promise.all(suppliers.map(async s => {
        const t = await computeSupplierTotals(s.id);
        return {
            name: s.name,
            phone: s.phone || '-',
            address: s.address || '-',
            totalDebt: t.totalDebt,
            paidAmount: t.paidAmount,
            remaining: t.remaining,
            invoiceCount: t.invoiceCount
        };
    }));
    
    enriched.sort((a, b) => b.remaining - a.remaining);
    
    const totalDebt = enriched.reduce((s, x) => s + x.totalDebt, 0);
    const totalPaid = enriched.reduce((s, x) => s + x.paidAmount, 0);
    const totalRemaining = totalDebt - totalPaid;
    
    await generatePDFReport({
        title: 'تقرير الديون والموردين',
        subtitle: `عدد الموردين: ${enriched.length}`,
        filename: `تقرير_الموردين_${getTodayString()}.pdf`,
        columns: [
            { key: 'name', label: 'المورد', width: '22%' },
            { key: 'phone', label: 'الهاتف', width: '14%' },
            { key: 'invoiceCount', label: 'فواتير', width: '8%' },
            { key: 'totalDebt', label: 'الإجمالي', width: '14%', format: v => formatCurrency(v) },
            { key: 'paidAmount', label: 'المدفوع', width: '14%', format: v => formatCurrency(v) },
            { key: 'remaining', label: 'المتبقي', width: '14%', format: v => formatCurrency(v) },
            { key: 'address', label: 'العنوان', width: '14%' }
        ],
        rows: enriched,
        summary: [
            { label: 'عدد الموردين', value: enriched.length },
            { label: 'إجمالي الديون', value: formatCurrency(totalDebt) },
            { label: 'إجمالي المدفوع', value: formatCurrency(totalPaid) },
            { label: 'إجمالي المتبقي', value: formatCurrency(totalRemaining), highlight: true }
        ]
    });
}
