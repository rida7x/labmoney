// ===== قسم تقسيم الأرباح (نسخة محسّنة) =====
//
// نظام تخصيص ذو مرحلتين:
// 1) تقسيم صافي الربح إلى فئات: سداد ديون، طوارئ، أرباح موزَّعة، فئات مخصصة
// 2) داخل فئة "الأرباح الموزَّعة" تُقسم على الشركاء بنسب مئوية
//
// مثال: إجمالي صافي 10000 دل
//   30% لسداد الديون     = 3000
//   20% احتياطي للطوارئ  = 2000
//   50% أرباح موزَّعة     = 5000
//        ├─ شريك 1 (60%) = 3000
//        └─ شريك 2 (40%) = 2000

let currentDistPeriod = 'month';
let currentDistFrom = null;
let currentDistTo = null;
let distCharts = {};

// ============== الواجهة الرئيسية ==============
async function renderProfitDistribution() {
    const content = document.getElementById('content');
    content.innerHTML = `
        <div class="page-header">
            <h2><i class="fas fa-handshake"></i> تقسيم وتخصيص الأرباح</h2>
        </div>

        <!-- شريط الفترة + الأزرار -->
        <div class="card" style="padding:14px;margin-bottom:14px;">
            <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
                <label style="font-weight:600;color:var(--text-secondary);">الفترة:</label>
                <select class="form-control" id="distPeriod" onchange="onDistPeriodChange()" style="min-width:160px;">
                    <option value="today">اليوم</option>
                    <option value="week">آخر 7 أيام</option>
                    <option value="month" selected>هذا الشهر</option>
                    <option value="lastMonth">الشهر الماضي</option>
                    <option value="year">هذه السنة</option>
                    <option value="all">كل الفترات</option>
                    <option value="custom">فترة مخصصة</option>
                </select>
                <input type="date" id="distFrom" class="form-control" style="display:none;width:auto;" onchange="loadProfitDistribution()">
                <input type="date" id="distTo" class="form-control" style="display:none;width:auto;" onchange="loadProfitDistribution()">
                <div style="flex:1;"></div>
                <button class="btn btn-secondary" onclick="showAllocationConfigModal()">
                    <i class="fas fa-sliders-h"></i> ضبط نسب التخصيص
                </button>
                <button class="btn btn-secondary" onclick="showPartnersConfig()">
                    <i class="fas fa-users-cog"></i> الشركاء
                </button>
                <button class="btn btn-primary" onclick="exportProfitDistributionPDF()">
                    <i class="fas fa-file-pdf"></i> تصدير PDF
                </button>
            </div>
        </div>

        <div id="distContent"></div>
    `;

    document.getElementById('distPeriod').value = currentDistPeriod;
    onDistPeriodChange(false);
    await loadProfitDistribution();
}

function onDistPeriodChange(reload = true) {
    const period = document.getElementById('distPeriod').value;
    currentDistPeriod = period;
    const fromEl = document.getElementById('distFrom');
    const toEl = document.getElementById('distTo');
    const isCustom = period === 'custom';
    fromEl.style.display = isCustom ? '' : 'none';
    toEl.style.display = isCustom ? '' : 'none';
    if (reload && !isCustom) loadProfitDistribution();
}

// ============== إعدادات الشركاء ==============
async function getPartnersConfig() {
    let config = await db.get('profitDistributionConfig', 'main');
    if (!config) {
        config = {
            id: 'main',
            partners: [
                { name: 'الشريك 1', percentage: 50 },
                { name: 'الشريك 2', percentage: 50 }
            ],
            // نسب التخصيص الافتراضية
            allocations: [
                { id: 'debts',     name: 'سداد الديون',       percentage: 30, color: '#ef4444', icon: 'fa-credit-card' },
                { id: 'emergency', name: 'احتياطي الطوارئ',  percentage: 20, color: '#f59e0b', icon: 'fa-shield-halved' },
                { id: 'partners',  name: 'أرباح الشركاء',    percentage: 50, color: '#10b981', icon: 'fa-users' }
            ]
        };
        await db.add('profitDistributionConfig', config);
    }
    // ضمان وجود allocations في الإعدادات القديمة
    if (!config.allocations || !config.allocations.length) {
        config.allocations = [
            { id: 'debts',     name: 'سداد الديون',       percentage: 30, color: '#ef4444', icon: 'fa-credit-card' },
            { id: 'emergency', name: 'احتياطي الطوارئ',  percentage: 20, color: '#f59e0b', icon: 'fa-shield-halved' },
            { id: 'partners',  name: 'أرباح الشركاء',    percentage: 50, color: '#10b981', icon: 'fa-users' }
        ];
        await db.update('profitDistributionConfig', config);
    }
    return config;
}

async function saveAllConfig(partners, allocations) {
    let config = await db.get('profitDistributionConfig', 'main');
    if (!config) config = { id: 'main' };
    if (partners) config.partners = partners;
    if (allocations) config.allocations = allocations;
    await db.update('profitDistributionConfig', config);
}

// ============== نافذة ضبط نسب التخصيص ==============
async function showAllocationConfigModal() {
    const config = await getPartnersConfig();

    const body = `
        <div style="margin-bottom:12px;color:var(--text-secondary);font-size:13px;background:var(--primary-bg);padding:10px;border-radius:8px;">
            <i class="fas fa-info-circle"></i> 
            حدد كيف تريد تقسيم صافي الربح بين الفئات الأساسية. مجموع النسب يجب أن يساوي <strong>100%</strong>.
        </div>

        <div id="allocationsList">
            ${config.allocations.map(a => renderAllocationRow(a)).join('')}
        </div>

        <button type="button" class="btn btn-secondary btn-sm" onclick="addCustomAllocation()" style="margin-top:10px;width:100%;">
            <i class="fas fa-plus"></i> إضافة فئة مخصصة (مثل: تطوير، تسويق...)
        </button>

        <div style="margin-top:14px;padding:12px;background:var(--bg-tertiary);border-radius:8px;text-align:center;">
            <span style="color:var(--text-secondary);">مجموع النسب: </span>
            <strong id="allocTotalPct" style="font-size:18px;">0</strong>
            <span style="color:var(--text-secondary);">%</span>
        </div>

        <div style="background:#fef3c7;border:1px solid #fbbf24;color:#92400e;padding:10px;border-radius:8px;margin-top:10px;font-size:12px;">
            <i class="fas fa-lightbulb"></i> 
            <strong>اقتراحات شائعة:</strong> 30% ديون - 20% طوارئ - 50% أرباح • أو 50% طوارئ + استثمار - 50% أرباح • أو 100% أرباح موزَّعة
        </div>
    `;

    showModal('ضبط نسب تخصيص الأرباح', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-warning" onclick="resetAllocationsToDefault()">
            <i class="fas fa-undo"></i> الافتراضي
        </button>
        <button class="btn btn-primary" onclick="saveAndCloseAllocations()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);

    updateAllocTotalPct();
}

function renderAllocationRow(a) {
    const isSystem = ['debts', 'emergency', 'partners'].includes(a.id);
    return `
        <div class="alloc-row" data-id="${a.id}" style="display:flex;gap:8px;align-items:center;margin-bottom:8px;padding:12px;background:${a.color}15;border-right:4px solid ${a.color};border-radius:8px;">
            <i class="fas ${a.icon || 'fa-tag'}" style="color:${a.color};font-size:18px;width:24px;text-align:center;"></i>
            <div style="flex:2;">
                <input type="text" class="alloc-name" value="${a.name || ''}" placeholder="اسم الفئة" style="width:100%;padding:6px 8px;border:1px solid var(--border);border-radius:6px;font-weight:600;" ${isSystem ? 'readonly' : ''}>
            </div>
            <div style="flex:1;">
                <input type="number" min="0" max="100" step="0.1" class="alloc-pct" value="${a.percentage || 0}" oninput="updateAllocTotalPct()" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:6px;text-align:center;">
            </div>
            <span style="color:var(--text-secondary);">%</span>
            ${isSystem ? '' : `<button type="button" class="action-btn delete" onclick="this.closest('.alloc-row').remove(); updateAllocTotalPct();"><i class="fas fa-trash"></i></button>`}
        </div>
    `;
}

function addCustomAllocation() {
    const list = document.getElementById('allocationsList');
    if (!list) return;
    const colors = ['#8b5cf6', '#06b6d4', '#ec4899', '#6366f1', '#84cc16'];
    const icons = ['fa-piggy-bank', 'fa-chart-line', 'fa-gear', 'fa-leaf', 'fa-rocket'];
    const idx = list.children.length;
    const newAlloc = {
        id: 'custom_' + Date.now(),
        name: '',
        percentage: 0,
        color: colors[idx % colors.length],
        icon: icons[idx % icons.length]
    };
    const div = document.createElement('div');
    div.innerHTML = renderAllocationRow(newAlloc);
    list.appendChild(div.firstElementChild);
    updateAllocTotalPct();
}

function updateAllocTotalPct() {
    const total = Array.from(document.querySelectorAll('.alloc-pct'))
        .reduce((s, el) => s + (parseFloat(el.value) || 0), 0);
    const el = document.getElementById('allocTotalPct');
    if (el) {
        el.textContent = total.toFixed(1);
        el.style.color = Math.abs(total - 100) < 0.01 ? 'var(--success)' : 'var(--danger)';
    }
}

async function resetAllocationsToDefault() {
    const list = document.getElementById('allocationsList');
    if (!list) return;
    const defaults = [
        { id: 'debts',     name: 'سداد الديون',       percentage: 30, color: '#ef4444', icon: 'fa-credit-card' },
        { id: 'emergency', name: 'احتياطي الطوارئ',  percentage: 20, color: '#f59e0b', icon: 'fa-shield-halved' },
        { id: 'partners',  name: 'أرباح الشركاء',    percentage: 50, color: '#10b981', icon: 'fa-users' }
    ];
    list.innerHTML = defaults.map(a => renderAllocationRow(a)).join('');
    updateAllocTotalPct();
    showToast('تمت إعادة النسب للافتراضي', 'info');
}

async function saveAndCloseAllocations() {
    const rows = document.querySelectorAll('.alloc-row');
    const allocations = Array.from(rows).map(row => {
        const id = row.dataset.id;
        const name = row.querySelector('.alloc-name').value.trim();
        const pct = parseFloat(row.querySelector('.alloc-pct').value) || 0;
        // الحفاظ على اللون والأيقونة من بياناتنا
        const colorMatch = row.style.borderRightColor;
        const iconEl = row.querySelector('i.fas');
        const iconClass = iconEl?.className.split(' ').find(c => c.startsWith('fa-')) || 'fa-tag';
        return {
            id,
            name,
            percentage: pct,
            color: colorMatch || '#0d9488',
            icon: iconClass
        };
    });

    const total = allocations.reduce((s, a) => s + a.percentage, 0);
    if (Math.abs(total - 100) > 0.01) {
        showToast(`مجموع النسب = ${total.toFixed(1)}% — يجب أن يكون 100%`, 'error');
        return;
    }
    if (allocations.some(a => !a.name)) {
        showToast('يرجى إدخال اسم لكل فئة', 'error');
        return;
    }

    await saveAllConfig(null, allocations);
    showToast('تم حفظ نسب التخصيص', 'success');
    closeModal();
    loadProfitDistribution();
}

// ============== نافذة الشركاء ==============
async function showPartnersConfig() {
    const config = await getPartnersConfig();
    const partnersAlloc = config.allocations.find(a => a.id === 'partners');

    const body = `
        <div style="margin-bottom:12px;color:var(--text-secondary);font-size:13px;background:var(--primary-bg);padding:10px;border-radius:8px;">
            <i class="fas fa-info-circle"></i> 
            هذه النسب تُطبَّق على حصة <strong>${partnersAlloc?.name || 'أرباح الشركاء'}</strong> فقط — وهي <strong>${partnersAlloc?.percentage || 0}%</strong> من إجمالي صافي الربح.
        </div>

        <div id="partnersList">
            ${config.partners.map(p => renderPartnerRow(p)).join('')}
        </div>
        <button type="button" class="btn btn-secondary btn-sm" onclick="addPartnerRow()" style="margin-top:10px;width:100%;">
            <i class="fas fa-plus"></i> إضافة شريك
        </button>
        <div style="margin-top:14px;padding:12px;background:var(--bg-tertiary);border-radius:8px;text-align:center;">
            <span style="color:var(--text-secondary);">مجموع النسب: </span>
            <strong id="partnersTotalPct" style="font-size:18px;">0</strong>
            <span style="color:var(--text-secondary);">%</span>
        </div>
    `;
    showModal('إعدادات الشركاء', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="saveAndClosePartners()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
    updatePartnersTotalPct();
}

function renderPartnerRow(p) {
    return `
        <div class="partner-row" style="display:flex;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:var(--bg-tertiary);border-radius:8px;">
            <i class="fas fa-user" style="color:var(--primary);font-size:16px;width:24px;text-align:center;"></i>
            <div style="flex:2;">
                <input type="text" class="partner-name" value="${p.name || ''}" placeholder="اسم الشريك" style="width:100%;padding:6px 8px;border:1px solid var(--border);border-radius:6px;">
            </div>
            <div style="flex:1;">
                <input type="number" min="0" max="100" step="0.1" class="partner-pct" value="${p.percentage || 0}" oninput="updatePartnersTotalPct()" style="width:100%;padding:6px;border:1px solid var(--border);border-radius:6px;text-align:center;">
            </div>
            <span style="color:var(--text-secondary);">%</span>
            <button type="button" class="action-btn delete" onclick="this.closest('.partner-row').remove(); updatePartnersTotalPct();">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
}

function addPartnerRow() {
    const list = document.getElementById('partnersList');
    if (!list) return;
    const div = document.createElement('div');
    div.innerHTML = renderPartnerRow({ name: '', percentage: 0 });
    list.appendChild(div.firstElementChild);
    updatePartnersTotalPct();
}

function updatePartnersTotalPct() {
    const total = Array.from(document.querySelectorAll('.partner-pct'))
        .reduce((s, el) => s + (parseFloat(el.value) || 0), 0);
    const el = document.getElementById('partnersTotalPct');
    if (el) {
        el.textContent = total.toFixed(1);
        el.style.color = Math.abs(total - 100) < 0.01 ? 'var(--success)' : 'var(--danger)';
    }
}

async function saveAndClosePartners() {
    const names = Array.from(document.querySelectorAll('.partner-name')).map(el => el.value.trim());
    const pcts = Array.from(document.querySelectorAll('.partner-pct')).map(el => parseFloat(el.value) || 0);
    const total = pcts.reduce((s, p) => s + p, 0);

    if (Math.abs(total - 100) > 0.01) {
        showToast(`مجموع النسب = ${total.toFixed(1)}% — يجب أن يكون 100%`, 'error');
        return;
    }
    if (names.some(n => !n)) {
        showToast('يرجى إدخال أسماء كل الشركاء', 'error');
        return;
    }

    const partners = names.map((name, i) => ({ name, percentage: pcts[i] }));
    await saveAllConfig(partners, null);
    showToast('تم حفظ إعدادات الشركاء', 'success');
    closeModal();
    loadProfitDistribution();
}

// ============== العرض الرئيسي ==============
async function loadProfitDistribution() {
    const container = document.getElementById('distContent');
    if (!container) return;
    container.innerHTML = '<div style="text-align:center;padding:40px;"><i class="fas fa-spinner fa-spin" style="font-size:32px;color:var(--primary);"></i></div>';

    // نظّف المخططات السابقة
    Object.values(distCharts).forEach(c => { try { c.destroy(); } catch(_){} });
    distCharts = {};

    let revenues = await db.getAll('revenues');
    let expenses = await db.getAll('expenses');
    let labSamples = await db.getAll('labToLab');
    let salaries = await db.getAll('salaryRecords');

    if (currentDistPeriod === 'custom') {
        const from = document.getElementById('distFrom').value;
        const to = document.getElementById('distTo').value;
        if (!from || !to) {
            container.innerHTML = '<div class="card" style="padding:30px;text-align:center;color:var(--text-secondary);">يرجى تحديد الفترة المخصصة (من / إلى)</div>';
            return;
        }
        currentDistFrom = from;
        currentDistTo = to;
        const fromDate = new Date(from);
        const toDate = new Date(to);
        toDate.setHours(23, 59, 59, 999);
        const inRange = item => {
            const d = new Date(item.date);
            return !isNaN(d) && d >= fromDate && d <= toDate;
        };
        revenues = revenues.filter(inRange);
        expenses = expenses.filter(inRange);
        labSamples = labSamples.filter(inRange);
        salaries = salaries.filter(inRange);
    } else if (currentDistPeriod !== 'all') {
        revenues = filterByPeriod(revenues, currentDistPeriod);
        expenses = filterByPeriod(expenses, currentDistPeriod);
        labSamples = filterByPeriod(labSamples, currentDistPeriod);
        salaries = filterByPeriod(salaries, currentDistPeriod);
    }

    // ====== الحسابات ======
    const clinicRevenue = sumField(revenues, 'amount');
    const labRevenue = sumField(labSamples.filter(l => l.paymentStatus === 'paid'), 'price')
                     + sumField(labSamples.filter(l => l.paymentStatus === 'partial'), 'paidAmount');
    const totalRevenue = clinicRevenue + labRevenue;
    const totalExpense = sumField(expenses, 'amount');
    const totalSalaries = sumField(salaries, 'netAmount');
    const netProfit = totalRevenue - totalExpense - totalSalaries;

    const config = await getPartnersConfig();
    const partners = config.partners || [];
    const allocations = config.allocations || [];

    // قيمة كل فئة
    const allocationResults = allocations.map(a => ({
        ...a,
        amount: netProfit * (a.percentage / 100)
    }));

    // فئة الشركاء وتفاصيلها
    const partnersAlloc = allocationResults.find(a => a.id === 'partners');
    const partnersAmount = partnersAlloc?.amount || 0;
    const partnerShares = partners.map(p => ({
        name: p.name,
        percentage: p.percentage,
        amount: partnersAmount * (p.percentage / 100),
        // النسبة من الإجمالي = نسبتنا في الشركاء × نسبة فئة الشركاء
        percentageOfTotal: (partnersAlloc?.percentage || 0) * (p.percentage / 100)
    }));

    container.innerHTML = `
        <!-- إحصائيات أساسية -->
        <div class="stats-grid" style="margin-bottom:18px;">
            <div class="stat-card revenue">
                <div class="stat-icon"><i class="fas fa-arrow-trend-up"></i></div>
                <div class="stat-info">
                    <div class="stat-label">إجمالي الإيرادات</div>
                    <div class="stat-value">${formatCurrency(totalRevenue)}</div>
                    <div class="stat-meta">عيادة + Lab to Lab</div>
                </div>
            </div>
            <div class="stat-card expense">
                <div class="stat-icon"><i class="fas fa-arrow-trend-down"></i></div>
                <div class="stat-info">
                    <div class="stat-label">المصروفات + الرواتب</div>
                    <div class="stat-value">${formatCurrency(totalExpense + totalSalaries)}</div>
                    <div class="stat-meta">${formatCurrency(totalExpense)} + ${formatCurrency(totalSalaries)}</div>
                </div>
            </div>
            <div class="stat-card profit">
                <div class="stat-icon"><i class="fas fa-sack-dollar"></i></div>
                <div class="stat-info">
                    <div class="stat-label">صافي الربح (قابل للتقسيم)</div>
                    <div class="stat-value" style="color:${netProfit >= 0 ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(netProfit)}</div>
                    <div class="stat-meta">${totalRevenue > 0 ? `هامش ${((netProfit / totalRevenue) * 100).toFixed(1)}%` : ''}</div>
                </div>
            </div>
        </div>

        ${netProfit <= 0 ? `
            <div class="card" style="padding:24px;text-align:center;background:#fef3c7;border:1px solid #fbbf24;color:#92400e;">
                <i class="fas fa-triangle-exclamation" style="font-size:36px;margin-bottom:10px;"></i>
                <h3 style="margin-bottom:8px;">لا يوجد ربح لتوزيعه</h3>
                <p>صافي الربح ${netProfit < 0 ? '<strong>سالب</strong> — هناك خسارة في هذه الفترة' : 'يساوي صفر'}.</p>
            </div>
        ` : `
            <!-- المرحلة 1: تقسيم الفئات -->
            <div class="card" style="padding:16px;margin-bottom:18px;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
                    <h3 style="margin:0;color:var(--primary);">
                        <i class="fas fa-chart-pie"></i> المرحلة 1 — تقسيم الربح حسب الفئات
                    </h3>
                    <button class="btn btn-sm btn-secondary" onclick="showAllocationConfigModal()">
                        <i class="fas fa-sliders-h"></i> تعديل النسب
                    </button>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start;" class="report-split">
                    <div style="position:relative;height:320px;width:100%;">
                        <canvas id="allocChart"></canvas>
                    </div>
                    <div>
                        ${allocationResults.map(a => `
                            <div style="background:${a.color}15;border-right:4px solid ${a.color};padding:14px;border-radius:10px;margin-bottom:10px;">
                                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;">
                                    <div style="display:flex;align-items:center;gap:10px;">
                                        <div style="width:38px;height:38px;background:${a.color};color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;">
                                            <i class="fas ${a.icon || 'fa-tag'}"></i>
                                        </div>
                                        <div>
                                            <div style="font-weight:700;font-size:14px;">${a.name}</div>
                                            <div style="font-size:12px;color:var(--text-secondary);">${a.percentage.toFixed(1)}% من صافي الربح</div>
                                        </div>
                                    </div>
                                    <div style="font-size:18px;font-weight:800;color:${a.color};">
                                        ${formatCurrency(a.amount)}
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>

            ${partners.length && partnersAmount > 0 ? `
                <!-- المرحلة 2: تقسيم حصة الشركاء -->
                <div class="card" style="padding:16px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
                        <h3 style="margin:0;color:var(--primary);">
                            <i class="fas fa-users"></i> المرحلة 2 — تقسيم حصة الشركاء (${formatCurrency(partnersAmount)})
                        </h3>
                        <button class="btn btn-sm btn-secondary" onclick="showPartnersConfig()">
                            <i class="fas fa-users-cog"></i> تعديل الشركاء
                        </button>
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start;" class="report-split">
                        <div style="position:relative;height:300px;width:100%;">
                            <canvas id="partnersChart"></canvas>
                        </div>
                        <div class="table-wrapper">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>الشريك</th>
                                        <th>نسبة الشريك</th>
                                        <th>من الإجمالي</th>
                                        <th>الحصة (د.ل)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${partnerShares.map(p => `
                                        <tr>
                                            <td><strong>${p.name}</strong></td>
                                            <td>${p.percentage.toFixed(1)}%</td>
                                            <td style="color:var(--text-secondary);">${p.percentageOfTotal.toFixed(1)}%</td>
                                            <td style="font-weight:700;color:var(--success);">${formatCurrency(p.amount)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                                <tfoot>
                                    <tr style="font-weight:700;background:var(--bg-tertiary);">
                                        <td>الإجمالي</td>
                                        <td>100%</td>
                                        <td>${(partnersAlloc?.percentage || 0).toFixed(1)}%</td>
                                        <td>${formatCurrency(partnersAmount)}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            ` : (partnersAmount > 0 ? `
                <div class="card" style="padding:18px;text-align:center;background:#fef3c7;border:1px solid #fbbf24;color:#92400e;">
                    <i class="fas fa-users" style="font-size:32px;margin-bottom:10px;"></i>
                    <p>هناك ${formatCurrency(partnersAmount)} مخصصة للشركاء، لكن لم تتم إضافة شركاء بعد.</p>
                    <button class="btn btn-primary btn-sm" onclick="showPartnersConfig()" style="margin-top:10px;">
                        <i class="fas fa-users-cog"></i> إعدادات الشركاء
                    </button>
                </div>
            ` : '')}
        `}
    `;

    // ====== المخططات ======
    if (netProfit > 0) {
        setTimeout(() => {
            // مخطط الفئات
            const allocCanvas = document.getElementById('allocChart');
            if (allocCanvas) {
                const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
                distCharts.alloc = new Chart(allocCanvas, {
                    type: 'doughnut',
                    data: {
                        labels: allocationResults.map(a => `${a.name} (${a.percentage.toFixed(1)}%)`),
                        datasets: [{
                            data: allocationResults.map(a => Math.max(a.amount, 0)),
                            backgroundColor: allocationResults.map(a => a.color),
                            borderWidth: 2,
                            borderColor: isDark ? '#1e293b' : '#fff'
                        }]
                    },
                    options: {
                        responsive: true, maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'bottom', labels: { color: isDark ? '#cbd5e1' : '#475569', font: { family: 'Cairo', size: 11 }, padding: 8, usePointStyle: true } },
                            tooltip: { callbacks: { label: ctx => `${ctx.label}: ${formatCurrency(ctx.parsed)}` } }
                        }
                    }
                });
            }

            // مخطط الشركاء
            if (partners.length && partnersAmount > 0) {
                const partnersCanvas = document.getElementById('partnersChart');
                if (partnersCanvas) {
                    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
                    const colors = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4', '#ec4899', '#84cc16'];
                    distCharts.partners = new Chart(partnersCanvas, {
                        type: 'doughnut',
                        data: {
                            labels: partnerShares.map(p => `${p.name} (${p.percentage.toFixed(1)}%)`),
                            datasets: [{
                                data: partnerShares.map(p => Math.max(p.amount, 0)),
                                backgroundColor: colors,
                                borderWidth: 2,
                                borderColor: isDark ? '#1e293b' : '#fff'
                            }]
                        },
                        options: {
                            responsive: true, maintainAspectRatio: false,
                            plugins: {
                                legend: { position: 'bottom', labels: { color: isDark ? '#cbd5e1' : '#475569', font: { family: 'Cairo', size: 11 }, padding: 8, usePointStyle: true } },
                                tooltip: { callbacks: { label: ctx => `${ctx.label}: ${formatCurrency(ctx.parsed)}` } }
                            }
                        }
                    });
                }
            }
        }, 50);
    }

    // احفظ البيانات لاستخدامها في PDF
    window._distData = {
        period: currentDistPeriod,
        from: currentDistFrom, to: currentDistTo,
        clinicRevenue, labRevenue, totalRevenue,
        totalExpense, totalSalaries, netProfit,
        allocationResults, partnerShares,
        partnersAmount, partnersAllocPct: partnersAlloc?.percentage || 0
    };
}

// ============== تصدير PDF ==============
async function exportProfitDistributionPDF() {
    const data = window._distData;
    if (!data) {
        showToast('يجب تحميل البيانات أولاً', 'warning');
        return;
    }
    if (data.netProfit <= 0) {
        showToast('لا يوجد ربح لتصدير تقريره', 'warning');
        return;
    }

    const periodLabels = {
        today: 'اليوم', week: 'آخر 7 أيام', month: 'هذا الشهر',
        lastMonth: 'الشهر الماضي', year: 'هذه السنة', all: 'كل الفترات',
        custom: `${data.from || ''} إلى ${data.to || ''}`
    };
    const periodLabel = periodLabels[data.period] || '';

    // جدول الفئات
    const allocRows = data.allocationResults.map(a => ({
        name: a.name,
        pct: `${a.percentage.toFixed(1)}%`,
        amount: formatCurrency(a.amount)
    }));

    // قسم تفصيل الشركاء (إن وُجد)
    const partnersSection = data.partnerShares.length > 0 ? [{
        title: `المرحلة 2 — تفصيل تقسيم حصة الشركاء (${formatCurrency(data.partnersAmount)})`,
        html: `
            <table style="width:100%;border-collapse:collapse;">
                <thead>
                    <tr>
                        <th style="background:#0d9488;color:#fff;padding:8px;border:1px solid #064e3b;">الشريك</th>
                        <th style="background:#0d9488;color:#fff;padding:8px;border:1px solid #064e3b;">نسبة الشريك</th>
                        <th style="background:#0d9488;color:#fff;padding:8px;border:1px solid #064e3b;">من الإجمالي</th>
                        <th style="background:#0d9488;color:#fff;padding:8px;border:1px solid #064e3b;">الحصة (د.ل)</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.partnerShares.map((p, i) => `
                        <tr style="background:${i % 2 === 0 ? '#fff' : '#f1f5f9'};">
                            <td style="padding:7px;border:1px solid #ddd;"><strong>${p.name}</strong></td>
                            <td style="padding:7px;border:1px solid #ddd;">${p.percentage.toFixed(1)}%</td>
                            <td style="padding:7px;border:1px solid #ddd;color:#64748b;">${p.percentageOfTotal.toFixed(1)}%</td>
                            <td style="padding:7px;border:1px solid #ddd;font-weight:700;color:#10b981;">${formatCurrency(p.amount)}</td>
                        </tr>
                    `).join('')}
                </tbody>
                <tfoot>
                    <tr style="background:#e2e8f0;font-weight:700;">
                        <td style="padding:7px;border:1px solid #ddd;">الإجمالي</td>
                        <td style="padding:7px;border:1px solid #ddd;">100%</td>
                        <td style="padding:7px;border:1px solid #ddd;">${data.partnersAllocPct.toFixed(1)}%</td>
                        <td style="padding:7px;border:1px solid #ddd;">${formatCurrency(data.partnersAmount)}</td>
                    </tr>
                </tfoot>
            </table>
        `
    }] : [];

    await generatePDFReport({
        title: 'تقرير تخصيص وتقسيم الأرباح',
        subtitle: `الفترة: ${periodLabel}`,
        filename: `تخصيص_الأرباح_${getTodayString()}.pdf`,
        columns: [
            { key: 'name',   label: 'الفئة',   width: '50%' },
            { key: 'pct',    label: 'النسبة',  width: '20%' },
            { key: 'amount', label: 'القيمة', width: '30%' }
        ],
        rows: allocRows,
        summary: [
            { label: 'إجمالي الإيرادات', value: formatCurrency(data.totalRevenue) },
            { label: 'إجمالي المصروفات + الرواتب', value: formatCurrency(data.totalExpense + data.totalSalaries) },
            { label: 'صافي الربح', value: formatCurrency(data.netProfit), highlight: true }
        ],
        extraSections: [
            {
                title: 'المرحلة 1 — تفاصيل الحسابات',
                html: `
                    <table style="width:100%;font-size:13px;">
                        <tr><td style="padding:4px;">إيرادات العيادة</td><td style="padding:4px;text-align:left;">${formatCurrency(data.clinicRevenue)}</td></tr>
                        <tr><td style="padding:4px;">إيرادات Lab to Lab</td><td style="padding:4px;text-align:left;">${formatCurrency(data.labRevenue)}</td></tr>
                        <tr style="background:#f1f5f9;font-weight:700;"><td style="padding:4px;">إجمالي الإيرادات</td><td style="padding:4px;text-align:left;">${formatCurrency(data.totalRevenue)}</td></tr>
                        <tr><td style="padding:4px;">المصروفات</td><td style="padding:4px;text-align:left;color:#ef4444;">- ${formatCurrency(data.totalExpense)}</td></tr>
                        <tr><td style="padding:4px;">الرواتب المصروفة</td><td style="padding:4px;text-align:left;color:#ef4444;">- ${formatCurrency(data.totalSalaries)}</td></tr>
                        <tr style="background:#d1fae5;font-weight:700;font-size:14px;"><td style="padding:6px;">= صافي الربح القابل للتقسيم</td><td style="padding:6px;text-align:left;color:#10b981;">${formatCurrency(data.netProfit)}</td></tr>
                    </table>
                `
            },
            ...partnersSection
        ]
    });
}
