/**
 * دوال مساعدة عامة
 */

// تنسيق العملة
function formatCurrency(amount, withSymbol = true) {
    const num = Number(amount) || 0;
    const formatted = num.toLocaleString('ar-LY', { 
        minimumFractionDigits: 2, 
        maximumFractionDigits: 2 
    });
    return withSymbol ? `${formatted} د.ل` : formatted;
}

// تنسيق التاريخ
function formatDate(dateStr, includeTime = false) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        ...(includeTime && { hour: '2-digit', minute: '2-digit' })
    };
    return date.toLocaleDateString('ar-LY', options);
}

// تنسيق التاريخ للحقول
function formatDateInput(dateStr) {
    if (!dateStr) return new Date().toISOString().split('T')[0];
    return new Date(dateStr).toISOString().split('T')[0];
}

function formatDateTimeInput(dateStr) {
    if (!dateStr) {
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        return now.toISOString().slice(0, 16);
    }
    const d = new Date(dateStr);
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
}

// عرض إشعار Toast
function showToast(message, type = 'success', duration = 3000) {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    toast.innerHTML = `
        <i class="fas ${icons[type] || icons.info}"></i>
        <div class="toast-message">${message}</div>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.transition = 'all 0.3s';
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-20px)';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// تأكيد إجراء
function confirmAction(message, callback, title = 'تأكيد', danger = true) {
    const dialog = document.getElementById('confirmDialog');
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMessage').textContent = message;
    
    const confirmBtn = document.getElementById('confirmYes');
    const newBtn = confirmBtn.cloneNode(true);
    confirmBtn.parentNode.replaceChild(newBtn, confirmBtn);
    
    newBtn.className = danger ? 'btn btn-danger' : 'btn btn-primary';
    newBtn.onclick = () => {
        callback();
        closeConfirm();
    };
    
    dialog.classList.remove('hidden');
}

function closeConfirm() {
    document.getElementById('confirmDialog').classList.add('hidden');
}

// مودال عام
function showModal(title, body, footer = '', size = '') {
    const overlay = document.getElementById('modalOverlay');
    const modal = document.getElementById('modal');
    
    modal.className = 'modal' + (size ? ` modal-${size}` : '');
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = body;
    document.getElementById('modalFooter').innerHTML = footer;
    
    overlay.classList.remove('hidden');
}

function closeModal() {
    document.getElementById('modalOverlay').classList.add('hidden');
}

function closeModalOnOverlay(event) {
    if (event.target.id === 'modalOverlay') {
        closeModal();
    }
}

// الحصول على التاريخ الحالي
function getCurrentDateTime() {
    return new Date().toISOString();
}

function getTodayString() {
    return new Date().toISOString().split('T')[0];
}

// الفلترة حسب الفترة الزمنية
function filterByPeriod(items, period, dateField = 'date') {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    return items.filter(item => {
        const itemDate = new Date(item[dateField]);
        
        switch (period) {
            case 'today':
                return itemDate >= today;
            case 'yesterday':
                const yesterday = new Date(today);
                yesterday.setDate(yesterday.getDate() - 1);
                return itemDate >= yesterday && itemDate < today;
            case 'week':
                const weekStart = new Date(today);
                weekStart.setDate(weekStart.getDate() - 7);
                return itemDate >= weekStart;
            case 'month':
                const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
                return itemDate >= monthStart;
            case 'lastMonth':
                const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
                const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 1);
                return itemDate >= lastMonthStart && itemDate < lastMonthEnd;
            case 'year':
                const yearStart = new Date(now.getFullYear(), 0, 1);
                return itemDate >= yearStart;
            default:
                return true;
        }
    });
}

// مجموع الحقل
function sumField(items, field) {
    return items.reduce((sum, item) => sum + (Number(item[field]) || 0), 0);
}

// تجميع حسب حقل
function groupBy(items, field) {
    return items.reduce((groups, item) => {
        const key = item[field];
        if (!groups[key]) groups[key] = [];
        groups[key].push(item);
        return groups;
    }, {});
}

// تنزيل ملف JSON
function downloadJSON(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

// تصدير CSV
function exportToCSV(data, filename, headers) {
    if (!data || data.length === 0) {
        showToast('لا توجد بيانات للتصدير', 'warning');
        return;
    }
    
    let csv = '\uFEFF'; // BOM للغة العربية
    csv += headers.map(h => h.label).join(',') + '\n';
    
    data.forEach(row => {
        csv += headers.map(h => {
            let val = row[h.key];
            if (h.format) val = h.format(val);
            if (val === null || val === undefined) val = '';
            val = String(val).replace(/"/g, '""');
            if (val.includes(',') || val.includes('\n')) val = `"${val}"`;
            return val;
        }).join(',') + '\n';
    });
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    showToast('تم التصدير بنجاح', 'success');
}

// تبديل الشريط الجانبي للموبايل
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('open');
    overlay.classList.toggle('show');
}

// تبديل الوضع الليلي والنهاري
async function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    document.getElementById('themeIcon').className = `fas fa-${newTheme === 'light' ? 'moon' : 'sun'}`;
    document.querySelector('meta[name="theme-color"]').setAttribute('content', newTheme === 'light' ? '#0d9488' : '#0f172a');
    
    localStorage.setItem('theme', newTheme);
    
    // تحديث الإعدادات في القاعدة
    try {
        const settings = await db.get('settings', 'main');
        if (settings) {
            settings.theme = newTheme;
            await db.update('settings', settings);
        }
    } catch (e) { /* ignore */ }
    
    // إعادة رسم الرسوم البيانية
    if (typeof refreshAllCharts === 'function') {
        setTimeout(refreshAllCharts, 100);
    }
}

// تهيئة الوضع الليلي عند البدء
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
        themeIcon.className = `fas fa-${savedTheme === 'light' ? 'moon' : 'sun'}`;
    }
}

// الإشعارات
async function showNotifications() {
    const suppliers = await db.getAll('suppliers');
    const overdueDebts = suppliers.filter(s => (s.totalDebt - s.paidAmount) > 0);
    
    let html = '';
    if (overdueDebts.length === 0) {
        html = `
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <h3>لا توجد إشعارات</h3>
                <p>كل شيء على ما يرام!</p>
            </div>
        `;
    } else {
        html = '<div style="display:flex;flex-direction:column;gap:10px;">';
        overdueDebts.forEach(s => {
            const remaining = s.totalDebt - s.paidAmount;
            html += `
                <div class="list-item">
                    <div class="list-icon" style="background:var(--warning-bg);color:var(--warning);">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="list-content">
                        <div class="list-title">${s.name}</div>
                        <div class="list-meta">دين متبقي: ${formatCurrency(remaining)}</div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    showModal('الإشعارات', html, '<button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>');
}

// تحديث شارة الإشعارات
async function updateNotificationBadge() {
    try {
        const suppliers = await db.getAll('suppliers');
        const overdueCount = suppliers.filter(s => (s.totalDebt - s.paidAmount) > 0).length;
        const badge = document.getElementById('notificationBadge');
        if (badge) {
            if (overdueCount > 0) {
                badge.textContent = overdueCount;
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }
        }
    } catch (e) { /* ignore */ }
}

// تحديث التاريخ الحالي في الشريط العلوي
function updateCurrentDate() {
    const el = document.getElementById('currentDate');
    if (el) {
        el.textContent = new Date().toLocaleDateString('ar-LY', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
}

// تأخير دالة البحث
function debounce(func, delay = 300) {
    let timer;
    return function(...args) {
        clearTimeout(timer);
        timer = setTimeout(() => func.apply(this, args), delay);
    };
}

// حساب الفرق بين تاريخين بالأيام
function daysBetween(date1, date2) {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    const diff = Math.abs(d2 - d1);
    return Math.floor(diff / (1000 * 60 * 60 * 24));
}

// عدد أيام الشهر
function daysInMonth(year, month) {
    return new Date(year, month + 1, 0).getDate();
}

// طباعة المحتوى
function printElement(elementId) {
    const printContent = document.getElementById(elementId);
    if (!printContent) return;

    // Build a fully self-contained HTML document and load it via a Blob URL
    // so the browser receives an explicit text/html;charset=utf-8 response.
    // (document.write() can mangle Arabic characters in some browsers because
    // the charset meta tag may be parsed after the bytes have already been
    // decoded with the parent document's encoding.)
    const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>طباعة</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;800&family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body { font-family: 'Cairo', 'Tajawal', 'Segoe UI', Tahoma, Arial, sans-serif; padding: 20px; direction: rtl; color: #000; }
        .receipt { max-width: 80mm; margin: 0 auto; }
        .receipt-header { text-align: center; border-bottom: 2px dashed #000; padding-bottom: 12px; margin-bottom: 12px; }
        .receipt-header h2 { font-size: 18px; margin: 0 0 4px; }
        .receipt-header h3 { font-size: 15px; margin: 6px 0; }
        .receipt-header p { font-size: 12px; margin: 2px 0; }
        .receipt-body div { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; border-bottom: 1px dotted #ccc; }
        .receipt-footer { text-align: center; margin-top: 16px; padding-top: 12px; border-top: 2px dashed #000; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 12px; }
        table th, table td { padding: 4px 6px; text-align: right; border-bottom: 1px solid #ddd; }
        table th { background: #f3f4f6; font-weight: 700; }
        .receipt-total { background: #0d9488; color: #fff; padding: 10px; text-align: center; margin-top: 12px; border-radius: 4px; font-weight: 700; }
        hr { border: none; border-top: 1px dashed #999; margin: 8px 0; }
        @media print {
            @page { margin: 5mm; }
            body { padding: 0; }
        }
    </style>
</head>
<body>${printContent.innerHTML}</body>
</html>`;

    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const printWindow = window.open(url, '_blank', 'width=800,height=600');

    if (!printWindow) {
        showToast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'warning');
        URL.revokeObjectURL(url);
        return;
    }

    // Wait for the document to load, then trigger print
    printWindow.addEventListener('load', () => {
        setTimeout(() => {
            printWindow.focus();
            printWindow.print();
            // Clean up the Blob URL after a delay to keep the printed window functional
            setTimeout(() => URL.revokeObjectURL(url), 5000);
        }, 300);
    });
}

// تنسيق الأرقام الكبيرة
function formatNumber(num) {
    return Number(num || 0).toLocaleString('ar-LY');
}

// التحقق من الصلاحيات
function hasPermission(permission) {
    const user = getCurrentUser();
    if (!user) return false;
    if (user.role === 'admin' || user.permissions?.includes('all')) return true;
    return user.permissions?.includes(permission);
}


// قراءة ملف صورة → data URL (لشعار المختبر)
function readImageAsDataURL(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

// حساب أيام العمل في الشهر (كل أيام الشهر عدا الجمعة)
function workingDaysInMonth(year, month) {
    // month: 0-11
    const lastDay = new Date(year, month + 1, 0).getDate();
    let count = 0;
    for (let d = 1; d <= lastDay; d++) {
        const dow = new Date(year, month, d).getDay();
        if (dow !== 5) count++; // 5 = Friday
    }
    return count;
}

// حساب أيام العمل في فترة بين تاريخين (شامل، عدا الجمعة)
function workingDaysInRange(fromDate, toDate) {
    let count = 0;
    const start = new Date(fromDate);
    const end = new Date(toDate);
    start.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        if (d.getDay() !== 5) count++;
    }
    return count;
}

// ===== Sorting utility =====
function sortRecords(records, sortBy) {
    const copy = [...records];
    switch (sortBy) {
        case 'date_desc':  return copy.sort((a,b) => new Date(b.date||b.createdAt||0) - new Date(a.date||a.createdAt||0));
        case 'date_asc':   return copy.sort((a,b) => new Date(a.date||a.createdAt||0) - new Date(b.date||b.createdAt||0));
        case 'amount_desc':return copy.sort((a,b) => Number(b.amount||b.totalDebt||b.dueAmount||0) - Number(a.amount||a.totalDebt||a.dueAmount||0));
        case 'amount_asc': return copy.sort((a,b) => Number(a.amount||a.totalDebt||a.dueAmount||0) - Number(b.amount||b.totalDebt||b.dueAmount||0));
        case 'name_asc':   return copy.sort((a,b) => (a.name||a.patientName||a.description||'').localeCompare(b.name||b.patientName||b.description||'','ar'));
        case 'name_desc':  return copy.sort((a,b) => (b.name||b.patientName||b.description||'').localeCompare(a.name||a.patientName||a.description||'','ar'));
        default:           return copy;
    }
}

// المكوّن المشترك لقائمة الفرز
function buildSortSelect(currentSort, onchangeFn) {
    return `
        <select class="filter-select" onchange="${onchangeFn}(this.value)" style="min-width:145px;">
            <option value="date_desc"  ${currentSort==='date_desc'  ?'selected':''}>⬇ الأحدث أولاً</option>
            <option value="date_asc"   ${currentSort==='date_asc'   ?'selected':''}>⬆ الأقدم أولاً</option>
            <option value="amount_desc"${currentSort==='amount_desc'?'selected':''}>⬇ الأعلى مبلغاً</option>
            <option value="amount_asc" ${currentSort==='amount_asc' ?'selected':''}>⬆ الأدنى مبلغاً</option>
            <option value="name_asc"   ${currentSort==='name_asc'   ?'selected':''}>أ-ي (الاسم)</option>
            <option value="name_desc"  ${currentSort==='name_desc'  ?'selected':''}>ي-أ (الاسم)</option>
        </select>
    `;
}
