// ===== PDF Export Module — تقارير PDF احترافية على ورق A4 =====
//
// المتطلبات:
// - A4: 210 × 297 mm
// - عند 96dpi → 794 × 1123 px
// - الهامش الافتراضي: 10mm من كل جانب
// - منطقة المحتوى: 190 × 277 mm (≈ 718 × 1047 px)
//
// الطريقة:
// 1) نُنشئ عنصر HTML بعرض ثابت = 190mm (= 718px في css-px)
// 2) نُمرّره لـ html2canvas بـ scale=2 لجودة ممتازة
// 3) نُغذي jsPDF بالصورة ونحدد عرضها = 190mm
// 4) إذا كان الارتفاع > 277mm، نقسم تلقائياً على صفحات A4

const A4_WIDTH_MM = 210;
const A4_HEIGHT_MM = 297;
const PDF_MARGIN_MM = 10;
const PDF_CONTENT_WIDTH_MM = A4_WIDTH_MM - (PDF_MARGIN_MM * 2);  // 190mm
const PDF_CONTENT_HEIGHT_MM = A4_HEIGHT_MM - (PDF_MARGIN_MM * 2); // 277mm

// عرض المحتوى بالبيكسل (لقاعدة 96dpi)
const PDF_CONTENT_WIDTH_PX = Math.round(PDF_CONTENT_WIDTH_MM * 3.78); // ≈ 718px

// ============================================================
// المولّد الرئيسي
// ============================================================
async function generatePDFReport(options) {
    showToast('جاري إنشاء ملف PDF...', 'info');

    const settings = await db.get('settings', 'main') || {};
    const labName = settings.labName || 'مختبر الهيثم للتحاليل الطبية';
    const labAddress = settings.labAddress || '';
    const labPhone = settings.labPhone || '';
    const labLogo = settings.labLogo || '';
    const currentUser = (typeof getCurrentUser === 'function' ? getCurrentUser() : null) || {};
    const userName = currentUser.fullName || currentUser.username || '';

    // الألوان المخصصة من إعدادات المستخدم
    const colors = settings.colors || {};
    const primary = colors.primary || '#0d9488';
    const primaryDark = colors.primaryDark || '#0f766e';
    const success = colors.success || '#10b981';
    const successLight = hexToRgbaSafe(success, 0.12);
    const primaryGradient = `linear-gradient(135deg, ${primary}, ${primaryDark})`;

    const now = new Date();
    const dateStr = now.toLocaleDateString('ar-LY', {
        year: 'numeric', month: 'long', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });

    const columns = options.columns || [];
    const rows = options.rows || [];

    // ===== بناء صفوف الجدول =====
    let tableRows = '';
    rows.forEach((row, idx) => {
        let cells = `<td class="num-col">${idx + 1}</td>`;
        columns.forEach(col => {
            let val = row[col.key];
            if (col.format) val = col.format(val, row);
            if (val === null || val === undefined) val = '-';
            cells += `<td>${val}</td>`;
        });
        tableRows += `<tr>${cells}</tr>`;
    });

    // ===== صفوف الملخص =====
    let summaryHtml = '';
    if (options.summary && options.summary.length) {
        summaryHtml = '<table class="summary-table">';
        options.summary.forEach(s => {
            const cls = s.highlight ? 'highlight' : '';
            summaryHtml += `<tr class="${cls}"><td>${s.label}</td><td>${s.value}</td></tr>`;
        });
        summaryHtml += '</table>';
    }

    // ===== أقسام إضافية =====
    let extraHtml = '';
    if (options.extraSections && options.extraSections.length) {
        options.extraSections.forEach(sec => {
            extraHtml += `
                <div class="extra-section">
                    <h3>${sec.title}</h3>
                    ${sec.html}
                </div>
            `;
        });
    }

    // ===== الشعار =====
    const logoHtml = labLogo
        ? `<img src="${labLogo}" alt="logo" class="lab-logo">`
        : `<div class="lab-logo-placeholder">🔬</div>`;

    const headerColCount = columns.length + 1;
    const headerCells = '<th class="num-col">#</th>' +
        columns.map(c => `<th${c.width ? ` style="width:${c.width}"` : ''}>${c.label}</th>`).join('');

    // ===== HTML الكامل للتقرير =====
    const reportHTML = `
<div id="pdfReportRoot" style="width:${PDF_CONTENT_WIDTH_PX}px;background:#fff;padding:0;font-family:'Cairo','Tajawal','Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#1f2937;line-height:1.5;font-size:11px;">

    <div class="pdf-header" style="display:flex;align-items:center;justify-content:space-between;padding-bottom:14px;border-bottom:3px solid ${primary};margin-bottom:14px;">
        <div style="display:flex;align-items:center;gap:14px;flex:1;">
            ${logoHtml}
            <div>
                <h1 style="font-size:18px;font-weight:800;color:${primary};margin:0 0 4px;">${labName}</h1>
                ${labAddress ? `<p style="font-size:11px;color:#64748b;margin:0;">📍 ${labAddress}</p>` : ''}
                ${labPhone ? `<p style="font-size:11px;color:#64748b;margin:0;">📞 ${labPhone}</p>` : ''}
            </div>
        </div>
        <div style="text-align:left;font-size:10px;color:#64748b;">
            <div><strong style="color:#1f2937;">تاريخ الطباعة:</strong></div>
            <div>${dateStr}</div>
            ${userName ? `<div style="margin-top:4px;"><strong style="color:#1f2937;">الموظف:</strong> ${userName}</div>` : ''}
        </div>
    </div>

    <div class="report-title-block" style="text-align:center;background:${primaryGradient};color:#fff;padding:12px 20px;border-radius:8px;margin-bottom:14px;">
        <h2 style="font-size:16px;font-weight:700;margin:0 0 4px;">${options.title}</h2>
        ${options.subtitle ? `<div style="font-size:11px;opacity:0.95;">${options.subtitle}</div>` : ''}
    </div>

    <table style="width:100%;border-collapse:collapse;margin-bottom:12px;font-size:10.5px;">
        <thead>
            <tr>${headerCells}</tr>
        </thead>
        <tbody>
            ${tableRows || `<tr><td colspan="${headerColCount}" style="text-align:center;color:#9ca3af;padding:25px;font-size:12px;border:1px solid #e5e7eb;">لا توجد بيانات للعرض</td></tr>`}
        </tbody>
    </table>

    ${summaryHtml}
    ${extraHtml}

    ${settings.printFooter ? `
    <div class="pdf-footer" style="margin-top:18px;padding-top:10px;border-top:1px dashed #cbd5e1;display:flex;justify-content:space-between;font-size:10px;color:#6b7280;">
        <div>${settings.printFooter}</div>
        <div>عدد السجلات: ${rows.length}</div>
    </div>
    ` : `
    <div class="pdf-footer" style="margin-top:18px;padding-top:10px;border-top:1px dashed #cbd5e1;text-align:left;font-size:10px;color:#6b7280;">
        عدد السجلات: ${rows.length}
    </div>
    `}
</div>

<style scoped>
    #pdfReportRoot table { width: 100%; border-collapse: collapse; }
    #pdfReportRoot thead th {
        background: ${primary} !important; color: #fff !important;
        padding: 8px 6px; text-align: right;
        font-weight: 700; font-size: 10.5px;
        border: 1px solid ${primaryDark};
    }
    #pdfReportRoot tbody td {
        padding: 6px;
        border: 1px solid #e5e7eb;
        background: #fff;
        text-align: right;
        font-size: 10.5px;
    }
    #pdfReportRoot tbody tr:nth-child(even) td { background: #f9fafb; }
    #pdfReportRoot .num-col {
        width: 28px; text-align: center; color: #6b7280; font-size: 10px;
    }
    #pdfReportRoot .summary-table {
        margin-top: 8px; width: 60%; margin-right: auto; margin-left: 0;
    }
    #pdfReportRoot .summary-table td {
        padding: 6px 10px; border: 1px solid #d1d5db; font-size: 11px;
    }
    #pdfReportRoot .summary-table td:first-child {
        background: #f3f4f6; font-weight: 700; color: #374151;
    }
    #pdfReportRoot .summary-table td:last-child {
        background: #fff; color: ${primary}; font-weight: 700; text-align: left;
    }
    #pdfReportRoot .summary-table tr.highlight td {
        background: ${successLight} !important; color: ${success}; font-size: 12px;
    }
    #pdfReportRoot .summary-table tr.highlight td:first-child {
        background: ${primary} !important; color: #fff;
    }
    #pdfReportRoot .extra-section { margin-top: 14px; }
    #pdfReportRoot .extra-section h3 {
        background: #f3f4f6; padding: 7px 11px;
        border-right: 4px solid ${primary};
        font-size: 12px; color: ${primary};
        margin: 0 0 8px;
    }
    #pdfReportRoot .lab-logo, #pdfReportRoot .lab-logo-placeholder {
        width: 60px; height: 60px;
        border-radius: 10px; object-fit: contain;
        background: ${primaryGradient};
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-size: 28px;
        flex-shrink: 0;
    }
</style>
    `;

    await renderHTMLToPDF(reportHTML, options.filename || `تقرير_${getTodayString()}.pdf`);
}

// ============================================================
// عَرض HTML على PDF — الواجهة الموحَّدة
// ============================================================
async function renderHTMLToPDF(html, filename) {
    // كشف iOS
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
                  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

    // أنشئ حاوياً مخفياً (خارج الشاشة لكن مرئيًا في DOM ليُلتقط بـ html2canvas)
    const wrapper = document.createElement('div');
    wrapper.style.cssText = `position:fixed;top:0;left:-9999px;width:${PDF_CONTENT_WIDTH_PX}px;background:#fff;z-index:-1;`;
    wrapper.innerHTML = html;
    document.body.appendChild(wrapper);

    const target = wrapper.querySelector('#pdfReportRoot');
    if (!target) {
        showToast('فشل بناء التقرير', 'error');
        wrapper.remove();
        return;
    }

    // انتظر تحميل الخطوط والصور قبل الالتقاط
    try { if (document.fonts?.ready) await document.fonts.ready; } catch (_) {}
    await new Promise(r => setTimeout(r, 50));

    try {
        // الخطوة 1: التقاط HTML كصورة (canvas)
        const canvas = await html2canvas(target, {
            scale: 2,                  // جودة عالية
            useCORS: true,
            backgroundColor: '#fff',
            logging: false,
            letterRendering: true,
            allowTaint: false,
            imageTimeout: 15000,
            width: PDF_CONTENT_WIDTH_PX,   // عرض ثابت = 718px
            windowWidth: PDF_CONTENT_WIDTH_PX
        });

        // الخطوة 2: إنشاء PDF بـ jsPDF
        // jsPDF متوفر عبر html2pdf.bundle عبر عدة مسارات
        const jsPDFCtor = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
        if (!jsPDFCtor) {
            throw new Error('jsPDF غير محمَّل');
        }
        const pdf = new jsPDFCtor({
            orientation: 'portrait',
            unit: 'mm',
            format: 'a4',
            compress: true
        });

        // أبعاد الصورة بالمليمتر
        // العرض = 190mm (ثابت)
        // الارتفاع نحسبه نسبياً
        const imgWidthMM = PDF_CONTENT_WIDTH_MM;
        const imgHeightMM = (canvas.height * imgWidthMM) / canvas.width;
        const pageHeightAvailable = PDF_CONTENT_HEIGHT_MM;

        const imgData = canvas.toDataURL('image/jpeg', 0.92);

        // الخطوة 3: تقسيم على صفحات A4 إذا كان المحتوى طويلاً
        if (imgHeightMM <= pageHeightAvailable) {
            // يدخل في صفحة واحدة
            pdf.addImage(imgData, 'JPEG', PDF_MARGIN_MM, PDF_MARGIN_MM, imgWidthMM, imgHeightMM, '', 'FAST');
        } else {
            // المحتوى أطول من صفحة A4 — نضع الصورة كاملة في كل صفحة لكن مع إزاحة سالبة
            // بحيث يظهر جزء مختلف منها في كل صفحة. باقي المساحة خارج حدود الصفحة (مقصوصة).
            let pageIdx = 0;
            let yOffset = PDF_MARGIN_MM; // أول صفحة تبدأ من أعلى الهامش
            let consumed = 0;            // كم مللي مستهلك من الصورة

            while (consumed < imgHeightMM) {
                if (pageIdx > 0) {
                    pdf.addPage();
                    yOffset = PDF_MARGIN_MM - consumed; // إزاحة سالبة بحجم ما تمّ عرضه
                }
                // أضف الصورة كاملة لكن jsPDF يقصّ ما خرج عن حدود الصفحة
                pdf.addImage(imgData, 'JPEG', PDF_MARGIN_MM, yOffset, imgWidthMM, imgHeightMM, '', 'FAST');
                consumed += pageHeightAvailable;
                pageIdx++;
                if (pageIdx > 50) { console.warn('PDF too long, truncated'); break; }
            }
        }

        // الخطوة 4: حفظ أو فتح
        const safeFilename = filename || `تقرير_${getTodayString()}.pdf`;

        if (isIOS) {
            // iOS: افتح في نافذة جديدة
            const blob = pdf.output('blob');
            const blobUrl = URL.createObjectURL(blob);
            const newTab = window.open(blobUrl, '_blank');
            if (!newTab) {
                showPDFFallbackDialog(blobUrl, safeFilename);
            } else {
                showToast('تم فتح الملف — استخدم زر المشاركة 📤 لحفظه أو إرساله', 'success');
            }
            setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
        } else {
            // ويندوز/أندرويد/ماك: تنزيل مباشر
            pdf.save(safeFilename);
            showToast('تم تصدير الملف PDF بنجاح', 'success');
        }
    } catch (e) {
        console.error('PDF generation error:', e);
        showToast('حدث خطأ في توليد الملف: ' + (e.message || 'خطأ غير معروف'), 'error');
    } finally {
        if (wrapper.parentNode) wrapper.parentNode.removeChild(wrapper);
    }
}

// ============================================================
// تصدير عنصر DOM موجود كـ PDF
// ============================================================
async function exportElementToPDF(elementId, filename = 'report.pdf') {
    const el = document.getElementById(elementId);
    if (!el) {
        showToast('العنصر غير موجود', 'error');
        return;
    }

    // استنسخه ولفّه في عنصر بعرض A4
    const clone = el.cloneNode(true);
    const html = `
        <div id="pdfReportRoot" style="width:${PDF_CONTENT_WIDTH_PX}px;background:#fff;padding:0;font-family:'Cairo','Tajawal',sans-serif;direction:rtl;color:#1f2937;">
            ${clone.outerHTML}
        </div>
    `;
    await renderHTMLToPDF(html, filename);
}

// ============================================================
// النافذة البديلة عند منع الفتح التلقائي على iOS
// ============================================================
function showPDFFallbackDialog(blobUrl, filename) {
    const body = `
        <div style="text-align:center;padding:10px;">
            <i class="fas fa-file-pdf" style="font-size:48px;color:#dc2626;margin-bottom:14px;"></i>
            <h3 style="margin-bottom:10px;">الملف جاهز</h3>
            <p style="color:var(--text-secondary);margin-bottom:18px;font-size:14px;">
                المتصفح منع الفتح التلقائي.<br>
                اضغط الزر أدناه لفتح الملف ثم استخدم زر المشاركة لحفظه.
            </p>
            <a href="${blobUrl}" target="_blank" rel="noopener" download="${filename}"
               class="btn btn-primary" style="display:inline-flex;align-items:center;gap:8px;text-decoration:none;font-size:14px;">
                <i class="fas fa-download"></i> فتح / تحميل الملف
            </a>
        </div>
    `;
    showModal('ملف PDF جاهز', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
    `);
}

// Safe hex→rgba helper (مكرر هنا لتجنب الاعتماد على settings.js)
function hexToRgbaSafe(hex, alpha = 1) {
    if (!hex) return `rgba(16,185,129,${alpha})`;
    const m = String(hex).replace('#', '').match(/.{2}/g);
    if (!m || m.length < 3) return hex;
    const [r, g, b] = m.map(x => parseInt(x, 16));
    return `rgba(${r},${g},${b},${alpha})`;
}
