/**
 * لوحة التحكم Dashboard
 */

let dashboardCharts = {};

async function renderDashboard() {
    // عرض شاشة تحميل فورية
    const contentEl = document.getElementById('content');
    if (contentEl) {
        contentEl.innerHTML = '<div style="text-align:center;padding:60px 20px;"><i class="fas fa-spinner fa-spin" style="font-size:36px;color:var(--primary);"></i><p style="margin-top:14px;color:var(--text-secondary);">جاري تحميل البيانات...</p></div>';
    }

    // جلب كل البيانات بالتوازي بدل التسلسل
    const [revenues, expenses, labToLab, suppliers, employees, paymentMethods] = await Promise.all([
        db.getAll('revenues'),
        db.getAll('expenses'),
        db.getAll('labToLab'),
        db.getAll('suppliers'),
        db.getAll('employees'),
        db.getAll('paymentMethods')
    ]);
    
    // الفلترة حسب الفترة
    const todayRevenues = filterByPeriod(revenues, 'today');
    const monthRevenues = filterByPeriod(revenues, 'month');
    const lastMonthRevenues = filterByPeriod(revenues, 'lastMonth');
    
    const todayExpenses = filterByPeriod(expenses, 'today');
    const monthExpenses = filterByPeriod(expenses, 'month');
    
    const totalTodayRevenue = sumField(todayRevenues, 'amount');
    const totalMonthRevenue = sumField(monthRevenues, 'amount');
    const totalLastMonthRevenue = sumField(lastMonthRevenues, 'amount');
    
    const totalTodayExpense = sumField(todayExpenses, 'amount');
    const totalMonthExpense = sumField(monthExpenses, 'amount');
    
    const netProfit = totalMonthRevenue - totalMonthExpense;
    
    // مقارنة بالشهر الماضي
    const revenueChange = totalLastMonthRevenue > 0 
        ? ((totalMonthRevenue - totalLastMonthRevenue) / totalLastMonthRevenue * 100).toFixed(1)
        : 100;
    
    // إجمالي الديون
    const totalDebt = suppliers.reduce((sum, s) => sum + (s.totalDebt - s.paidAmount), 0);
    
    // إيرادات LAB to LAB
    const labRevenue = sumField(labToLab.filter(l => l.paymentStatus === 'paid'), 'price');
    
    const html = `
        <div class="page-header">
            <h2><i class="fas fa-chart-pie"></i> لوحة التحكم</h2>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-primary" onclick="navigateTo('revenues'); setTimeout(() => showRevenueModal(), 100)">
                    <i class="fas fa-plus"></i> إيراد جديد
                </button>
            </div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card revenue">
                <div class="stat-icon"><i class="fas fa-arrow-trend-up"></i></div>
                <div class="stat-label">إيرادات اليوم</div>
                <div class="stat-value">${formatCurrency(totalTodayRevenue)}</div>
                <div class="stat-meta">
                    <span>${todayRevenues.length} عملية</span>
                </div>
            </div>
            
            <div class="stat-card revenue">
                <div class="stat-icon"><i class="fas fa-coins"></i></div>
                <div class="stat-label">إيرادات الشهر</div>
                <div class="stat-value">${formatCurrency(totalMonthRevenue)}</div>
                <div class="stat-meta">
                    ${revenueChange >= 0 
                        ? `<span class="stat-trend up"><i class="fas fa-arrow-up"></i> ${revenueChange}%</span>`
                        : `<span class="stat-trend down"><i class="fas fa-arrow-down"></i> ${Math.abs(revenueChange)}%</span>`}
                    <span>مقارنة بالشهر الماضي</span>
                </div>
            </div>
            
            <div class="stat-card expense">
                <div class="stat-icon"><i class="fas fa-receipt"></i></div>
                <div class="stat-label">مصروفات الشهر</div>
                <div class="stat-value">${formatCurrency(totalMonthExpense)}</div>
                <div class="stat-meta">
                    <span>${monthExpenses.length} عملية</span>
                </div>
            </div>
            
            <div class="stat-card profit">
                <div class="stat-icon"><i class="fas fa-sack-dollar"></i></div>
                <div class="stat-label">صافي الربح الشهري</div>
                <div class="stat-value" style="color:${netProfit >= 0 ? 'var(--success)' : 'var(--danger)'}">${formatCurrency(netProfit)}</div>
                <div class="stat-meta">
                    <span>${netProfit >= 0 ? 'ربح' : 'خسارة'}</span>
                </div>
            </div>
            
            <div class="stat-card debt">
                <div class="stat-icon"><i class="fas fa-handshake"></i></div>
                <div class="stat-label">إجمالي الديون</div>
                <div class="stat-value">${formatCurrency(totalDebt)}</div>
                <div class="stat-meta">
                    <span>${suppliers.length} مورد</span>
                </div>
            </div>
            
            <div class="stat-card lab">
                <div class="stat-icon"><i class="fas fa-vial"></i></div>
                <div class="stat-label">إيرادات Lab to Lab</div>
                <div class="stat-value">${formatCurrency(labRevenue)}</div>
                <div class="stat-meta">
                    <span>${labToLab.length} عينة</span>
                </div>
            </div>
            
            <div class="stat-card employees">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-label">عدد الموظفين</div>
                <div class="stat-value">${employees.filter(e => e.active !== false).length}</div>
                <div class="stat-meta">
                    <span>إجمالي الفريق</span>
                </div>
            </div>
        </div>
        
        <div class="charts-grid">
            <div class="chart-container">
                <div class="card-header">
                    <div class="card-title">
                        <i class="fas fa-chart-line"></i>
                        الإيرادات والمصروفات (آخر 30 يوماً)
                    </div>
                </div>
                <div style="position:relative;height:280px;width:100%;"><canvas id="trendChart"></canvas></div>
            </div>
            
            <div class="chart-container">
                <div class="card-header">
                    <div class="card-title">
                        <i class="fas fa-chart-pie"></i>
                        طرق الدفع
                    </div>
                </div>
                <div style="position:relative;height:280px;width:100%;"><canvas id="paymentChart"></canvas></div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="fas fa-clock"></i>
                    آخر العمليات المالية
                </div>
                <button class="btn btn-sm btn-secondary" onclick="navigateTo('revenues')">
                    عرض الكل <i class="fas fa-arrow-left"></i>
                </button>
            </div>
            ${renderRecentTransactions(revenues, expenses, paymentMethods)}
        </div>
    `;
    
    document.getElementById('content').innerHTML = html;
    
    // رسم المخططات
    setTimeout(() => {
        renderTrendChart(revenues, expenses);
        renderPaymentChart(revenues, paymentMethods);
    }, 100);
}

function renderRecentTransactions(revenues, expenses, paymentMethods) {
    const allTransactions = [
        ...revenues.map(r => ({ ...r, type: 'revenue' })),
        ...expenses.map(e => ({ ...e, type: 'expense' }))
    ].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 8);
    
    if (allTransactions.length === 0) {
        return `
            <div class="empty-state">
                <i class="fas fa-inbox"></i>
                <h3>لا توجد عمليات بعد</h3>
                <p>ابدأ بإضافة أول عملية مالية</p>
            </div>
        `;
    }
    
    const methodsMap = Object.fromEntries(paymentMethods.map(m => [m.id, m]));
    
    let html = '<div style="display:flex;flex-direction:column;gap:8px;">';
    allTransactions.forEach(t => {
        const isRevenue = t.type === 'revenue';
        const method = isRevenue ? methodsMap[t.paymentMethod] : null;
        const title = isRevenue ? (t.patientName || t.description) : t.description;
        const subtitle = isRevenue ? t.description : (t.notes || 'مصروف');
        
        html += `
            <div class="list-item">
                <div class="list-icon" style="background:${isRevenue ? 'var(--success-bg)' : 'var(--danger-bg)'};color:${isRevenue ? 'var(--success)' : 'var(--danger)'};">
                    <i class="fas ${isRevenue ? 'fa-arrow-down' : 'fa-arrow-up'}"></i>
                </div>
                <div class="list-content">
                    <div class="list-title">${title || '-'}</div>
                    <div class="list-meta">
                        ${formatDate(t.date, true)}
                        ${method ? ` • <i class="fas ${method.icon}"></i> ${method.name}` : ''}
                    </div>
                </div>
                <div class="list-amount" style="color:${isRevenue ? 'var(--success)' : 'var(--danger)'};">
                    ${isRevenue ? '+' : '-'} ${formatCurrency(t.amount)}
                </div>
            </div>
        `;
    });
    html += '</div>';
    
    return html;
}

function renderTrendChart(revenues, expenses) {
    const canvas = document.getElementById('trendChart');
    if (!canvas) return;
    
    // تجميع البيانات لآخر 30 يوماً
    const days = 30;
    const labels = [];
    const revenueData = [];
    const expenseData = [];
    
    for (let i = days - 1; i >= 0; i--) {
        const date = new Date();
        date.setHours(0, 0, 0, 0);
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        labels.push(date.toLocaleDateString('ar-LY', { day: 'numeric', month: 'short' }));
        
        // مطابقة تواريخ متعدّدة الأشكال (YYYY-MM-DD أو ISO كامل)
        const dayRevenues = revenues.filter(r => {
            if (!r.date) return false;
            return String(r.date).slice(0, 10) === dateStr;
        });
        const dayExpenses = expenses.filter(e => {
            if (!e.date) return false;
            return String(e.date).slice(0, 10) === dateStr;
        });
        
        revenueData.push(sumField(dayRevenues, 'amount'));
        expenseData.push(sumField(dayExpenses, 'amount'));
    }
    
    if (dashboardCharts.trend) {
        try { dashboardCharts.trend.destroy(); } catch(_){}
        dashboardCharts.trend = null;
    }
    
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const textColor = isDark ? '#cbd5e1' : '#475569';
    const gridColor = isDark ? '#334155' : '#e2e8f0';
    
    // أزل أي رسالة فراغ سابقة
    const oldMsg = canvas.parentElement.querySelector('.chart-empty-msg');
    if (oldMsg) oldMsg.remove();
    canvas.style.display = '';
    
    // ارسم المخطط دائماً (حتى لو كل القيم أصفار - يظهر المحور الزمني)
    const totalSum = [...revenueData, ...expenseData].reduce((a, b) => a + b, 0);
    
    dashboardCharts.trend = new Chart(canvas, {
        type: 'line',
        data: {
            labels,
            datasets: [
                {
                    label: 'الإيرادات',
                    data: revenueData,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16,185,129,0.1)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 2.5,
                    pointRadius: 0,
                    pointHoverRadius: 5
                },
                {
                    label: 'المصروفات',
                    data: expenseData,
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239,68,68,0.1)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 2.5,
                    pointRadius: 0,
                    pointHoverRadius: 5
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { intersect: false, mode: 'index' },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: textColor, font: { family: 'Cairo', size: 12 } }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.dataset.label}: ${formatCurrency(ctx.parsed.y)}`
                    }
                }
            },
            scales: {
                x: {
                    ticks: { color: textColor, font: { family: 'Cairo' }, maxRotation: 0, autoSkip: true, maxTicksLimit: 10 },
                    grid: { color: gridColor, display: false }
                },
                y: {
                    ticks: { 
                        color: textColor, 
                        font: { family: 'Cairo' },
                        callback: (val) => formatNumber(val)
                    },
                    grid: { color: gridColor }
                }
            }
        }
    });
}

function renderPaymentChart(revenues, paymentMethods) {
    const canvas = document.getElementById('paymentChart');
    if (!canvas) return;
    
    // آخر 30 يوماً (بدل الشهر الحالي - أكثر فائدة للوحة التحكم)
    const cutoff = new Date();
    cutoff.setHours(0, 0, 0, 0);
    cutoff.setDate(cutoff.getDate() - 30);
    const recentRevenues = revenues.filter(r => {
        if (!r.date) return false;
        const d = new Date(r.date);
        return !isNaN(d) && d >= cutoff;
    });
    
    const data = {};
    recentRevenues.forEach(r => {
        const method = paymentMethods.find(m => m.id === r.paymentMethod);
        const name = method?.name || 'غير محدد';
        data[name] = (data[name] || 0) + Number(r.amount || 0);
    });
    
    const labels = Object.keys(data);
    const values = Object.values(data);
    const colors = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#06b6d4', '#ec4899', '#64748b'];
    
    if (dashboardCharts.payment) {
        try { dashboardCharts.payment.destroy(); } catch(_){}
        dashboardCharts.payment = null;
    }
    
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const textColor = isDark ? '#cbd5e1' : '#475569';
    
    if (labels.length === 0) {
        const parent = canvas.parentElement;
        let emptyMsg = parent.querySelector('.chart-empty-msg');
        if (!emptyMsg) {
            emptyMsg = document.createElement('div');
            emptyMsg.className = 'chart-empty-msg empty-state';
            emptyMsg.style.cssText = 'padding:40px 20px;text-align:center;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;';
            emptyMsg.innerHTML = '<i class="fas fa-chart-pie" style="font-size:36px;color:#94a3b8;"></i><p style="margin-top:10px;color:#64748b;">لا توجد بيانات إيرادات في آخر 30 يوم</p>';
            canvas.style.display = 'none';
            parent.appendChild(emptyMsg);
        }
        return;
    }
    
    // أزل رسالة الفراغ السابقة إن وُجدت
    const oldMsg = canvas.parentElement.querySelector('.chart-empty-msg');
    if (oldMsg) oldMsg.remove();
    canvas.style.display = '';
    
    dashboardCharts.payment = new Chart(canvas, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{
                data: values,
                backgroundColor: colors,
                borderWidth: 0,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { 
                        color: textColor, 
                        font: { family: 'Cairo', size: 12 },
                        padding: 12,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.label}: ${formatCurrency(ctx.parsed)}`
                    }
                }
            }
        }
    });
}

function refreshAllCharts() {
    if (document.querySelector('.nav-item.active')?.dataset.page === 'dashboard') {
        renderDashboard();
    }
}
