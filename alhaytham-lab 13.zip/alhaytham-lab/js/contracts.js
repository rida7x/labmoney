// ===== قسم التعاقدات =====
// إدارة الجهات المتعاقدة (شركات كبرى تتعامل مع المختبر بشكل دوري)
// مثال: شركة البريقة لتسويق النفط
//
// لكل جهة:
//   - بيانات أساسية (اسم، جهة اتصال، هاتف، عنوان، رقم العقد)
//   - حساب جاري: فواتير (مستحقات لنا) + دفعات (وارد منهم)
//   - الرصيد = إجمالي الفواتير - إجمالي الدفعات
//   - تقرير مطالبة PDF احترافي

let currentContractSearch = '';
let currentContractSort = 'name_asc';
function setContractSort(v) { currentContractSort = v; loadContracts(); }

// ============== الواجهة الرئيسية ==============
async function renderContracts() {
    const content = document.getElementById('content');
    content.innerHTML = `
        <div class="page-header">
            <h2><i class="fas fa-file-contract"></i> التعاقدات</h2>
            <button class="btn btn-primary" onclick="showContractModal()">
                <i class="fas fa-plus"></i> جهة جديدة
            </button>
        </div>

        <div id="contractStats" class="stats-grid" style="margin-bottom:14px;"></div>

        <div class="card">
            <div class="toolbar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="بحث بالاسم أو رقم العقد..." oninput="onContractSearch(this.value)">
                </div>
                ${buildSortSelect(currentContractSort, 'setContractSort')}
                <button class="btn btn-secondary" onclick="exportContractsListPDF()">
                    <i class="fas fa-file-pdf"></i> تقرير شامل
                </button>
            </div>
            <div id="contractsList"></div>
        </div>
    `;
    await loadContracts();
}

function onContractSearch(v) {
    currentContractSearch = v;
    loadContracts();
}

async function computeContractTotals(contractId) {
    const invoices = (await db.getAll('contractInvoices')).filter(i => i.contractId === contractId);
    const payments = (await db.getAll('contractPayments')).filter(p => p.contractId === contractId);
    const totalDue = invoices.reduce((s, i) => s + Number(i.amount || 0), 0);
    const totalPaid = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    return {
        totalDue,
        totalPaid,
        remaining: totalDue - totalPaid,
        invoiceCount: invoices.length,
        paymentCount: payments.length
    };
}

async function loadContracts() {
    let contracts = await db.getAll('contracts');

    if (currentContractSearch) {
        const s = currentContractSearch.toLowerCase();
        contracts = contracts.filter(c =>
            (c.name || '').toLowerCase().includes(s) ||
            (c.contractNumber || '').toLowerCase().includes(s) ||
            (c.contactPerson || '').toLowerCase().includes(s)
        );
    }

    const enriched = await Promise.all(contracts.map(async c => {
        const t = await computeContractTotals(c.id);
        return { ...c, ...t };
    }));

    enriched = sortRecords(enriched, currentContractSort);

    // الإحصائيات
    const totalDue = enriched.reduce((s, c) => s + c.totalDue, 0);
    const totalPaid = enriched.reduce((s, c) => s + c.totalPaid, 0);
    const totalRemaining = totalDue - totalPaid;
    const withRemaining = enriched.filter(c => c.remaining > 0).length;

    document.getElementById('contractStats').innerHTML = `
        <div class="stat-card debt">
            <div class="stat-icon"><i class="fas fa-handshake"></i></div>
            <div class="stat-label">عدد الجهات</div>
            <div class="stat-value">${enriched.length}</div>
            <div class="stat-meta">${withRemaining} لديها مستحقات</div>
        </div>
        <div class="stat-card expense">
            <div class="stat-icon"><i class="fas fa-file-invoice-dollar"></i></div>
            <div class="stat-label">إجمالي المستحقات</div>
            <div class="stat-value">${formatCurrency(totalDue)}</div>
        </div>
        <div class="stat-card revenue">
            <div class="stat-icon"><i class="fas fa-money-bill-trend-up"></i></div>
            <div class="stat-label">المحصَّل</div>
            <div class="stat-value">${formatCurrency(totalPaid)}</div>
        </div>
        <div class="stat-card profit">
            <div class="stat-icon"><i class="fas fa-exclamation-circle"></i></div>
            <div class="stat-label">المتبقي على الجهات</div>
            <div class="stat-value">${formatCurrency(totalRemaining)}</div>
            <div class="stat-meta">${totalDue > 0 ? Math.round(totalPaid / totalDue * 100) : 0}% محصَّل</div>
        </div>
    `;

    const container = document.getElementById('contractsList');
    if (enriched.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding:40px 20px;text-align:center;">
                <i class="fas fa-file-contract" style="font-size:48px;color:#94a3b8;opacity:0.5;"></i>
                <h3 style="margin-top:12px;">لا توجد جهات متعاقدة</h3>
                <p style="color:var(--text-secondary);">اضغط "جهة جديدة" لإضافة جهة مثل شركة البريقة لتسويق النفط</p>
            </div>
        `;
        return;
    }

    container.innerHTML = enriched.map(c => {
        const isPaid = c.remaining <= 0;
        const percentage = c.totalDue > 0 ? Math.min((c.totalPaid / c.totalDue) * 100, 100) : 0;
        return `
            <div class="lab-card" onclick="showContractDetails('${c.id}')" style="cursor:pointer;">
                <div class="lab-card-header">
                    <div>
                        <div class="lab-card-title">
                            <i class="fas fa-building" style="color:var(--primary);"></i>
                            ${c.name}
                        </div>
                        <div style="font-size:13px;color:var(--text-tertiary);margin-top:4px;">
                            ${c.contractNumber ? `<i class="fas fa-hashtag"></i> ${c.contractNumber} • ` : ''}
                            ${c.contactPerson ? `<i class="fas fa-user"></i> ${c.contactPerson} • ` : ''}
                            <i class="fas fa-receipt"></i> ${c.invoiceCount} فاتورة
                        </div>
                    </div>
                    <span class="status ${isPaid ? 'paid' : 'unpaid'}">
                        ${isPaid ? 'مسدد' : 'مستحقات قائمة'}
                    </span>
                </div>

                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:14px 0;">
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">إجمالي المستحق</div>
                        <div style="font-weight:700;">${formatCurrency(c.totalDue)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">المسدَّد</div>
                        <div style="font-weight:700;color:var(--success);">${formatCurrency(c.totalPaid)}</div>
                    </div>
                    <div>
                        <div style="font-size:12px;color:var(--text-tertiary);">المتبقي</div>
                        <div style="font-weight:700;color:${isPaid ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(c.remaining)}</div>
                    </div>
                </div>

                <div style="background:var(--bg-tertiary);border-radius:8px;height:6px;overflow:hidden;">
                    <div style="height:100%;width:${percentage}%;background:linear-gradient(to right,var(--success),var(--primary));transition:width 0.5s;"></div>
                </div>

                <div style="display:flex;justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap;">
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); showContractInvoiceModal('${c.id}')">
                            <i class="fas fa-plus"></i> فاتورة جديدة
                        </button>
                        ${c.remaining > 0 ? `
                            <button class="btn btn-sm btn-success" onclick="event.stopPropagation(); showContractPaymentModal('${c.id}')">
                                <i class="fas fa-money-bill-wave"></i> تسجيل دفعة
                            </button>
                        ` : ''}
                    </div>
                    <div style="display:flex;gap:6px;">
                        <button class="action-btn print" onclick="event.stopPropagation(); printContractStatement('${c.id}')" title="مطالبة PDF">
                            <i class="fas fa-file-pdf"></i>
                        </button>
                        <button class="action-btn edit" onclick="event.stopPropagation(); showContractModal('${c.id}')" title="تعديل البيانات">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" onclick="event.stopPropagation(); deleteContract('${c.id}')" title="حذف">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// ============== إضافة / تعديل جهة ==============
async function showContractModal(id = null) {
    let c = { name: '', contractNumber: '', contactPerson: '', phone: '', email: '', address: '', notes: '' };
    if (id) {
        const found = await db.get('contracts', id);
        if (found) c = found;
    }

    const body = `
        <form id="contractForm" onsubmit="saveContract(event, '${id || ''}')">
            <div class="form-group">
                <label>اسم الجهة <span class="required">*</span></label>
                <input type="text" id="ct_name" value="${c.name || ''}" required placeholder="مثل: شركة البريقة لتسويق النفط">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>رقم العقد / المرجع</label>
                    <input type="text" id="ct_contractNumber" value="${c.contractNumber || ''}" placeholder="CT-2026-001">
                </div>
                <div class="form-group">
                    <label>الشخص المسؤول</label>
                    <input type="text" id="ct_contactPerson" value="${c.contactPerson || ''}" placeholder="مدير المشتريات...">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>رقم الهاتف</label>
                    <input type="tel" id="ct_phone" value="${c.phone || ''}">
                </div>
                <div class="form-group">
                    <label>البريد الإلكتروني</label>
                    <input type="email" id="ct_email" value="${c.email || ''}">
                </div>
            </div>
            <div class="form-group">
                <label>العنوان</label>
                <input type="text" id="ct_address" value="${c.address || ''}">
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="ct_notes" rows="2">${c.notes || ''}</textarea>
            </div>
        </form>
    `;

    showModal(id ? 'تعديل بيانات الجهة' : 'إضافة جهة متعاقدة', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('contractForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
}

async function saveContract(event, id) {
    event.preventDefault();
    const data = {
        name: document.getElementById('ct_name').value.trim(),
        contractNumber: document.getElementById('ct_contractNumber').value.trim(),
        contactPerson: document.getElementById('ct_contactPerson').value.trim(),
        phone: document.getElementById('ct_phone').value.trim(),
        email: document.getElementById('ct_email').value.trim(),
        address: document.getElementById('ct_address').value.trim(),
        notes: document.getElementById('ct_notes').value.trim()
    };
    if (!data.name) {
        showToast('يرجى إدخال اسم الجهة', 'error');
        return;
    }
    try {
        if (id) {
            const existing = await db.get('contracts', id);
            await db.update('contracts', { ...existing, ...data });
            showToast('تم التعديل', 'success');
        } else {
            data.createdAt = new Date().toISOString();
            await db.add('contracts', data);
            showToast('تم إضافة الجهة', 'success');
        }
        closeModal();
        loadContracts();
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

function deleteContract(id) {
    confirmAction('هل تريد حذف هذه الجهة؟ ستُحذف معها كل الفواتير والدفعات المرتبطة.', async () => {
        const invoices = (await db.getAll('contractInvoices')).filter(i => i.contractId === id);
        const payments = (await db.getAll('contractPayments')).filter(p => p.contractId === id);
        for (const i of invoices) { try { await db.delete('contractInvoices', i.id); } catch(_){} }
        for (const p of payments) { try { await db.delete('contractPayments', p.id); } catch(_){} }
        await db.delete('contracts', id);
        showToast('تم الحذف', 'success');
        loadContracts();
    }, 'حذف جهة');
}

// ============== تفاصيل الجهة ==============
async function showContractDetails(id) {
    const c = await db.get('contracts', id);
    if (!c) return;
    const invoices = ((await db.getAll('contractInvoices')).filter(i => i.contractId === id))
        .sort((a, b) => new Date(b.date) - new Date(a.date));
    const payments = ((await db.getAll('contractPayments')).filter(p => p.contractId === id))
        .sort((a, b) => new Date(b.date) - new Date(a.date));
    const totals = await computeContractTotals(id);

    const body = `
        <!-- بيانات الجهة -->
        <div style="background:var(--bg-tertiary);padding:12px;border-radius:10px;margin-bottom:14px;font-size:13px;">
            ${c.contractNumber ? `<div><i class="fas fa-hashtag"></i> <strong>رقم العقد:</strong> ${c.contractNumber}</div>` : ''}
            ${c.contactPerson ? `<div style="margin-top:4px;"><i class="fas fa-user"></i> ${c.contactPerson}</div>` : ''}
            ${c.phone ? `<div style="margin-top:4px;"><i class="fas fa-phone"></i> ${c.phone}</div>` : ''}
            ${c.email ? `<div style="margin-top:4px;"><i class="fas fa-envelope"></i> ${c.email}</div>` : ''}
            ${c.address ? `<div style="margin-top:4px;"><i class="fas fa-location-dot"></i> ${c.address}</div>` : ''}
            ${c.notes ? `<div style="margin-top:6px;color:var(--text-secondary);font-style:italic;">${c.notes}</div>` : ''}
        </div>

        <!-- الإحصائيات -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px;">
            <div style="background:var(--bg-tertiary);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--text-tertiary);">إجمالي المستحق</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;">${formatCurrency(totals.totalDue)}</div>
            </div>
            <div style="background:var(--success-bg);padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:var(--success);">المسدَّد</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:var(--success);">${formatCurrency(totals.totalPaid)}</div>
            </div>
            <div style="background:${totals.remaining <= 0 ? 'var(--success-bg)' : 'var(--danger-bg)'};padding:12px;border-radius:10px;text-align:center;">
                <div style="font-size:12px;color:${totals.remaining <= 0 ? 'var(--success)' : 'var(--danger)'};">المتبقي</div>
                <div style="font-weight:800;font-size:16px;margin-top:4px;color:${totals.remaining <= 0 ? 'var(--success)' : 'var(--danger)'};">${formatCurrency(totals.remaining)}</div>
            </div>
        </div>

        <!-- الفواتير -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <h4 style="font-size:15px;">الفواتير (${invoices.length})</h4>
            <button class="btn btn-sm btn-primary" onclick="closeModal(); setTimeout(() => showContractInvoiceModal('${id}'), 200)">
                <i class="fas fa-plus"></i> فاتورة جديدة
            </button>
        </div>
        ${invoices.length === 0 ? `
            <div class="empty-state" style="padding:14px;text-align:center;color:var(--text-secondary);font-size:13px;">لا توجد فواتير بعد</div>
        ` : `
            <div style="max-height:200px;overflow-y:auto;display:flex;flex-direction:column;gap:8px;margin-bottom:14px;">
                ${invoices.map(inv => `
                    <div class="list-item">
                        <div class="list-icon" style="background:var(--primary-bg);color:var(--primary);">
                            <i class="fas fa-file-invoice"></i>
                        </div>
                        <div class="list-content">
                            <div class="list-title">${inv.description || 'فاتورة'} — ${formatCurrency(inv.amount)}</div>
                            <div class="list-meta">${formatDate(inv.date, false)}${inv.invoiceNumber ? ` • ${inv.invoiceNumber}` : ''}${inv.notes ? ` • ${inv.notes}` : ''}</div>
                        </div>
                        <div style="display:flex;gap:6px;">
                            <button class="action-btn edit" onclick="closeModal(); setTimeout(() => showContractInvoiceModal('${id}', '${inv.id}'), 200)" title="تعديل">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete" onclick="deleteContractInvoice('${inv.id}', '${id}')" title="حذف">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `}

        <!-- الدفعات -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
            <h4 style="font-size:15px;">الدفعات الواردة (${payments.length})</h4>
            ${totals.remaining > 0 ? `
                <button class="btn btn-sm btn-success" onclick="closeModal(); setTimeout(() => showContractPaymentModal('${id}'), 200)">
                    <i class="fas fa-plus"></i> دفعة جديدة
                </button>
            ` : ''}
        </div>
        ${payments.length === 0 ? `
            <div class="empty-state" style="padding:14px;text-align:center;color:var(--text-secondary);font-size:13px;">لا توجد دفعات بعد</div>
        ` : `
            <div style="max-height:200px;overflow-y:auto;display:flex;flex-direction:column;gap:8px;">
                ${payments.map(p => `
                    <div class="list-item">
                        <div class="list-icon" style="background:var(--success-bg);color:var(--success);">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="list-content">
                            <div class="list-title">${formatCurrency(p.amount)}</div>
                            <div class="list-meta">${formatDate(p.date, false)}${p.receiptNumber ? ` • إيصال: ${p.receiptNumber}` : ''}${p.notes ? ` • ${p.notes}` : ''}</div>
                        </div>
                        <div style="display:flex;gap:6px;">
                            <button class="action-btn edit" onclick="closeModal(); setTimeout(() => showContractPaymentModal('${id}', '${p.id}'), 200)" title="تعديل">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete" onclick="deleteContractPayment('${p.id}', '${id}')" title="حذف">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `}
    `;

    showModal(c.name, body, `
        <button class="btn btn-secondary" onclick="closeModal()">إغلاق</button>
        <button class="btn btn-warning" onclick="printContractStatement('${id}')">
            <i class="fas fa-file-pdf"></i> مطالبة PDF
        </button>
    `, 'lg');
}

// ============== فواتير ==============
async function showContractInvoiceModal(contractId, invoiceId = null) {
    let inv = { description: '', amount: 0, date: new Date().toISOString(), invoiceNumber: '', notes: '' };
    if (invoiceId) {
        const found = await db.get('contractInvoices', invoiceId);
        if (found) inv = found;
    }

    const body = `
        <form id="ciForm" onsubmit="saveContractInvoice(event, '${contractId}', '${invoiceId || ''}')">
            <div class="form-group">
                <label>وصف الفاتورة / الخدمة <span class="required">*</span></label>
                <input type="text" id="ci_desc" value="${inv.description || ''}" required placeholder="مثل: تحاليل شهر يناير 2026">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0.01" id="ci_amount" value="${inv.amount || ''}" required>
                </div>
                <div class="form-group">
                    <label>رقم الفاتورة</label>
                    <input type="text" id="ci_invoiceNumber" value="${inv.invoiceNumber || ''}" placeholder="INV-001">
                </div>
            </div>
            <div class="form-group">
                <label>تاريخ الفاتورة</label>
                <input type="date" id="ci_date" value="${inv.date ? String(inv.date).slice(0,10) : getTodayString()}">
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="ci_notes" rows="2">${inv.notes || ''}</textarea>
            </div>
        </form>
    `;
    showModal(invoiceId ? 'تعديل فاتورة' : 'فاتورة جديدة', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-primary" onclick="document.getElementById('ciForm').requestSubmit()">
            <i class="fas fa-save"></i> حفظ
        </button>
    `);
}

async function saveContractInvoice(event, contractId, invoiceId) {
    event.preventDefault();
    const data = {
        contractId,
        description: document.getElementById('ci_desc').value.trim(),
        amount: parseFloat(document.getElementById('ci_amount').value) || 0,
        invoiceNumber: document.getElementById('ci_invoiceNumber').value.trim(),
        date: new Date(document.getElementById('ci_date').value).toISOString(),
        notes: document.getElementById('ci_notes').value.trim()
    };
    if (!data.description || data.amount <= 0) {
        showToast('يرجى ملء البيانات', 'error');
        return;
    }
    try {
        if (invoiceId) {
            const existing = await db.get('contractInvoices', invoiceId);
            await db.update('contractInvoices', { ...existing, ...data });
            showToast('تم تعديل الفاتورة', 'success');
        } else {
            await db.add('contractInvoices', data);
            showToast('تم إضافة الفاتورة', 'success');
        }
        closeModal();
        loadContracts();
        setTimeout(() => showContractDetails(contractId), 200);
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

async function deleteContractInvoice(invoiceId, contractId) {
    confirmAction('هل تريد حذف هذه الفاتورة؟', async () => {
        await db.delete('contractInvoices', invoiceId);
        showToast('تم الحذف', 'success');
        closeModal();
        loadContracts();
        setTimeout(() => showContractDetails(contractId), 200);
    }, 'حذف فاتورة');
}

// ============== دفعات ==============
async function showContractPaymentModal(contractId, paymentId = null) {
    const c = await db.get('contracts', contractId);
    const totals = await computeContractTotals(contractId);
    let payment = { amount: 0, date: new Date().toISOString(), receiptNumber: '', notes: '' };
    if (paymentId) {
        const found = await db.get('contractPayments', paymentId);
        if (found) payment = found;
    }

    const body = `
        <div style="background:var(--primary-bg);padding:12px;border-radius:10px;margin-bottom:14px;">
            <div style="font-weight:700;">${c?.name || ''}</div>
            <div style="font-size:13px;color:var(--text-secondary);margin-top:4px;">
                إجمالي: <strong>${formatCurrency(totals.totalDue)}</strong> • 
                مسدَّد: <strong style="color:var(--success);">${formatCurrency(totals.totalPaid)}</strong> • 
                متبقي: <strong style="color:var(--danger);">${formatCurrency(totals.remaining)}</strong>
            </div>
        </div>
        <form id="cpForm" onsubmit="saveContractPayment(event, '${contractId}', '${paymentId || ''}')">
            <div class="form-row">
                <div class="form-group">
                    <label>المبلغ (د.ل) <span class="required">*</span></label>
                    <input type="number" step="0.01" min="0.01" id="cp_amount" value="${payment.amount || ''}" required autofocus>
                </div>
                <div class="form-group">
                    <label>رقم الإيصال</label>
                    <input type="text" id="cp_receiptNumber" value="${payment.receiptNumber || ''}">
                </div>
            </div>
            <div class="form-group">
                <label>تاريخ الدفعة</label>
                <input type="date" id="cp_date" value="${payment.date ? String(payment.date).slice(0,10) : getTodayString()}">
            </div>
            <div class="form-group">
                <label>ملاحظات</label>
                <textarea id="cp_notes" rows="2">${payment.notes || ''}</textarea>
            </div>
        </form>
    `;
    showModal(paymentId ? 'تعديل دفعة' : 'تسجيل دفعة من الجهة', body, `
        <button class="btn btn-secondary" onclick="closeModal()">إلغاء</button>
        <button class="btn btn-success" onclick="document.getElementById('cpForm').requestSubmit()">
            <i class="fas fa-check"></i> ${paymentId ? 'تحديث' : 'تأكيد الدفعة'}
        </button>
    `);
}

async function saveContractPayment(event, contractId, paymentId) {
    event.preventDefault();
    const data = {
        contractId,
        amount: parseFloat(document.getElementById('cp_amount').value) || 0,
        receiptNumber: document.getElementById('cp_receiptNumber').value.trim(),
        date: new Date(document.getElementById('cp_date').value).toISOString(),
        notes: document.getElementById('cp_notes').value.trim()
    };
    if (data.amount <= 0) {
        showToast('مبلغ غير صحيح', 'error');
        return;
    }
    try {
        if (paymentId) {
            const existing = await db.get('contractPayments', paymentId);
            await db.update('contractPayments', { ...existing, ...data });
            showToast('تم تعديل الدفعة', 'success');
        } else {
            await db.add('contractPayments', data);
            showToast('تم تسجيل الدفعة', 'success');
            // سجّلها أيضاً في الإيرادات
            try {
                const c = await db.get('contracts', contractId);
                await db.add('revenues', {
                    patientName: c?.name || 'جهة متعاقدة',
                    description: `دفعة من ${c?.name || 'جهة'}`,
                    amount: data.amount,
                    paymentMethod: '',
                    date: data.date,
                    notes: 'دفعة من جهة متعاقدة' + (data.notes ? ' — ' + data.notes : ''),
                    sourceType: 'contract_payment',
                    sourceId: contractId
                });
            } catch(_){}
        }
        closeModal();
        loadContracts();
        setTimeout(() => showContractDetails(contractId), 200);
    } catch (e) {
        showToast('خطأ: ' + e.message, 'error');
    }
}

async function deleteContractPayment(paymentId, contractId) {
    confirmAction('هل تريد حذف هذه الدفعة؟', async () => {
        // احذف الإيراد المرتبط
        try {
            const p = await db.get('contractPayments', paymentId);
            const all = await db.getAll('revenues');
            const match = all.find(r =>
                r.sourceType === 'contract_payment' &&
                r.sourceId === contractId &&
                Number(r.amount) === Number(p.amount) &&
                String(r.date).slice(0,10) === String(p.date).slice(0,10)
            );
            if (match) await db.delete('revenues', match.id);
        } catch(_){}
        await db.delete('contractPayments', paymentId);
        showToast('تم الحذف', 'success');
        closeModal();
        loadContracts();
        setTimeout(() => showContractDetails(contractId), 200);
    }, 'حذف دفعة');
}

// ============== تقرير المطالبة PDF ==============
async function printContractStatement(id) {
    const c = await db.get('contracts', id);
    if (!c) return;
    const invoices = ((await db.getAll('contractInvoices')).filter(i => i.contractId === id))
        .sort((a, b) => new Date(a.date) - new Date(b.date));
    const payments = ((await db.getAll('contractPayments')).filter(p => p.contractId === id))
        .sort((a, b) => new Date(a.date) - new Date(b.date));
    const totals = await computeContractTotals(id);

    // ادمج الفواتير والدفعات حسب التاريخ مع رصيد تراكمي
    const movements = [
        ...invoices.map(i => ({ date: i.date, type: 'invoice', desc: i.description, ref: i.invoiceNumber, amount: i.amount })),
        ...payments.map(p => ({ date: p.date, type: 'payment', desc: 'دفعة واردة', ref: p.receiptNumber, amount: p.amount }))
    ].sort((a, b) => new Date(a.date) - new Date(b.date));

    let runningBalance = 0;
    const movementRows = movements.map(m => {
        const debit = m.type === 'invoice' ? m.amount : 0;   // مدين علينا
        const credit = m.type === 'payment' ? m.amount : 0;   // دائن
        runningBalance += debit - credit;
        return {
            date: formatDate(m.date, false),
            desc: m.desc || '-',
            ref: m.ref || '-',
            debit: debit > 0 ? formatCurrency(debit) : '-',
            credit: credit > 0 ? formatCurrency(credit) : '-',
            balance: formatCurrency(runningBalance)
        };
    });

    await generatePDFReport({
        title: `كشف مطالبة: ${c.name}`,
        subtitle: `${c.contractNumber ? `رقم العقد: ${c.contractNumber} • ` : ''}${c.contactPerson ? `المسؤول: ${c.contactPerson}` : ''}`,
        filename: `مطالبة_${c.name.replace(/[\/\\]/g, '_')}_${getTodayString()}.pdf`,
        columns: [
            { key: 'date',    label: 'التاريخ',  width: '15%' },
            { key: 'desc',    label: 'البيان',   width: '30%' },
            { key: 'ref',     label: 'المرجع',   width: '12%' },
            { key: 'debit',   label: 'مدين',     width: '14%' },
            { key: 'credit',  label: 'دائن',     width: '14%' },
            { key: 'balance', label: 'الرصيد',   width: '15%' }
        ],
        rows: movementRows,
        summary: [
            { label: 'إجمالي المستحقات', value: formatCurrency(totals.totalDue) },
            { label: 'إجمالي الدفعات', value: formatCurrency(totals.totalPaid) },
            { label: 'صافي المستحق', value: formatCurrency(totals.remaining), highlight: true }
        ],
        extraSections: c.address || c.phone || c.email ? [{
            title: 'بيانات التواصل',
            html: `
                <div style="font-size:11px;line-height:1.8;padding:6px;">
                    ${c.address ? `<div><strong>العنوان:</strong> ${c.address}</div>` : ''}
                    ${c.phone ? `<div><strong>الهاتف:</strong> ${c.phone}</div>` : ''}
                    ${c.email ? `<div><strong>البريد:</strong> ${c.email}</div>` : ''}
                </div>
            `
        }] : []
    });
}

// تصدير قائمة كل التعاقدات
async function exportContractsListPDF() {
    const contracts = await db.getAll('contracts');
    if (!contracts.length) {
        showToast('لا توجد تعاقدات', 'warning');
        return;
    }
    const enriched = await Promise.all(contracts.map(async c => {
        const t = await computeContractTotals(c.id);
        return {
            name: c.name,
            contractNumber: c.contractNumber || '-',
            contactPerson: c.contactPerson || '-',
            phone: c.phone || '-',
            totalDue: formatCurrency(t.totalDue),
            totalPaid: formatCurrency(t.totalPaid),
            remaining: formatCurrency(t.remaining),
            status: t.remaining <= 0 ? 'مسدد' : 'قائم'
        };
    }));
    enriched.sort((a, b) => a.status === 'قائم' ? -1 : 1);

    const allInv = await db.getAll('contractInvoices');
    const allPay = await db.getAll('contractPayments');
    const totalDue = allInv.reduce((s, i) => s + Number(i.amount || 0), 0);
    const totalPaid = allPay.reduce((s, p) => s + Number(p.amount || 0), 0);

    await generatePDFReport({
        title: 'تقرير التعاقدات الشامل',
        subtitle: `إجمالي الجهات: ${contracts.length}`,
        filename: `التعاقدات_${getTodayString()}.pdf`,
        columns: [
            { key: 'name',           label: 'الجهة',         width: '22%' },
            { key: 'contractNumber', label: 'رقم العقد',     width: '11%' },
            { key: 'contactPerson',  label: 'المسؤول',       width: '13%' },
            { key: 'phone',          label: 'الهاتف',        width: '12%' },
            { key: 'totalDue',       label: 'المستحق',      width: '12%' },
            { key: 'totalPaid',      label: 'المسدَّد',     width: '12%' },
            { key: 'remaining',      label: 'المتبقي',      width: '12%' },
            { key: 'status',         label: 'الحالة',       width: '6%' }
        ],
        rows: enriched,
        summary: [
            { label: 'إجمالي المستحقات', value: formatCurrency(totalDue) },
            { label: 'إجمالي المحصَّل', value: formatCurrency(totalPaid) },
            { label: 'صافي المتبقي', value: formatCurrency(totalDue - totalPaid), highlight: true }
        ]
    });
}
